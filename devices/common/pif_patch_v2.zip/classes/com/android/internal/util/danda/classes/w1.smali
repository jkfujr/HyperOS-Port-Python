.class public final Lcom/android/internal/util/danda/classes/w1;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/z;


# instance fields
.field public final m:[B


# direct methods
.method public constructor <init>([B)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/w1;->m:[B

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w1;->m:[B

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/p5;->a([B)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 3

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/w1;

    if-nez v0, :cond_6

    const/4 p1, 0x0

    return p1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/w1;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w1;->m:[B

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/w1;->m:[B

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/c0;->c([B[B)Z

    move-result p1

    return p1
.end method

.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 4

    const/16 v0, 0x19

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/w1;->m:[B

    invoke-virtual {p1, v0, v1}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    return-void
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w1;->m:[B

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/c0;->j([B)I

    move-result v0

    return v0
.end method

.method public final i()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w1;->m:[B

    array-length v1, v0

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    array-length v0, v0

    add-int/2addr v1, v0

    return v1
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
