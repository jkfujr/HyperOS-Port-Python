.class public abstract synthetic Lcom/android/internal/util/danda/classes/m0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o;
    .registers 2

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, p0}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    move-result-object p0

    return-object p0
.end method
