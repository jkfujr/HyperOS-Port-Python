.class public final Lcom/android/internal/util/danda/classes/b6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public final transient a:Lcom/android/internal/util/danda/classes/i1;


# direct methods
.method public constructor <init>([B)V
    .registers 10

    new-instance v0, Ljava/io/ByteArrayInputStream;

    invoke-direct {v0, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const-string p1, "malformed data: "

    const/4 v1, 0x1

    :try_start_8
    new-instance v2, Lcom/android/internal/util/danda/classes/j;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->c(Ljava/io/InputStream;)I

    move-result v3

    invoke-direct {v2, v0, v3, v1}, Lcom/android/internal/util/danda/classes/j;-><init>(Ljava/io/InputStream;IZ)V

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/j;->f()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    if-eqz v0, :cond_10e

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/i1;->g(Lcom/android/internal/util/danda/classes/t;)Lcom/android/internal/util/danda/classes/i1;

    move-result-object p1
    :try_end_1b
    .catch Ljava/lang/ClassCastException; {:try_start_8 .. :try_end_1b} :catch_118
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_1b} :catch_116

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/b6;->a:Lcom/android/internal/util/danda/classes/i1;

    iget-object v0, p1, Lcom/android/internal/util/danda/classes/i1;->m:Lcom/android/internal/util/danda/classes/r5;

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/r5;->s:Lcom/android/internal/util/danda/classes/g3;

    if-nez v0, :cond_28

    goto/16 :goto_109

    :cond_28
    sget-object v2, Lcom/android/internal/util/danda/classes/f3;->r:Lcom/android/internal/util/danda/classes/o;

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/g3;->m:Ljava/util/Hashtable;

    invoke-virtual {v0, v2}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/f3;

    if-eqz v0, :cond_109

    :try_start_34
    iget-object v0, v0, Lcom/android/internal/util/danda/classes/f3;->o:Lcom/android/internal/util/danda/classes/p;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_3e
    .catch Ljava/io/IOException; {:try_start_34 .. :try_end_3e} :catch_f4

    instance-of v2, v0, Lcom/android/internal/util/danda/classes/v3;

    if-eqz v2, :cond_46

    check-cast v0, Lcom/android/internal/util/danda/classes/v3;

    goto/16 :goto_f1

    :cond_46
    if-eqz v0, :cond_f0

    new-instance v2, Lcom/android/internal/util/danda/classes/v3;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v0, v2, Lcom/android/internal/util/danda/classes/v3;->s:Lcom/android/internal/util/danda/classes/u;

    const/4 v3, 0x0

    move v4, v3

    :goto_55
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v5

    if-eq v4, v5, :cond_ee

    invoke-virtual {v0, v4}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/a0;->n(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/a0;

    move-result-object v5

    iget v6, v5, Lcom/android/internal/util/danda/classes/a0;->m:I

    if-eqz v6, :cond_bb

    if-eq v6, v1, :cond_b0

    const/4 v7, 0x2

    if-eq v6, v7, :cond_a5

    const/4 v7, 0x3

    if-eq v6, v7, :cond_93

    const/4 v7, 0x4

    if-eq v6, v7, :cond_88

    const/4 v7, 0x5

    if-ne v6, v7, :cond_80

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/c;->p(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/c;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/c;->q()Z

    move-result v5

    iput-boolean v5, v2, Lcom/android/internal/util/danda/classes/v3;->r:Z

    goto :goto_ea

    :cond_80
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "unknown tag in IssuingDistributionPoint"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_88
    invoke-static {v5}, Lcom/android/internal/util/danda/classes/c;->p(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/c;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/c;->q()Z

    move-result v5

    iput-boolean v5, v2, Lcom/android/internal/util/danda/classes/v3;->q:Z

    goto :goto_ea

    :cond_93
    new-instance v6, Lcom/android/internal/util/danda/classes/i5;

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/q1;->o(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/q1;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/b;->n()[B

    move-result-object v7

    iget v5, v5, Lcom/android/internal/util/danda/classes/b;->n:I

    invoke-direct {v6, v5, v7}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    iput-object v6, v2, Lcom/android/internal/util/danda/classes/v3;->p:Lcom/android/internal/util/danda/classes/i5;

    goto :goto_ea

    :cond_a5
    invoke-static {v5}, Lcom/android/internal/util/danda/classes/c;->p(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/c;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/c;->q()Z

    move-result v5

    iput-boolean v5, v2, Lcom/android/internal/util/danda/classes/v3;->o:Z

    goto :goto_ea

    :cond_b0
    invoke-static {v5}, Lcom/android/internal/util/danda/classes/c;->p(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/c;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/c;->q()Z

    move-result v5

    iput-boolean v5, v2, Lcom/android/internal/util/danda/classes/v3;->n:Z

    goto :goto_ea

    :cond_bb
    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v5

    check-cast v5, Lcom/android/internal/util/danda/classes/a0;

    if-eqz v5, :cond_e5

    instance-of v6, v5, Lcom/android/internal/util/danda/classes/s2;

    if-eqz v6, :cond_c8

    goto :goto_e5

    :cond_c8
    new-instance v6, Lcom/android/internal/util/danda/classes/s2;

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    iget v7, v5, Lcom/android/internal/util/danda/classes/a0;->m:I

    iput v7, v6, Lcom/android/internal/util/danda/classes/s2;->n:I

    if-nez v7, :cond_de

    invoke-static {v5, v3}, Lcom/android/internal/util/danda/classes/u;->n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;

    move-result-object v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/n3;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/n3;

    move-result-object v5

    iput-object v5, v6, Lcom/android/internal/util/danda/classes/s2;->m:Lcom/android/internal/util/danda/classes/m;

    goto :goto_e8

    :cond_de
    invoke-static {v5}, Lcom/android/internal/util/danda/classes/w;->n(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/w;

    move-result-object v5

    iput-object v5, v6, Lcom/android/internal/util/danda/classes/s2;->m:Lcom/android/internal/util/danda/classes/m;

    goto :goto_e8

    :cond_e5
    :goto_e5
    move-object v6, v5

    check-cast v6, Lcom/android/internal/util/danda/classes/s2;

    :goto_e8
    iput-object v6, v2, Lcom/android/internal/util/danda/classes/v3;->m:Lcom/android/internal/util/danda/classes/s2;

    :goto_ea
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_55

    :cond_ee
    move-object v0, v2

    goto :goto_f1

    :cond_f0
    const/4 v0, 0x0

    :goto_f1
    iget-boolean v0, v0, Lcom/android/internal/util/danda/classes/v3;->q:Z

    goto :goto_109

    :catch_f4
    move-exception p1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "can\'t convert extension: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_109
    :goto_109
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/i1;->m:Lcom/android/internal/util/danda/classes/r5;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/r5;->o:Lcom/android/internal/util/danda/classes/x5;

    return-void

    :cond_10e
    :try_start_10e
    new-instance v0, Ljava/io/IOException;

    const-string v2, "no content found"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_116
    .catch Ljava/lang/ClassCastException; {:try_start_10e .. :try_end_116} :catch_118
    .catch Ljava/lang/IllegalArgumentException; {:try_start_10e .. :try_end_116} :catch_116

    :catch_116
    move-exception v0

    goto :goto_11a

    :catch_118
    move-exception v0

    goto :goto_130

    :goto_11a
    new-instance v2, Lcom/android/internal/util/danda/classes/h;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v2, p1, v0, v1}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v2

    :goto_130
    new-instance v2, Lcom/android/internal/util/danda/classes/h;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v2, p1, v0, v1}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v2
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    if-ne p1, p0, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    instance-of v0, p1, Lcom/android/internal/util/danda/classes/b6;

    if-nez v0, :cond_a

    const/4 p1, 0x0

    return p1

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/b6;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/b6;->a:Lcom/android/internal/util/danda/classes/i1;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/b6;->a:Lcom/android/internal/util/danda/classes/i1;

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/m;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/b6;->a:Lcom/android/internal/util/danda/classes/i1;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/i1;->hashCode()I

    move-result v0

    return v0
.end method
