.class public final Lcom/android/internal/util/danda/classes/w4;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/w4;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/w4;

    if-eq p1, p0, :cond_2e

    iget-object v0, p1, Lcom/android/internal/util/danda/classes/w4;->a:Ljava/lang/String;

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/w4;->a:Ljava/lang/String;

    if-ne v2, v0, :cond_11

    goto :goto_1c

    :cond_11
    if-eqz v2, :cond_2f

    if-nez v0, :cond_16

    goto :goto_2f

    :cond_16
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2f

    :goto_1c
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w4;->b:Ljava/lang/String;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/w4;->b:Ljava/lang/String;

    if-ne v0, p1, :cond_23

    goto :goto_2e

    :cond_23
    if-eqz v0, :cond_2f

    if-nez p1, :cond_28

    goto :goto_2f

    :cond_28
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2f

    :cond_2e
    :goto_2e
    const/4 v1, 0x1

    :cond_2f
    :goto_2f
    return v1
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w4;->a:Ljava/lang/String;

    const/4 v1, 0x1

    if-nez v0, :cond_7

    move v0, v1

    goto :goto_b

    :cond_7
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_b
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/w4;->b:Ljava/lang/String;

    if-nez v2, :cond_10

    goto :goto_14

    :cond_10
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v1

    :goto_14
    mul-int/lit8 v1, v1, 0x1f

    add-int/2addr v1, v0

    return v1
.end method
