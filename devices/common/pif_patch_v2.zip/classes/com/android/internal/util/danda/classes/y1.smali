.class public final Lcom/android/internal/util/danda/classes/y1;
.super Lcom/android/internal/util/danda/classes/l;
.source "SourceFile"


# static fields
.field public static final m:Lcom/android/internal/util/danda/classes/y1;

.field public static final n:[B


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/android/internal/util/danda/classes/y1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    const/4 v0, 0x0

    new-array v0, v0, [B

    sput-object v0, Lcom/android/internal/util/danda/classes/y1;->n:[B

    return-void
.end method


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 4

    sget-object v0, Lcom/android/internal/util/danda/classes/y1;->n:[B

    const/4 v1, 0x5

    invoke-virtual {p1, v1, v0}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    return-void
.end method

.method public final i()I
    .registers 2

    const/4 v0, 0x2

    return v0
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
