.class public final Lcom/android/internal/util/danda/classes/l1;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/k;

.field public n:Lcom/android/internal/util/danda/classes/x5;

.field public o:Lcom/android/internal/util/danda/classes/q5;

.field public p:Lcom/android/internal/util/danda/classes/w;


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/l1;->m:Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/l1;->n:Lcom/android/internal/util/danda/classes/x5;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/l1;->o:Lcom/android/internal/util/danda/classes/q5;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/l1;->p:Lcom/android/internal/util/danda/classes/w;

    if-eqz v2, :cond_21

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    invoke-direct {v3, v1, v1, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_21
    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method
