.class public interface abstract Lcom/android/internal/util/danda/classes/r3;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.0.10118"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "3.0"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "49"

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/r3;->a:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "50"

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/r3;->b:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "55"

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/r3;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.0.18033.2"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "1.2"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "2.4"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    return-void
.end method
