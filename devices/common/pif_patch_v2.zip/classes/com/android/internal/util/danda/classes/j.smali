.class public final Lcom/android/internal/util/danda/classes/j;
.super Ljava/io/FilterInputStream;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:Z

.field public final c:[[B


# direct methods
.method public constructor <init>(Ljava/io/InputStream;IZ)V
    .registers 4

    .line 3
    invoke-direct {p0, p1}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V

    iput p2, p0, Lcom/android/internal/util/danda/classes/j;->a:I

    iput-boolean p3, p0, Lcom/android/internal/util/danda/classes/j;->b:Z

    const/16 p1, 0xb

    new-array p1, p1, [[B

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/j;->c:[[B

    return-void
.end method

.method public constructor <init>([B)V
    .registers 4

    .line 1
    new-instance v0, Ljava/io/ByteArrayInputStream;

    invoke-direct {v0, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    array-length p1, p1

    const/4 v1, 0x0

    .line 2
    invoke-direct {p0, v0, p1, v1}, Lcom/android/internal/util/danda/classes/j;-><init>(Ljava/io/InputStream;IZ)V

    return-void
.end method

.method public static a(Lcom/android/internal/util/danda/classes/q2;)Lcom/android/internal/util/danda/classes/f;
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/j;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/n5;->c(Ljava/io/InputStream;)I

    move-result v1

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, v2}, Lcom/android/internal/util/danda/classes/j;-><init>(Ljava/io/InputStream;IZ)V

    new-instance p0, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {p0, v2}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    :goto_f
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/j;->f()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    if-eqz v1, :cond_19

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_f

    :cond_19
    return-object p0
.end method

.method public static c(ILcom/android/internal/util/danda/classes/q2;[[B)Lcom/android/internal/util/danda/classes/t;
    .registers 8

    const/16 v0, 0xff

    const/4 v1, 0x1

    const/16 v2, 0xa

    const/16 v3, 0xc

    const/4 v4, 0x0

    if-eq p0, v2, :cond_154

    if-eq p0, v3, :cond_14a

    const/16 v2, 0x1e

    if-eq p0, v2, :cond_122

    packed-switch p0, :pswitch_data_18e

    packed-switch p0, :pswitch_data_19e

    new-instance p1, Ljava/io/IOException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "unknown tag "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " encountered"

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :pswitch_2f
    new-instance p0, Lcom/android/internal/util/danda/classes/j2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/j2;-><init>([B)V

    return-object p0

    :pswitch_39
    new-instance p0, Lcom/android/internal/util/danda/classes/u1;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/u1;-><init>([B)V

    return-object p0

    :pswitch_43
    new-instance p0, Lcom/android/internal/util/danda/classes/l2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/l2;-><init>([B)V

    return-object p0

    :pswitch_4d
    new-instance p0, Lcom/android/internal/util/danda/classes/w1;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/w1;-><init>([B)V

    return-object p0

    :pswitch_57
    new-instance p0, Lcom/android/internal/util/danda/classes/i;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/i;->m:[B

    return-object p0

    :pswitch_63
    new-instance p0, Lcom/android/internal/util/danda/classes/b0;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/b0;->m:[B

    return-object p0

    :pswitch_6f
    new-instance p0, Lcom/android/internal/util/danda/classes/x1;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/x1;-><init>([B)V

    return-object p0

    :pswitch_79
    new-instance p0, Lcom/android/internal/util/danda/classes/k2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/k2;-><init>([B)V

    return-object p0

    :pswitch_83
    new-instance p0, Lcom/android/internal/util/danda/classes/f2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/f2;->m:[B

    return-object p0

    :pswitch_93
    new-instance p0, Lcom/android/internal/util/danda/classes/c2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/c2;-><init>([B)V

    return-object p0

    :pswitch_9d
    new-instance p0, Lcom/android/internal/util/danda/classes/z1;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/z1;-><init>([B)V

    return-object p0

    :pswitch_a7
    invoke-static {p1, p2}, Lcom/android/internal/util/danda/classes/j;->d(Lcom/android/internal/util/danda/classes/q2;[[B)[B

    move-result-object p0

    sget-object p1, Lcom/android/internal/util/danda/classes/o;->o:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance p1, Lcom/android/internal/util/danda/classes/n;

    invoke-direct {p1, p0}, Lcom/android/internal/util/danda/classes/n;-><init>([B)V

    sget-object p2, Lcom/android/internal/util/danda/classes/o;->o:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/internal/util/danda/classes/o;

    if-nez p1, :cond_c1

    new-instance p1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {p1, p0}, Lcom/android/internal/util/danda/classes/o;-><init>([B)V

    :cond_c1
    return-object p1

    :pswitch_c2
    sget-object p0, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    return-object p0

    :pswitch_c5
    new-instance p0, Lcom/android/internal/util/danda/classes/a2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    return-object p0

    :pswitch_cf
    iget p0, p1, Lcom/android/internal/util/danda/classes/q2;->d:I

    if-lt p0, v1, :cond_107

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->read()I

    move-result p2

    add-int/lit8 v1, p0, -0x1

    new-array v2, v1, [B

    if-eqz v1, :cond_101

    invoke-static {p1, v2}, Lcom/android/internal/util/danda/classes/c0;->o(Ljava/io/InputStream;[B)I

    move-result p1

    if-ne p1, v1, :cond_f9

    if-lez p2, :cond_101

    const/16 p1, 0x8

    if-ge p2, p1, :cond_101

    add-int/lit8 p0, p0, -0x2

    aget-byte p0, v2, p0

    shl-int p1, v0, p2

    and-int/2addr p1, p0

    int-to-byte p1, p1

    if-eq p0, p1, :cond_101

    new-instance p0, Lcom/android/internal/util/danda/classes/m2;

    invoke-direct {p0, p2, v2}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    goto :goto_106

    :cond_f9
    new-instance p0, Ljava/io/EOFException;

    const-string p1, "EOF encountered in middle of BIT STRING"

    invoke-direct {p0, p1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_101
    new-instance p0, Lcom/android/internal/util/danda/classes/q1;

    invoke-direct {p0, p2, v2}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    :goto_106
    return-object p0

    :cond_107
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "truncated BIT STRING detected"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_10f
    new-instance p0, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1, v4}, Lcom/android/internal/util/danda/classes/k;-><init>([BZ)V

    return-object p0

    :pswitch_119
    invoke-static {p1, p2}, Lcom/android/internal/util/danda/classes/j;->d(Lcom/android/internal/util/danda/classes/q2;[[B)[B

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/c;->n([B)Lcom/android/internal/util/danda/classes/c;

    move-result-object p0

    return-object p0

    :cond_122
    new-instance p0, Lcom/android/internal/util/danda/classes/p1;

    iget p2, p1, Lcom/android/internal/util/danda/classes/q2;->d:I

    div-int/lit8 p2, p2, 0x2

    new-array v0, p2, [C

    :goto_12a
    if-ge v4, p2, :cond_146

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->read()I

    move-result v1

    if-gez v1, :cond_133

    goto :goto_146

    :cond_133
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->read()I

    move-result v2

    if-gez v2, :cond_13a

    goto :goto_146

    :cond_13a
    add-int/lit8 v3, v4, 0x1

    shl-int/lit8 v1, v1, 0x8

    and-int/lit16 v2, v2, 0xff

    or-int/2addr v1, v2

    int-to-char v1, v1

    aput-char v1, v0, v4

    move v4, v3

    goto :goto_12a

    :cond_146
    :goto_146
    invoke-direct {p0, v0}, Lcom/android/internal/util/danda/classes/p1;-><init>([C)V

    return-object p0

    :cond_14a
    new-instance p0, Lcom/android/internal/util/danda/classes/i2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/i2;-><init>([B)V

    return-object p0

    :cond_154
    invoke-static {p1, p2}, Lcom/android/internal/util/danda/classes/j;->d(Lcom/android/internal/util/danda/classes/q2;[[B)[B

    move-result-object p0

    array-length p1, p0

    if-le p1, v1, :cond_161

    new-instance p1, Lcom/android/internal/util/danda/classes/g;

    invoke-direct {p1, p0}, Lcom/android/internal/util/danda/classes/g;-><init>([B)V

    goto :goto_185

    :cond_161
    array-length p1, p0

    if-eqz p1, :cond_186

    aget-byte p1, p0, v4

    and-int/2addr p1, v0

    if-lt p1, v3, :cond_173

    new-instance p1, Lcom/android/internal/util/danda/classes/g;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object p0

    invoke-direct {p1, p0}, Lcom/android/internal/util/danda/classes/g;-><init>([B)V

    goto :goto_185

    :cond_173
    sget-object p2, Lcom/android/internal/util/danda/classes/g;->n:[Lcom/android/internal/util/danda/classes/g;

    aget-object v0, p2, p1

    if-nez v0, :cond_184

    new-instance v0, Lcom/android/internal/util/danda/classes/g;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object p0

    invoke-direct {v0, p0}, Lcom/android/internal/util/danda/classes/g;-><init>([B)V

    aput-object v0, p2, p1

    :cond_184
    move-object p1, v0

    :goto_185
    return-object p1

    :cond_186
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "ENUMERATED has zero length"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_data_18e
    .packed-switch 0x1
        :pswitch_119
        :pswitch_10f
        :pswitch_cf
        :pswitch_c5
        :pswitch_c2
        :pswitch_a7
    .end packed-switch

    :pswitch_data_19e
    .packed-switch 0x12
        :pswitch_9d
        :pswitch_93
        :pswitch_83
        :pswitch_79
        :pswitch_6f
        :pswitch_63
        :pswitch_57
        :pswitch_4d
        :pswitch_43
        :pswitch_39
        :pswitch_2f
    .end packed-switch
.end method

.method public static d(Lcom/android/internal/util/danda/classes/q2;[[B)[B
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    array-length v1, p1

    if-ge v0, v1, :cond_11

    aget-object v1, p1, v0

    if-nez v1, :cond_d

    new-array v1, v0, [B

    aput-object v1, p1, v0

    :cond_d
    invoke-static {p0, v1}, Lcom/android/internal/util/danda/classes/c0;->o(Ljava/io/InputStream;[B)I

    return-object v1

    :cond_11
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p0

    return-object p0
.end method

.method public static e(ILjava/io/InputStream;)I
    .registers 6

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result v0

    if-ltz v0, :cond_58

    const/16 v1, 0x80

    if-ne v0, v1, :cond_c

    const/4 p0, -0x1

    return p0

    :cond_c
    const/16 v1, 0x7f

    if-le v0, v1, :cond_57

    and-int/lit8 v0, v0, 0x7f

    const/4 v1, 0x4

    if-gt v0, v1, :cond_43

    const/4 v1, 0x0

    move v2, v1

    :goto_17
    if-ge v2, v0, :cond_2d

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result v3

    if-ltz v3, :cond_25

    shl-int/lit8 v1, v1, 0x8

    add-int/2addr v1, v3

    add-int/lit8 v2, v2, 0x1

    goto :goto_17

    :cond_25
    new-instance p0, Ljava/io/EOFException;

    const-string p1, "EOF found reading length"

    invoke-direct {p0, p1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2d
    if-ltz v1, :cond_3b

    if-ge v1, p0, :cond_33

    move v0, v1

    goto :goto_57

    :cond_33
    new-instance p0, Ljava/io/IOException;

    const-string p1, "corrupted stream - out of bounds length found"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3b
    new-instance p0, Ljava/io/IOException;

    const-string p1, "corrupted stream - negative length found"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_43
    new-instance p0, Ljava/io/IOException;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "DER length more than 4 bytes: "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_57
    :goto_57
    return v0

    :cond_58
    new-instance p0, Ljava/io/EOFException;

    const-string p1, "EOF found when length expected"

    invoke-direct {p0, p1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static g(ILjava/io/InputStream;)I
    .registers 4

    const/16 v0, 0x1f

    and-int/2addr p0, v0

    if-ne p0, v0, :cond_34

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result p0

    and-int/lit8 v0, p0, 0x7f

    if-eqz v0, :cond_2c

    const/4 v0, 0x0

    :goto_e
    if-ltz p0, :cond_1e

    and-int/lit16 v1, p0, 0x80

    if-eqz v1, :cond_1e

    and-int/lit8 p0, p0, 0x7f

    or-int/2addr p0, v0

    shl-int/lit8 v0, p0, 0x7

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result p0

    goto :goto_e

    :cond_1e
    if-ltz p0, :cond_24

    and-int/lit8 p0, p0, 0x7f

    or-int/2addr p0, v0

    goto :goto_34

    :cond_24
    new-instance p0, Ljava/io/EOFException;

    const-string p1, "EOF found inside tag value."

    invoke-direct {p0, p1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2c
    new-instance p0, Ljava/io/IOException;

    const-string p1, "corrupted stream - invalid high tag number found"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_34
    :goto_34
    return p0
.end method


# virtual methods
.method public final b(III)Lcom/android/internal/util/danda/classes/t;
    .registers 8

    and-int/lit8 v0, p1, 0x20

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_8

    move v0, v2

    goto :goto_9

    :cond_8
    move v0, v1

    :goto_9
    new-instance v3, Lcom/android/internal/util/danda/classes/q2;

    invoke-direct {v3, p3, p0}, Lcom/android/internal/util/danda/classes/q2;-><init>(ILjava/io/InputStream;)V

    and-int/lit8 p3, p1, 0x40

    if-eqz p3, :cond_1c

    new-instance p1, Lcom/android/internal/util/danda/classes/o0;

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p3

    invoke-direct {p1, v0, p2, p3}, Lcom/android/internal/util/danda/classes/o0;-><init>(ZI[B)V

    return-object p1

    :cond_1c
    and-int/lit16 p1, p1, 0x80

    if-eqz p1, :cond_2a

    new-instance p1, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {p1, v3}, Lcom/android/internal/util/danda/classes/y;-><init>(Lcom/android/internal/util/danda/classes/q2;)V

    invoke-virtual {p1, v0, p2}, Lcom/android/internal/util/danda/classes/y;->b(ZI)Lcom/android/internal/util/danda/classes/a0;

    move-result-object p1

    return-object p1

    :cond_2a
    if-eqz v0, :cond_b7

    const/4 p1, 0x4

    if-eq p2, p1, :cond_9a

    const/16 p1, 0x8

    if-eq p2, p1, :cond_90

    const/16 p1, 0x10

    if-eq p2, p1, :cond_6a

    const/16 p1, 0x11

    if-ne p2, p1, :cond_51

    invoke-static {v3}, Lcom/android/internal/util/danda/classes/j;->a(Lcom/android/internal/util/danda/classes/q2;)Lcom/android/internal/util/danda/classes/f;

    move-result-object p1

    sget-object p2, Lcom/android/internal/util/danda/classes/t1;->a:Lcom/android/internal/util/danda/classes/d2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result p2

    if-ge p2, v2, :cond_4a

    sget-object p1, Lcom/android/internal/util/danda/classes/t1;->b:Lcom/android/internal/util/danda/classes/e2;

    goto :goto_50

    :cond_4a
    new-instance p2, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {p2, v2, p1}, Lcom/android/internal/util/danda/classes/e2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    move-object p1, p2

    :goto_50
    return-object p1

    :cond_51
    new-instance p1, Ljava/io/IOException;

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "unknown tag "

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, " encountered"

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_6a
    iget-boolean p1, p0, Lcom/android/internal/util/danda/classes/j;->b:Z

    if-eqz p1, :cond_7a

    new-instance p1, Lcom/android/internal/util/danda/classes/d4;

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object p2

    invoke-direct {p1}, Lcom/android/internal/util/danda/classes/u;-><init>()V

    iput-object p2, p1, Lcom/android/internal/util/danda/classes/d4;->n:[B

    return-object p1

    :cond_7a
    invoke-static {v3}, Lcom/android/internal/util/danda/classes/j;->a(Lcom/android/internal/util/danda/classes/q2;)Lcom/android/internal/util/danda/classes/f;

    move-result-object p1

    sget-object p2, Lcom/android/internal/util/danda/classes/t1;->a:Lcom/android/internal/util/danda/classes/d2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result p2

    if-ge p2, v2, :cond_89

    sget-object p1, Lcom/android/internal/util/danda/classes/t1;->a:Lcom/android/internal/util/danda/classes/d2;

    goto :goto_8f

    :cond_89
    new-instance p2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {p2, v2, p1}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    move-object p1, p2

    :goto_8f
    return-object p1

    :cond_90
    new-instance p1, Lcom/android/internal/util/danda/classes/r1;

    invoke-static {v3}, Lcom/android/internal/util/danda/classes/j;->a(Lcom/android/internal/util/danda/classes/q2;)Lcom/android/internal/util/danda/classes/f;

    move-result-object p2

    invoke-direct {p1, p2}, Lcom/android/internal/util/danda/classes/r1;-><init>(Lcom/android/internal/util/danda/classes/f;)V

    return-object p1

    :cond_9a
    invoke-static {v3}, Lcom/android/internal/util/danda/classes/j;->a(Lcom/android/internal/util/danda/classes/q2;)Lcom/android/internal/util/danda/classes/f;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result p2

    new-array p3, p2, [Lcom/android/internal/util/danda/classes/p;

    :goto_a4
    if-eq v1, p2, :cond_b1

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->b(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/p;

    aput-object v0, p3, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_a4

    :cond_b1
    new-instance p1, Lcom/android/internal/util/danda/classes/s0;

    invoke-direct {p1, p3}, Lcom/android/internal/util/danda/classes/s0;-><init>([Lcom/android/internal/util/danda/classes/p;)V

    return-object p1

    :cond_b7
    iget-object p1, p0, Lcom/android/internal/util/danda/classes/j;->c:[[B

    invoke-static {p2, v3, p1}, Lcom/android/internal/util/danda/classes/j;->c(ILcom/android/internal/util/danda/classes/q2;[[B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    return-object p1
.end method

.method public final f()Lcom/android/internal/util/danda/classes/t;
    .registers 8

    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v0

    if-gtz v0, :cond_12

    if-eqz v0, :cond_a

    const/4 v0, 0x0

    return-object v0

    :cond_a
    new-instance v0, Ljava/io/IOException;

    const-string v1, "unexpected end-of-contents marker"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_12
    invoke-static {v0, p0}, Lcom/android/internal/util/danda/classes/j;->g(ILjava/io/InputStream;)I

    move-result v1

    and-int/lit8 v2, v0, 0x20

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_1e

    move v2, v3

    goto :goto_1f

    :cond_1e
    move v2, v4

    :goto_1f
    iget v5, p0, Lcom/android/internal/util/danda/classes/j;->a:I

    invoke-static {v5, p0}, Lcom/android/internal/util/danda/classes/j;->e(ILjava/io/InputStream;)I

    move-result v6

    if-gez v6, :cond_b4

    if-eqz v2, :cond_ac

    new-instance v2, Lcom/android/internal/util/danda/classes/t3;

    invoke-direct {v2, v5, p0}, Lcom/android/internal/util/danda/classes/t3;-><init>(ILjava/io/InputStream;)V

    new-instance v6, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {v6, v5, v2}, Lcom/android/internal/util/danda/classes/y;-><init>(ILcom/android/internal/util/danda/classes/e4;)V

    and-int/lit8 v2, v0, 0x40

    if-eqz v2, :cond_41

    new-instance v0, Lcom/android/internal/util/danda/classes/o0;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o0;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v0

    :cond_41
    and-int/lit16 v0, v0, 0x80

    if-eqz v0, :cond_4a

    invoke-virtual {v6, v3, v1}, Lcom/android/internal/util/danda/classes/y;->b(ZI)Lcom/android/internal/util/danda/classes/a0;

    move-result-object v0

    return-object v0

    :cond_4a
    const/4 v0, 0x4

    if-eq v1, v0, :cond_8a

    const/16 v0, 0x8

    if-eq v1, v0, :cond_75

    const/16 v0, 0x10

    if-eq v1, v0, :cond_6b

    const/16 v0, 0x11

    if-ne v1, v0, :cond_63

    new-instance v0, Lcom/android/internal/util/danda/classes/w0;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v1

    invoke-direct {v0, v1, v4}, Lcom/android/internal/util/danda/classes/w;-><init>(Lcom/android/internal/util/danda/classes/f;Z)V

    return-object v0

    :cond_63
    new-instance v0, Ljava/io/IOException;

    const-string v1, "unknown BER object encountered"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_6b
    new-instance v0, Lcom/android/internal/util/danda/classes/u0;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/u;-><init>(Lcom/android/internal/util/danda/classes/f;)V

    return-object v0

    :cond_75
    :try_start_75
    new-instance v0, Lcom/android/internal/util/danda/classes/r1;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/r1;-><init>(Lcom/android/internal/util/danda/classes/f;)V
    :try_end_7e
    .catch Ljava/lang/IllegalArgumentException; {:try_start_75 .. :try_end_7e} :catch_7f

    return-object v0

    :catch_7f
    move-exception v0

    new-instance v1, Lcom/android/internal/util/danda/classes/h;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, v0, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1

    :cond_8a
    new-instance v0, Lcom/android/internal/util/danda/classes/s0;

    new-instance v1, Lcom/android/internal/util/danda/classes/m1;

    invoke-direct {v1, v6}, Lcom/android/internal/util/danda/classes/m1;-><init>(Lcom/android/internal/util/danda/classes/y;)V

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v3, 0x1000

    new-array v5, v3, [B

    :goto_9a
    invoke-virtual {v1, v5, v4, v3}, Lcom/android/internal/util/danda/classes/m1;->read([BII)I

    move-result v6

    if-ltz v6, :cond_a4

    invoke-virtual {v2, v5, v4, v6}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_9a

    :cond_a4
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    return-object v0

    :cond_ac
    new-instance v0, Ljava/io/IOException;

    const-string v1, "indefinite-length primitive encoding encountered"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_b4
    :try_start_b4
    invoke-virtual {p0, v0, v1, v6}, Lcom/android/internal/util/danda/classes/j;->b(III)Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_b8
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b4 .. :try_end_b8} :catch_b9

    return-object v0

    :catch_b9
    move-exception v0

    new-instance v1, Lcom/android/internal/util/danda/classes/h;

    const-string v2, "corrupted stream detected"

    invoke-direct {v1, v2, v0, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1
.end method
