.class public final Lcom/android/internal/util/danda/classes/y2;
.super Lcom/android/internal/util/danda/classes/a3;
.source "SourceFile"


# instance fields
.field public final d:I

.field public final e:I

.field public final f:[I

.field public final g:Lcom/android/internal/util/danda/classes/f4;


# direct methods
.method public constructor <init>(IIIILjava/math/BigInteger;)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p5, :cond_ae

    .line 2
    invoke-virtual {p5}, Ljava/math/BigInteger;->signum()I

    move-result v0

    if-ltz v0, :cond_ae

    invoke-virtual {p5}, Ljava/math/BigInteger;->bitLength()I

    move-result v0

    if-gt v0, p1, :cond_ae

    const/4 v0, 0x2

    if-nez p3, :cond_1f

    if-nez p4, :cond_1f

    iput v0, p0, Lcom/android/internal/util/danda/classes/y2;->d:I

    filled-new-array {p2}, [I

    move-result-object p2

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    goto :goto_2c

    :cond_1f
    if-ge p3, p4, :cond_a6

    if-lez p3, :cond_9e

    const/4 v1, 0x3

    iput v1, p0, Lcom/android/internal/util/danda/classes/y2;->d:I

    filled-new-array {p2, p3, p4}, [I

    move-result-object p2

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    :goto_2c
    iput p1, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    .line 3
    new-instance p1, Lcom/android/internal/util/danda/classes/f4;

    .line 4
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 5
    invoke-virtual {p5}, Ljava/math/BigInteger;->signum()I

    move-result p2

    if-ltz p2, :cond_96

    .line 6
    invoke-virtual {p5}, Ljava/math/BigInteger;->signum()I

    move-result p2

    const/4 p3, 0x1

    const-wide/16 v1, 0x0

    const/4 p4, 0x0

    if-nez p2, :cond_4a

    new-array p2, p3, [J

    aput-wide v1, p2, p4

    iput-object p2, p1, Lcom/android/internal/util/danda/classes/f4;->a:[J

    goto :goto_93

    .line 7
    :cond_4a
    invoke-virtual {p5}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p2

    .line 8
    array-length p5, p2

    .line 9
    aget-byte v3, p2, p4

    if-nez v3, :cond_56

    add-int/lit8 p5, p5, -0x1

    goto :goto_57

    :cond_56
    move p3, p4

    :goto_57
    add-int/lit8 v3, p5, 0x7

    const/16 v4, 0x8

    .line 10
    div-int/2addr v3, v4

    .line 11
    new-array v5, v3, [J

    iput-object v5, p1, Lcom/android/internal/util/danda/classes/f4;->a:[J

    add-int/lit8 v5, v3, -0x1

    .line 12
    rem-int/2addr p5, v4

    add-int/2addr p5, p3

    if-ge p3, p5, :cond_79

    move-wide v6, v1

    :goto_67
    if-ge p3, p5, :cond_73

    shl-long/2addr v6, v4

    .line 13
    aget-byte v8, p2, p3

    and-int/lit16 v8, v8, 0xff

    int-to-long v8, v8

    or-long/2addr v6, v8

    add-int/lit8 p3, p3, 0x1

    goto :goto_67

    :cond_73
    iget-object p5, p1, Lcom/android/internal/util/danda/classes/f4;->a:[J

    sub-int/2addr v3, v0

    .line 14
    aput-wide v6, p5, v5

    move v5, v3

    :cond_79
    :goto_79
    if-ltz v5, :cond_93

    move p5, p4

    move-wide v6, v1

    :goto_7d
    if-ge p5, v4, :cond_8c

    shl-long/2addr v6, v4

    add-int/lit8 v0, p3, 0x1

    .line 15
    aget-byte p3, p2, p3

    and-int/lit16 p3, p3, 0xff

    int-to-long v8, p3

    or-long/2addr v6, v8

    add-int/lit8 p5, p5, 0x1

    move p3, v0

    goto :goto_7d

    :cond_8c
    iget-object p5, p1, Lcom/android/internal/util/danda/classes/f4;->a:[J

    .line 16
    aput-wide v6, p5, v5

    add-int/lit8 v5, v5, -0x1

    goto :goto_79

    :cond_93
    :goto_93
    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    return-void

    .line 17
    :cond_96
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "invalid F2m field value"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 18
    :cond_9e
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "k2 must be larger than 0"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 19
    :cond_a6
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "k2 must be smaller than k3"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 20
    :cond_ae
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "x value invalid in F2m field element"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(ILcom/android/internal/util/danda/classes/f4;[I)V
    .registers 5

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    .line 22
    array-length p1, p3

    const/4 v0, 0x1

    if-ne p1, v0, :cond_b

    const/4 p1, 0x2

    goto :goto_c

    :cond_b
    const/4 p1, 0x3

    :goto_c
    iput p1, p0, Lcom/android/internal/util/danda/classes/y2;->d:I

    iput-object p3, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    return-void
.end method

.method public static r(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)V
    .registers 4

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/y2;

    if-eqz v0, :cond_33

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/y2;

    if-eqz v0, :cond_33

    check-cast p0, Lcom/android/internal/util/danda/classes/y2;

    check-cast p1, Lcom/android/internal/util/danda/classes/y2;

    iget v0, p0, Lcom/android/internal/util/danda/classes/y2;->d:I

    iget v1, p1, Lcom/android/internal/util/danda/classes/y2;->d:I

    if-ne v0, v1, :cond_2b

    iget v0, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget v1, p1, Lcom/android/internal/util/danda/classes/y2;->e:I

    if-ne v0, v1, :cond_23

    iget-object p0, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/y2;->f:[I

    invoke-static {p0, p1}, Lcom/android/internal/util/danda/classes/c0;->d([I[I)Z

    move-result p0

    if-eqz p0, :cond_23

    return-void

    :cond_23
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Field elements are not elements of the same field F2m"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "One of the F2m field elements has incorrect representation"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_33
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Field elements are not both instances of ECFieldElement.F2m"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
    .registers 5

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/f4;

    check-cast p1, Lcom/android/internal/util/danda/classes/y2;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/f4;->c(Lcom/android/internal/util/danda/classes/f4;)V

    new-instance p1, Lcom/android/internal/util/danda/classes/y2;

    iget v1, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    invoke-direct {p1, v1, v0, v2}, Lcom/android/internal/util/danda/classes/y2;-><init>(ILcom/android/internal/util/danda/classes/f4;[I)V

    return-object p1
.end method

.method public final b()Lcom/android/internal/util/danda/classes/a3;
    .registers 9

    new-instance v0, Lcom/android/internal/util/danda/classes/y2;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    iget-object v2, v1, Lcom/android/internal/util/danda/classes/f4;->a:[J

    array-length v2, v2

    const/4 v3, 0x0

    const-wide/16 v4, 0x1

    const/4 v6, 0x1

    if-nez v2, :cond_17

    new-instance v1, Lcom/android/internal/util/danda/classes/f4;

    new-array v2, v6, [J

    aput-wide v4, v2, v3

    invoke-direct {v1, v2}, Lcom/android/internal/util/danda/classes/f4;-><init>([J)V

    goto :goto_35

    :cond_17
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/f4;->k()I

    move-result v2

    invoke-static {v6, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    new-array v6, v2, [J

    iget-object v1, v1, Lcom/android/internal/util/danda/classes/f4;->a:[J

    array-length v7, v1

    invoke-static {v7, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v1, v3, v6, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    aget-wide v1, v6, v3

    xor-long/2addr v1, v4

    aput-wide v1, v6, v3

    new-instance v1, Lcom/android/internal/util/danda/classes/f4;

    invoke-direct {v1, v6}, Lcom/android/internal/util/danda/classes/f4;-><init>([J)V

    :goto_35
    iget v2, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    invoke-direct {v0, v2, v1, v3}, Lcom/android/internal/util/danda/classes/y2;-><init>(ILcom/android/internal/util/danda/classes/f4;[I)V

    return-object v0
.end method

.method public final c()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->f()I

    move-result v0

    return v0
.end method

.method public final d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
    .registers 2

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/a3;->f()Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/android/internal/util/danda/classes/y2;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    return-object p1
.end method

.method public final e()I
    .registers 2

    iget v0, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/android/internal/util/danda/classes/y2;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/y2;

    iget v1, p1, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget v3, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    if-ne v3, v1, :cond_2d

    iget v1, p0, Lcom/android/internal/util/danda/classes/y2;->d:I

    iget v3, p1, Lcom/android/internal/util/danda/classes/y2;->d:I

    if-ne v1, v3, :cond_2d

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    iget-object v3, p1, Lcom/android/internal/util/danda/classes/y2;->f:[I

    invoke-static {v1, v3}, Lcom/android/internal/util/danda/classes/c0;->d([I[I)Z

    move-result v1

    if-eqz v1, :cond_2d

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v1, p1}, Lcom/android/internal/util/danda/classes/f4;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2d

    goto :goto_2e

    :cond_2d
    move v0, v2

    :goto_2e
    return v0
.end method

.method public final f()Lcom/android/internal/util/danda/classes/a3;
    .registers 16

    new-instance v0, Lcom/android/internal/util/danda/classes/y2;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/f4;->f()I

    move-result v2

    if-eqz v2, :cond_a3

    iget v3, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget-object v4, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    const/4 v5, 0x1

    if-ne v2, v5, :cond_12

    goto :goto_84

    :cond_12
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/f4;->clone()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/f4;

    add-int/lit8 v6, v3, 0x3f

    ushr-int/lit8 v6, v6, 0x6

    new-instance v7, Lcom/android/internal/util/danda/classes/f4;

    invoke-direct {v7, v6}, Lcom/android/internal/util/danda/classes/f4;-><init>(I)V

    iget-object v8, v7, Lcom/android/internal/util/danda/classes/f4;->a:[J

    invoke-static {v8, v3}, Lcom/android/internal/util/danda/classes/f4;->h([JI)V

    sub-int v9, v3, v3

    array-length v10, v4

    :goto_29
    add-int/lit8 v10, v10, -0x1

    if-ltz v10, :cond_34

    aget v11, v4, v10

    add-int/2addr v11, v9

    invoke-static {v8, v11}, Lcom/android/internal/util/danda/classes/f4;->h([JI)V

    goto :goto_29

    :cond_34
    invoke-static {v8, v9}, Lcom/android/internal/util/danda/classes/f4;->h([JI)V

    new-instance v8, Lcom/android/internal/util/danda/classes/f4;

    invoke-direct {v8, v6}, Lcom/android/internal/util/danda/classes/f4;-><init>(I)V

    iget-object v9, v8, Lcom/android/internal/util/danda/classes/f4;->a:[J

    const-wide/16 v10, 0x1

    const/4 v12, 0x0

    aput-wide v10, v9, v12

    new-instance v9, Lcom/android/internal/util/danda/classes/f4;

    invoke-direct {v9, v6}, Lcom/android/internal/util/danda/classes/f4;-><init>(I)V

    add-int/lit8 v6, v3, 0x1

    filled-new-array {v2, v6}, [I

    move-result-object v2

    filled-new-array {v1, v7}, [Lcom/android/internal/util/danda/classes/f4;

    move-result-object v1

    filled-new-array {v5, v12}, [I

    move-result-object v6

    filled-new-array {v8, v9}, [Lcom/android/internal/util/danda/classes/f4;

    move-result-object v7

    aget v8, v2, v5

    aget v9, v6, v5

    aget v10, v2, v12

    sub-int v10, v8, v10

    :goto_62
    if-gez v10, :cond_6f

    neg-int v10, v10

    aput v8, v2, v5

    aput v9, v6, v5

    rsub-int/lit8 v5, v5, 0x1

    aget v8, v2, v5

    aget v9, v6, v5

    :cond_6f
    aget-object v11, v1, v5

    rsub-int/lit8 v12, v5, 0x1

    aget-object v13, v1, v12

    aget v14, v2, v12

    invoke-virtual {v11, v13, v14, v10}, Lcom/android/internal/util/danda/classes/f4;->b(Lcom/android/internal/util/danda/classes/f4;II)V

    aget-object v11, v1, v5

    invoke-virtual {v11, v8}, Lcom/android/internal/util/danda/classes/f4;->g(I)I

    move-result v11

    if-nez v11, :cond_88

    aget-object v1, v7, v12

    :goto_84
    invoke-direct {v0, v3, v1, v4}, Lcom/android/internal/util/danda/classes/y2;-><init>(ILcom/android/internal/util/danda/classes/f4;[I)V

    return-object v0

    :cond_88
    aget v13, v6, v12

    aget-object v14, v7, v5

    aget-object v12, v7, v12

    invoke-virtual {v14, v12, v13, v10}, Lcom/android/internal/util/danda/classes/f4;->b(Lcom/android/internal/util/danda/classes/f4;II)V

    add-int/2addr v13, v10

    if-le v13, v9, :cond_96

    move v9, v13

    goto :goto_9e

    :cond_96
    if-ne v13, v9, :cond_9e

    aget-object v12, v7, v5

    invoke-virtual {v12, v9}, Lcom/android/internal/util/danda/classes/f4;->g(I)I

    move-result v9

    :cond_9e
    :goto_9e
    sub-int v8, v11, v8

    add-int/2addr v10, v8

    move v8, v11

    goto :goto_62

    :cond_a3
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0
.end method

.method public final g()Z
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->m()Z

    move-result v0

    return v0
.end method

.method public final h()Z
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->n()Z

    move-result v0

    return v0
.end method

.method public final hashCode()I
    .registers 6

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->hashCode()I

    move-result v0

    iget v1, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    xor-int/2addr v0, v1

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    if-nez v1, :cond_f

    const/4 v1, 0x0

    goto :goto_1d

    :cond_f
    array-length v2, v1

    add-int/lit8 v3, v2, 0x1

    :goto_12
    add-int/lit8 v2, v2, -0x1

    if-ltz v2, :cond_1c

    mul-int/lit16 v3, v3, 0x101

    aget v4, v1, v2

    xor-int/2addr v3, v4

    goto :goto_12

    :cond_1c
    move v1, v3

    :goto_1d
    xor-int/2addr v0, v1

    return v0
.end method

.method public final i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
    .registers 31

    move-object/from16 v0, p0

    new-instance v1, Lcom/android/internal/util/danda/classes/y2;

    move-object/from16 v2, p1

    check-cast v2, Lcom/android/internal/util/danda/classes/y2;

    iget-object v2, v2, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/f4;->f()I

    move-result v4

    iget v5, v0, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget-object v6, v0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    if-nez v4, :cond_19

    :goto_16
    move-object v2, v3

    goto/16 :goto_138

    :cond_19
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/f4;->f()I

    move-result v7

    if-nez v7, :cond_21

    goto/16 :goto_138

    :cond_21
    if-le v4, v7, :cond_2d

    move-object/from16 v27, v3

    move-object v3, v2

    move-object/from16 v2, v27

    move/from16 v28, v7

    move v7, v4

    move/from16 v4, v28

    :cond_2d
    add-int/lit8 v8, v4, 0x3f

    ushr-int/lit8 v8, v8, 0x6

    add-int/lit8 v9, v7, 0x3f

    ushr-int/lit8 v9, v9, 0x6

    add-int/2addr v4, v7

    add-int/lit8 v4, v4, 0x3e

    ushr-int/lit8 v4, v4, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-ne v8, v11, :cond_5d

    iget-object v3, v3, Lcom/android/internal/util/danda/classes/f4;->a:[J

    aget-wide v7, v3, v10

    const-wide/16 v10, 0x1

    cmp-long v3, v7, v10

    if-nez v3, :cond_4a

    goto/16 :goto_138

    :cond_4a
    new-array v3, v4, [J

    iget-object v2, v2, Lcom/android/internal/util/danda/classes/f4;->a:[J

    invoke-static {v7, v8, v2, v9, v3}, Lcom/android/internal/util/danda/classes/f4;->p(J[JI[J)V

    invoke-static {v3, v4, v5, v6}, Lcom/android/internal/util/danda/classes/f4;->q([JII[I)I

    move-result v2

    new-instance v4, Lcom/android/internal/util/danda/classes/f4;

    invoke-direct {v4, v3, v2}, Lcom/android/internal/util/danda/classes/f4;-><init>([JI)V

    move-object v2, v4

    goto/16 :goto_138

    :cond_5d
    add-int/lit8 v7, v7, 0x46

    ushr-int/lit8 v7, v7, 0x6

    const/16 v15, 0x10

    new-array v14, v15, [I

    shl-int/lit8 v13, v7, 0x4

    new-array v12, v13, [J

    aput v7, v14, v11

    iget-object v2, v2, Lcom/android/internal/util/danda/classes/f4;->a:[J

    invoke-static {v2, v10, v12, v7, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v2, 0x2

    move v9, v7

    :goto_72
    if-ge v2, v15, :cond_b5

    add-int/2addr v9, v7

    aput v9, v14, v2

    and-int/lit8 v11, v2, 0x1

    if-nez v11, :cond_8f

    ushr-int/lit8 v11, v9, 0x1

    const/16 v17, 0x1

    move-object/from16 v22, v12

    move v10, v13

    move v13, v11

    move-object v11, v14

    move-object/from16 v14, v22

    move/from16 v18, v15

    move v15, v9

    move/from16 v16, v7

    invoke-static/range {v12 .. v17}, Lcom/android/internal/util/danda/classes/f4;->r([JI[JIII)V

    goto :goto_ab

    :cond_8f
    move-object/from16 v22, v12

    move v10, v13

    move-object v11, v14

    move/from16 v18, v15

    sub-int v12, v9, v7

    const/4 v13, 0x0

    :goto_98
    if-ge v13, v7, :cond_ab

    add-int v14, v9, v13

    add-int v15, v7, v13

    aget-wide v15, v22, v15

    add-int v17, v12, v13

    aget-wide v19, v22, v17

    xor-long v15, v15, v19

    aput-wide v15, v22, v14

    add-int/lit8 v13, v13, 0x1

    goto :goto_98

    :cond_ab
    :goto_ab
    add-int/lit8 v2, v2, 0x1

    move v13, v10

    move-object v14, v11

    move/from16 v15, v18

    move-object/from16 v12, v22

    const/4 v10, 0x0

    goto :goto_72

    :cond_b5
    move-object/from16 v22, v12

    move v10, v13

    move-object v11, v14

    new-array v2, v10, [J

    const/16 v17, 0x0

    const/16 v19, 0x0

    const/16 v21, 0x4

    move-object/from16 v16, v22

    move-object/from16 v18, v2

    move/from16 v20, v10

    invoke-static/range {v16 .. v21}, Lcom/android/internal/util/danda/classes/f4;->r([JI[JIII)V

    iget-object v3, v3, Lcom/android/internal/util/danda/classes/f4;->a:[J

    shl-int/lit8 v9, v4, 0x3

    new-array v15, v9, [J

    const/4 v10, 0x0

    :goto_d1
    if-ge v10, v8, :cond_118

    aget-wide v12, v3, v10

    move v14, v10

    :goto_d6
    long-to-int v0, v12

    and-int/lit8 v0, v0, 0xf

    const/16 v16, 0x4

    move/from16 v17, v8

    move/from16 v18, v9

    ushr-long v8, v12, v16

    long-to-int v8, v8

    and-int/lit8 v8, v8, 0xf

    aget v0, v11, v0

    aget v8, v11, v8

    const/4 v9, 0x0

    :goto_e9
    if-ge v9, v7, :cond_100

    add-int v16, v14, v9

    aget-wide v19, v15, v16

    add-int v21, v0, v9

    aget-wide v23, v22, v21

    add-int v21, v8, v9

    aget-wide v25, v2, v21

    xor-long v23, v23, v25

    xor-long v19, v19, v23

    aput-wide v19, v15, v16

    add-int/lit8 v9, v9, 0x1

    goto :goto_e9

    :cond_100
    const/16 v0, 0x8

    ushr-long/2addr v12, v0

    const-wide/16 v8, 0x0

    cmp-long v0, v12, v8

    if-nez v0, :cond_112

    add-int/lit8 v10, v10, 0x1

    move-object/from16 v0, p0

    move/from16 v8, v17

    move/from16 v9, v18

    goto :goto_d1

    :cond_112
    add-int/2addr v14, v4

    move/from16 v8, v17

    move/from16 v9, v18

    goto :goto_d6

    :cond_118
    move/from16 v18, v9

    :goto_11a
    sub-int/2addr v9, v4

    if-eqz v9, :cond_12c

    sub-int v11, v9, v4

    const/16 v0, 0x8

    move-object v10, v15

    move-object v12, v15

    move v13, v9

    move v14, v4

    move-object v2, v15

    move v15, v0

    invoke-static/range {v10 .. v15}, Lcom/android/internal/util/danda/classes/f4;->d([JI[JIII)J

    move-object v15, v2

    goto :goto_11a

    :cond_12c
    move-object v2, v15

    invoke-static {v2, v4, v5, v6}, Lcom/android/internal/util/danda/classes/f4;->q([JII[I)I

    move-result v0

    new-instance v3, Lcom/android/internal/util/danda/classes/f4;

    invoke-direct {v3, v2, v0}, Lcom/android/internal/util/danda/classes/f4;-><init>([JI)V

    goto/16 :goto_16

    :goto_138
    invoke-direct {v1, v5, v2, v6}, Lcom/android/internal/util/danda/classes/y2;-><init>(ILcom/android/internal/util/danda/classes/f4;[I)V

    return-object v1
.end method

.method public final j(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lcom/android/internal/util/danda/classes/y2;->k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    return-object p1
.end method

.method public final k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
    .registers 8

    check-cast p1, Lcom/android/internal/util/danda/classes/y2;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    check-cast p2, Lcom/android/internal/util/danda/classes/y2;

    iget-object p2, p2, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    check-cast p3, Lcom/android/internal/util/danda/classes/y2;

    iget-object p3, p3, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    iget v1, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/f4;->o(Lcom/android/internal/util/danda/classes/f4;)Lcom/android/internal/util/danda/classes/f4;

    move-result-object v3

    invoke-virtual {p2, p3}, Lcom/android/internal/util/danda/classes/f4;->o(Lcom/android/internal/util/danda/classes/f4;)Lcom/android/internal/util/danda/classes/f4;

    move-result-object p2

    if-eq v3, v0, :cond_1e

    if-ne v3, p1, :cond_25

    :cond_1e
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/f4;->clone()Ljava/lang/Object;

    move-result-object p1

    move-object v3, p1

    check-cast v3, Lcom/android/internal/util/danda/classes/f4;

    :cond_25
    invoke-virtual {v3, p2}, Lcom/android/internal/util/danda/classes/f4;->c(Lcom/android/internal/util/danda/classes/f4;)V

    iget-object p1, v3, Lcom/android/internal/util/danda/classes/f4;->a:[J

    array-length p2, p1

    invoke-static {p1, p2, v1, v2}, Lcom/android/internal/util/danda/classes/f4;->q([JII[I)I

    move-result p2

    array-length p3, p1

    if-ge p2, p3, :cond_3a

    new-array p3, p2, [J

    iput-object p3, v3, Lcom/android/internal/util/danda/classes/f4;->a:[J

    const/4 v0, 0x0

    invoke-static {p1, v0, p3, v0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_3a
    new-instance p1, Lcom/android/internal/util/danda/classes/y2;

    invoke-direct {p1, v1, v3, v2}, Lcom/android/internal/util/danda/classes/y2;-><init>(ILcom/android/internal/util/danda/classes/f4;[I)V

    return-object p1
.end method

.method public final l()Lcom/android/internal/util/danda/classes/a3;
    .registers 1

    return-object p0
.end method

.method public final m()Lcom/android/internal/util/danda/classes/a3;
    .registers 14

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->n()Z

    move-result v1

    if-nez v1, :cond_61

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->m()Z

    move-result v1

    if-eqz v1, :cond_f

    goto :goto_61

    :cond_f
    iget v1, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    add-int/lit8 v2, v1, -0x1

    const/4 v3, 0x1

    if-ge v2, v3, :cond_17

    goto :goto_61

    :cond_17
    new-instance v4, Lcom/android/internal/util/danda/classes/y2;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->k()I

    move-result v5

    iget-object v6, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    if-nez v5, :cond_22

    goto :goto_5d

    :cond_22
    add-int/lit8 v7, v1, 0x3f

    ushr-int/lit8 v7, v7, 0x6

    shl-int/lit8 v3, v7, 0x1

    new-array v7, v3, [J

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/f4;->a:[J

    const/4 v8, 0x0

    invoke-static {v0, v8, v7, v8, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_30
    add-int/lit8 v2, v2, -0x1

    if-ltz v2, :cond_58

    shl-int/lit8 v0, v5, 0x1

    :goto_36
    add-int/lit8 v5, v5, -0x1

    if-ltz v5, :cond_53

    aget-wide v8, v7, v5

    add-int/lit8 v10, v0, -0x1

    const/16 v11, 0x20

    ushr-long v11, v8, v11

    long-to-int v11, v11

    invoke-static {v11}, Lcom/android/internal/util/danda/classes/f4;->l(I)J

    move-result-wide v11

    aput-wide v11, v7, v10

    add-int/lit8 v0, v0, -0x2

    long-to-int v8, v8

    invoke-static {v8}, Lcom/android/internal/util/danda/classes/f4;->l(I)J

    move-result-wide v8

    aput-wide v8, v7, v0

    goto :goto_36

    :cond_53
    invoke-static {v7, v3, v1, v6}, Lcom/android/internal/util/danda/classes/f4;->q([JII[I)I

    move-result v5

    goto :goto_30

    :cond_58
    new-instance v0, Lcom/android/internal/util/danda/classes/f4;

    invoke-direct {v0, v7, v5}, Lcom/android/internal/util/danda/classes/f4;-><init>([JI)V

    :goto_5d
    invoke-direct {v4, v1, v0, v6}, Lcom/android/internal/util/danda/classes/y2;-><init>(ILcom/android/internal/util/danda/classes/f4;[I)V

    goto :goto_62

    :cond_61
    :goto_61
    move-object v4, p0

    :goto_62
    return-object v4
.end method

.method public final n()Lcom/android/internal/util/danda/classes/a3;
    .registers 13

    new-instance v0, Lcom/android/internal/util/danda/classes/y2;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/f4;->k()I

    move-result v2

    iget v3, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget-object v4, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    if-nez v2, :cond_f

    goto :goto_3b

    :cond_f
    shl-int/lit8 v2, v2, 0x1

    new-array v5, v2, [J

    const/4 v6, 0x0

    :goto_14
    if-ge v6, v2, :cond_32

    iget-object v7, v1, Lcom/android/internal/util/danda/classes/f4;->a:[J

    ushr-int/lit8 v8, v6, 0x1

    aget-wide v7, v7, v8

    add-int/lit8 v9, v6, 0x1

    long-to-int v10, v7

    invoke-static {v10}, Lcom/android/internal/util/danda/classes/f4;->l(I)J

    move-result-wide v10

    aput-wide v10, v5, v6

    add-int/lit8 v6, v6, 0x2

    const/16 v10, 0x20

    ushr-long/2addr v7, v10

    long-to-int v7, v7

    invoke-static {v7}, Lcom/android/internal/util/danda/classes/f4;->l(I)J

    move-result-wide v7

    aput-wide v7, v5, v9

    goto :goto_14

    :cond_32
    new-instance v1, Lcom/android/internal/util/danda/classes/f4;

    invoke-static {v5, v2, v3, v4}, Lcom/android/internal/util/danda/classes/f4;->q([JII[I)I

    move-result v2

    invoke-direct {v1, v5, v2}, Lcom/android/internal/util/danda/classes/f4;-><init>([JI)V

    :goto_3b
    invoke-direct {v0, v3, v1, v4}, Lcom/android/internal/util/danda/classes/y2;-><init>(ILcom/android/internal/util/danda/classes/f4;[I)V

    return-object v0
.end method

.method public final o(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
    .registers 13

    check-cast p1, Lcom/android/internal/util/danda/classes/y2;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    check-cast p2, Lcom/android/internal/util/danda/classes/y2;

    iget-object p2, p2, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->k()I

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_13

    move-object v4, v0

    goto :goto_3b

    :cond_13
    shl-int/lit8 v1, v1, 0x1

    new-array v3, v1, [J

    move v4, v2

    :goto_18
    if-ge v4, v1, :cond_36

    iget-object v5, v0, Lcom/android/internal/util/danda/classes/f4;->a:[J

    ushr-int/lit8 v6, v4, 0x1

    aget-wide v5, v5, v6

    add-int/lit8 v7, v4, 0x1

    long-to-int v8, v5

    invoke-static {v8}, Lcom/android/internal/util/danda/classes/f4;->l(I)J

    move-result-wide v8

    aput-wide v8, v3, v4

    add-int/lit8 v4, v4, 0x2

    const/16 v8, 0x20

    ushr-long/2addr v5, v8

    long-to-int v5, v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/f4;->l(I)J

    move-result-wide v5

    aput-wide v5, v3, v7

    goto :goto_18

    :cond_36
    new-instance v4, Lcom/android/internal/util/danda/classes/f4;

    invoke-direct {v4, v3, v1}, Lcom/android/internal/util/danda/classes/f4;-><init>([JI)V

    :goto_3b
    iget v1, p0, Lcom/android/internal/util/danda/classes/y2;->e:I

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/y2;->f:[I

    invoke-virtual {p1, p2}, Lcom/android/internal/util/danda/classes/f4;->o(Lcom/android/internal/util/danda/classes/f4;)Lcom/android/internal/util/danda/classes/f4;

    move-result-object p1

    if-ne v4, v0, :cond_4c

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/f4;->clone()Ljava/lang/Object;

    move-result-object p2

    move-object v4, p2

    check-cast v4, Lcom/android/internal/util/danda/classes/f4;

    :cond_4c
    invoke-virtual {v4, p1}, Lcom/android/internal/util/danda/classes/f4;->c(Lcom/android/internal/util/danda/classes/f4;)V

    iget-object p1, v4, Lcom/android/internal/util/danda/classes/f4;->a:[J

    array-length p2, p1

    invoke-static {p1, p2, v1, v3}, Lcom/android/internal/util/danda/classes/f4;->q([JII[I)I

    move-result p2

    array-length v0, p1

    if-ge p2, v0, :cond_60

    new-array v0, p2, [J

    iput-object v0, v4, Lcom/android/internal/util/danda/classes/f4;->a:[J

    invoke-static {p1, v2, v0, v2, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_60
    new-instance p1, Lcom/android/internal/util/danda/classes/y2;

    invoke-direct {p1, v1, v4, v3}, Lcom/android/internal/util/danda/classes/y2;-><init>(ILcom/android/internal/util/danda/classes/f4;[I)V

    return-object p1
.end method

.method public final p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
    .registers 2

    invoke-virtual {p0, p1}, Lcom/android/internal/util/danda/classes/y2;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    return-object p1
.end method

.method public final q()Ljava/math/BigInteger;
    .registers 16

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->k()I

    move-result v1

    if-nez v1, :cond_b

    sget-object v0, Lcom/android/internal/util/danda/classes/u2;->a:Ljava/math/BigInteger;

    goto :goto_5e

    :cond_b
    iget-object v2, v0, Lcom/android/internal/util/danda/classes/f4;->a:[J

    add-int/lit8 v3, v1, -0x1

    aget-wide v4, v2, v3

    const/16 v2, 0x8

    new-array v6, v2, [B

    const/4 v7, 0x7

    const/4 v8, 0x0

    move v9, v7

    move v10, v8

    move v11, v10

    :goto_1a
    const/4 v12, 0x1

    if-ltz v9, :cond_30

    mul-int/lit8 v13, v9, 0x8

    ushr-long v13, v4, v13

    long-to-int v13, v13

    int-to-byte v13, v13

    if-nez v11, :cond_27

    if-eqz v13, :cond_2d

    :cond_27
    add-int/lit8 v11, v10, 0x1

    aput-byte v13, v6, v10

    move v10, v11

    move v11, v12

    :cond_2d
    add-int/lit8 v9, v9, -0x1

    goto :goto_1a

    :cond_30
    mul-int/2addr v3, v2

    add-int/2addr v3, v10

    new-array v2, v3, [B

    :goto_34
    if-ge v8, v10, :cond_3d

    aget-byte v3, v6, v8

    aput-byte v3, v2, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_34

    :cond_3d
    add-int/lit8 v1, v1, -0x2

    :goto_3f
    if-ltz v1, :cond_59

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/f4;->a:[J

    aget-wide v3, v3, v1

    move v5, v7

    :goto_46
    if-ltz v5, :cond_56

    add-int/lit8 v6, v10, 0x1

    mul-int/lit8 v8, v5, 0x8

    ushr-long v8, v3, v8

    long-to-int v8, v8

    int-to-byte v8, v8

    aput-byte v8, v2, v10

    add-int/lit8 v5, v5, -0x1

    move v10, v6

    goto :goto_46

    :cond_56
    add-int/lit8 v1, v1, -0x1

    goto :goto_3f

    :cond_59
    new-instance v0, Ljava/math/BigInteger;

    invoke-direct {v0, v12, v2}, Ljava/math/BigInteger;-><init>(I[B)V

    :goto_5e
    return-object v0
.end method
