.class public final Lcom/android/internal/util/danda/classes/x5;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/d;


# static fields
.field public static final q:Lcom/android/internal/util/danda/classes/n0;


# instance fields
.field public m:Z

.field public n:I

.field public final o:Lcom/android/internal/util/danda/classes/c0;

.field public final p:[Lcom/android/internal/util/danda/classes/e5;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    sget-object v0, Lcom/android/internal/util/danda/classes/n0;->v:Lcom/android/internal/util/danda/classes/n0;

    sput-object v0, Lcom/android/internal/util/danda/classes/x5;->q:Lcom/android/internal/util/danda/classes/n0;

    return-void
.end method

.method public constructor <init>()V
    .registers 14

    sget-object v0, Lcom/android/internal/util/danda/classes/x5;->q:Lcom/android/internal/util/danda/classes/n0;

    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    new-instance v1, Lcom/android/internal/util/danda/classes/z5;

    const/16 v2, 0x2c

    const-string v3, "CN=Android Keystore Key"

    .line 13
    invoke-direct {v1, v3, v2}, Lcom/android/internal/util/danda/classes/z5;-><init>(Ljava/lang/String;C)V

    .line 14
    new-instance v2, Lcom/android/internal/util/danda/classes/y5;

    .line 15
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 16
    new-instance v3, Ljava/util/Vector;

    invoke-direct {v3}, Ljava/util/Vector;-><init>()V

    iput-object v3, v2, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    iput-object v0, v2, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    .line 17
    :goto_1c
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/z5;->a()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_14d

    .line 18
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v3

    const/16 v5, 0x2b

    .line 19
    invoke-virtual {v3, v5}, Ljava/lang/String;->indexOf(I)I

    move-result v6

    const-string v7, "badly formatted directory string"

    const/16 v8, 0x3d

    if-lez v6, :cond_123

    .line 20
    new-instance v6, Lcom/android/internal/util/danda/classes/z5;

    invoke-direct {v6, v3, v5}, Lcom/android/internal/util/danda/classes/z5;-><init>(Ljava/lang/String;C)V

    .line 21
    new-instance v3, Lcom/android/internal/util/danda/classes/z5;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v5, v8}, Lcom/android/internal/util/danda/classes/z5;-><init>(Ljava/lang/String;C)V

    .line 22
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v5

    .line 23
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/z5;->a()Z

    move-result v9

    if-eqz v9, :cond_11d

    .line 24
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v3

    .line 25
    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Lcom/android/internal/util/danda/classes/n0;->t(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o;

    move-result-object v5

    .line 26
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/z5;->a()Z

    move-result v9

    if-eqz v9, :cond_114

    .line 27
    new-instance v9, Ljava/util/Vector;

    invoke-direct {v9}, Ljava/util/Vector;-><init>()V

    .line 28
    new-instance v10, Ljava/util/Vector;

    invoke-direct {v10}, Ljava/util/Vector;-><init>()V

    .line 29
    invoke-virtual {v9, v5}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    .line 30
    invoke-static {v3}, Lcom/android/internal/util/danda/classes/c0;->r(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v10, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    .line 31
    :goto_71
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/z5;->a()Z

    move-result v3

    if-eqz v3, :cond_a7

    .line 32
    new-instance v3, Lcom/android/internal/util/danda/classes/z5;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v5, v8}, Lcom/android/internal/util/danda/classes/z5;-><init>(Ljava/lang/String;C)V

    .line 33
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v5

    .line 34
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/z5;->a()Z

    move-result v11

    if-eqz v11, :cond_a1

    .line 35
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v3

    .line 36
    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Lcom/android/internal/util/danda/classes/n0;->t(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o;

    move-result-object v5

    .line 37
    invoke-virtual {v9, v5}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    .line 38
    invoke-static {v3}, Lcom/android/internal/util/danda/classes/c0;->r(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v10, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    goto :goto_71

    .line 39
    :cond_a1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 40
    :cond_a7
    invoke-virtual {v9}, Ljava/util/Vector;->size()I

    move-result v3

    new-array v5, v3, [Lcom/android/internal/util/danda/classes/o;

    move v6, v4

    :goto_ae
    if-eq v6, v3, :cond_bb

    .line 41
    invoke-virtual {v9, v6}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/internal/util/danda/classes/o;

    aput-object v7, v5, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_ae

    .line 42
    :cond_bb
    invoke-virtual {v10}, Ljava/util/Vector;->size()I

    move-result v6

    new-array v7, v6, [Ljava/lang/String;

    move v8, v4

    :goto_c2
    if-eq v8, v6, :cond_cf

    .line 43
    invoke-virtual {v10, v8}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    aput-object v9, v7, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_c2

    .line 44
    :cond_cf
    new-array v8, v6, [Lcom/android/internal/util/danda/classes/e;

    move v9, v4

    :goto_d2
    if-eq v9, v6, :cond_e8

    iget-object v10, v2, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v10, Lcom/android/internal/util/danda/classes/c0;

    .line 45
    aget-object v11, v5, v9

    aget-object v12, v7, v9

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v11, v12}, Lcom/android/internal/util/danda/classes/c0;->p(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)Lcom/android/internal/util/danda/classes/t;

    move-result-object v10

    aput-object v10, v8, v9

    add-int/lit8 v9, v9, 0x1

    goto :goto_d2

    .line 46
    :cond_e8
    new-array v6, v3, [Lcom/android/internal/util/danda/classes/k0;

    move v7, v4

    :goto_eb
    if-eq v7, v3, :cond_ff

    .line 47
    new-instance v9, Lcom/android/internal/util/danda/classes/k0;

    aget-object v10, v5, v7

    aget-object v11, v8, v7

    .line 48
    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    iput-object v10, v9, Lcom/android/internal/util/danda/classes/k0;->m:Lcom/android/internal/util/danda/classes/o;

    iput-object v11, v9, Lcom/android/internal/util/danda/classes/k0;->n:Lcom/android/internal/util/danda/classes/e;

    .line 49
    aput-object v9, v6, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_eb

    :cond_ff
    iget-object v3, v2, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v3, Ljava/util/Vector;

    .line 50
    new-instance v5, Lcom/android/internal/util/danda/classes/e5;

    .line 51
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 52
    new-instance v7, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {v7, v6, v4}, Lcom/android/internal/util/danda/classes/e2;-><init>([Lcom/android/internal/util/danda/classes/e;I)V

    iput-object v7, v5, Lcom/android/internal/util/danda/classes/e5;->m:Lcom/android/internal/util/danda/classes/w;

    .line 53
    invoke-virtual {v3, v5}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    goto/16 :goto_1c

    .line 54
    :cond_114
    invoke-static {v3}, Lcom/android/internal/util/danda/classes/c0;->r(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v5, v3}, Lcom/android/internal/util/danda/classes/y5;->b(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    goto/16 :goto_1c

    .line 55
    :cond_11d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 56
    :cond_123
    new-instance v4, Lcom/android/internal/util/danda/classes/z5;

    invoke-direct {v4, v3, v8}, Lcom/android/internal/util/danda/classes/z5;-><init>(Ljava/lang/String;C)V

    .line 57
    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v3

    .line 58
    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/z5;->a()Z

    move-result v5

    if-eqz v5, :cond_147

    .line 59
    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/z5;->b()Ljava/lang/String;

    move-result-object v4

    .line 60
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/n0;->t(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o;

    move-result-object v3

    .line 61
    invoke-static {v4}, Lcom/android/internal/util/danda/classes/c0;->r(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lcom/android/internal/util/danda/classes/y5;->b(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    goto/16 :goto_1c

    .line 62
    :cond_147
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_14d
    iget-object v1, v2, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v1, Ljava/util/Vector;

    .line 63
    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    new-array v3, v1, [Lcom/android/internal/util/danda/classes/e5;

    move v5, v4

    :goto_158
    if-eq v5, v1, :cond_169

    iget-object v6, v2, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v6, Ljava/util/Vector;

    .line 64
    invoke-virtual {v6, v5}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/android/internal/util/danda/classes/e5;

    aput-object v6, v3, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_158

    :cond_169
    array-length v1, v3

    .line 65
    new-array v2, v1, [Lcom/android/internal/util/danda/classes/e5;

    .line 66
    invoke-static {v3, v4, v2, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 67
    invoke-direct {p0, v0, v2}, Lcom/android/internal/util/danda/classes/x5;-><init>(Lcom/android/internal/util/danda/classes/c0;[Lcom/android/internal/util/danda/classes/e5;)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/x5;->o:Lcom/android/internal/util/danda/classes/c0;

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/c0;[Lcom/android/internal/util/danda/classes/e5;)V
    .registers 3

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/x5;->p:[Lcom/android/internal/util/danda/classes/e5;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/x5;->o:Lcom/android/internal/util/danda/classes/c0;

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/u;)V
    .registers 7

    sget-object v0, Lcom/android/internal/util/danda/classes/x5;->q:Lcom/android/internal/util/danda/classes/n0;

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/x5;->o:Lcom/android/internal/util/danda/classes/c0;

    .line 2
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v0

    new-array v0, v0, [Lcom/android/internal/util/danda/classes/e5;

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/x5;->p:[Lcom/android/internal/util/danda/classes/e5;

    .line 3
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object p1

    const/4 v0, 0x0

    :goto_14
    invoke-interface {p1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_3d

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/x5;->p:[Lcom/android/internal/util/danda/classes/e5;

    add-int/lit8 v2, v0, 0x1

    .line 4
    invoke-interface {p1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v3

    .line 5
    instance-of v4, v3, Lcom/android/internal/util/danda/classes/e5;

    if-eqz v4, :cond_29

    .line 6
    check-cast v3, Lcom/android/internal/util/danda/classes/e5;

    goto :goto_39

    :cond_29
    if-eqz v3, :cond_38

    .line 7
    new-instance v4, Lcom/android/internal/util/danda/classes/e5;

    invoke-static {v3}, Lcom/android/internal/util/danda/classes/w;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/w;

    move-result-object v3

    .line 8
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    iput-object v3, v4, Lcom/android/internal/util/danda/classes/e5;->m:Lcom/android/internal/util/danda/classes/w;

    move-object v3, v4

    goto :goto_39

    :cond_38
    const/4 v3, 0x0

    .line 9
    :goto_39
    aput-object v3, v1, v0

    move v0, v2

    goto :goto_14

    :cond_3d
    return-void
.end method

.method public static g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/x5;
    .registers 2

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/x5;

    if-eqz v0, :cond_7

    check-cast p0, Lcom/android/internal/util/danda/classes/x5;

    return-object p0

    :cond_7
    if-eqz p0, :cond_13

    new-instance v0, Lcom/android/internal/util/danda/classes/x5;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    invoke-direct {v0, p0}, Lcom/android/internal/util/danda/classes/x5;-><init>(Lcom/android/internal/util/danda/classes/u;)V

    return-object v0

    :cond_13
    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/d2;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/x5;->p:[Lcom/android/internal/util/danda/classes/e5;

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/d2;-><init>([Lcom/android/internal/util/danda/classes/e;)V

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/android/internal/util/danda/classes/x5;

    const/4 v2, 0x0

    if-nez v1, :cond_e

    instance-of v1, p1, Lcom/android/internal/util/danda/classes/u;

    if-nez v1, :cond_e

    return v2

    :cond_e
    move-object v1, p1

    check-cast v1, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/x5;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v3

    invoke-virtual {v3, v1}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_20

    return v0

    :cond_20
    :try_start_20
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x5;->o:Lcom/android/internal/util/danda/classes/c0;

    new-instance v1, Lcom/android/internal/util/danda/classes/x5;

    check-cast p1, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {p1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p1

    invoke-direct {v1, p1}, Lcom/android/internal/util/danda/classes/x5;-><init>(Lcom/android/internal/util/danda/classes/u;)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v1}, Lcom/android/internal/util/danda/classes/c0;->b(Lcom/android/internal/util/danda/classes/x5;Lcom/android/internal/util/danda/classes/x5;)Z

    move-result p1
    :try_end_38
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_38} :catch_39

    return p1

    :catch_39
    return v2
.end method

.method public final hashCode()I
    .registers 9

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/x5;->m:Z

    if-eqz v0, :cond_7

    iget v0, p0, Lcom/android/internal/util/danda/classes/x5;->n:I

    return v0

    :cond_7
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/internal/util/danda/classes/x5;->m:Z

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x5;->o:Lcom/android/internal/util/danda/classes/c0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x5;->p:[Lcom/android/internal/util/danda/classes/e5;

    array-length v1, v0

    new-array v2, v1, [Lcom/android/internal/util/danda/classes/e5;

    const/4 v3, 0x0

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move v0, v3

    move v4, v0

    :goto_1a
    if-eq v0, v1, :cond_74

    aget-object v5, v2, v0

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/e5;->i()Z

    move-result v5

    if-eqz v5, :cond_4d

    aget-object v5, v2, v0

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/e5;->h()[Lcom/android/internal/util/danda/classes/k0;

    move-result-object v5

    move v6, v3

    :goto_2b
    array-length v7, v5

    if-eq v6, v7, :cond_71

    aget-object v7, v5, v6

    iget-object v7, v7, Lcom/android/internal/util/danda/classes/k0;->m:Lcom/android/internal/util/danda/classes/o;

    iget-object v7, v7, Lcom/android/internal/util/danda/classes/o;->m:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v4, v7

    aget-object v7, v5, v6

    iget-object v7, v7, Lcom/android/internal/util/danda/classes/k0;->n:Lcom/android/internal/util/danda/classes/e;

    invoke-static {v7}, Lcom/android/internal/util/danda/classes/c0;->s(Lcom/android/internal/util/danda/classes/e;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/android/internal/util/danda/classes/c0;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    move-result v7

    xor-int/2addr v4, v7

    add-int/lit8 v6, v6, 0x1

    goto :goto_2b

    :cond_4d
    aget-object v5, v2, v0

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/e5;->g()Lcom/android/internal/util/danda/classes/k0;

    move-result-object v5

    iget-object v5, v5, Lcom/android/internal/util/danda/classes/k0;->m:Lcom/android/internal/util/danda/classes/o;

    iget-object v5, v5, Lcom/android/internal/util/danda/classes/o;->m:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v4, v5

    aget-object v5, v2, v0

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/e5;->g()Lcom/android/internal/util/danda/classes/k0;

    move-result-object v5

    iget-object v5, v5, Lcom/android/internal/util/danda/classes/k0;->n:Lcom/android/internal/util/danda/classes/e;

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/c0;->s(Lcom/android/internal/util/danda/classes/e;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/c0;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    move-result v5

    xor-int/2addr v4, v5

    :cond_71
    add-int/lit8 v0, v0, 0x1

    goto :goto_1a

    :cond_74
    iput v4, p0, Lcom/android/internal/util/danda/classes/x5;->n:I

    return v4
.end method

.method public final toString()Ljava/lang/String;
    .registers 14

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x5;->o:Lcom/android/internal/util/danda/classes/c0;

    check-cast v0, Lcom/android/internal/util/danda/classes/n0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/x5;->p:[Lcom/android/internal/util/danda/classes/e5;

    array-length v3, v2

    new-array v4, v3, [Lcom/android/internal/util/danda/classes/e5;

    const/4 v5, 0x0

    invoke-static {v2, v5, v4, v5, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v2, 0x1

    move v7, v2

    move v6, v5

    :goto_18
    if-ge v6, v3, :cond_57

    if-eqz v7, :cond_1e

    move v7, v5

    goto :goto_23

    :cond_1e
    const/16 v8, 0x2c

    invoke-virtual {v1, v8}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    :goto_23
    aget-object v8, v4, v6

    iget-object v9, v0, Lcom/android/internal/util/danda/classes/n0;->l:Ljava/util/Hashtable;

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/e5;->i()Z

    move-result v10

    if-eqz v10, :cond_47

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/e5;->h()[Lcom/android/internal/util/danda/classes/k0;

    move-result-object v8

    move v11, v2

    move v10, v5

    :goto_33
    array-length v12, v8

    if-eq v10, v12, :cond_54

    if-eqz v11, :cond_3a

    move v11, v5

    goto :goto_3f

    :cond_3a
    const/16 v12, 0x2b

    invoke-virtual {v1, v12}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    :goto_3f
    aget-object v12, v8, v10

    invoke-static {v1, v12, v9}, Lcom/android/internal/util/danda/classes/c0;->a(Ljava/lang/StringBuffer;Lcom/android/internal/util/danda/classes/k0;Ljava/util/Hashtable;)V

    add-int/lit8 v10, v10, 0x1

    goto :goto_33

    :cond_47
    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/e5;->g()Lcom/android/internal/util/danda/classes/k0;

    move-result-object v10

    if-eqz v10, :cond_54

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/e5;->g()Lcom/android/internal/util/danda/classes/k0;

    move-result-object v8

    invoke-static {v1, v8, v9}, Lcom/android/internal/util/danda/classes/c0;->a(Ljava/lang/StringBuffer;Lcom/android/internal/util/danda/classes/k0;Ljava/util/Hashtable;)V

    :cond_54
    add-int/lit8 v6, v6, 0x1

    goto :goto_18

    :cond_57
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
