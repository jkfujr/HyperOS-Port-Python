.class public final Lcom/android/internal/util/danda/classes/q3;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/u3;

.field public n:Lcom/android/internal/util/danda/classes/n3;

.field public o:Lcom/android/internal/util/danda/classes/k4;

.field public p:I


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 7

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/q3;->n:Lcom/android/internal/util/danda/classes/n3;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/q3;->m:Lcom/android/internal/util/danda/classes/u3;

    iget v2, p0, Lcom/android/internal/util/danda/classes/q3;->p:I

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ne v2, v4, :cond_36

    new-instance v2, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    if-eqz v1, :cond_19

    new-instance v5, Lcom/android/internal/util/danda/classes/g2;

    invoke-direct {v5, v3, v3, v1}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v2, v5}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_19
    if-eqz v0, :cond_23

    new-instance v1, Lcom/android/internal/util/danda/classes/g2;

    invoke-direct {v1, v3, v4, v0}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_23
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/q3;->o:Lcom/android/internal/util/danda/classes/k4;

    if-eqz v0, :cond_30

    new-instance v1, Lcom/android/internal/util/danda/classes/g2;

    const/4 v4, 0x2

    invoke-direct {v1, v3, v4, v0}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_30
    new-instance v0, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v0, v3, v2}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v0

    :cond_36
    if-eqz v0, :cond_3e

    new-instance v1, Lcom/android/internal/util/danda/classes/g2;

    invoke-direct {v1, v4, v4, v0}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    return-object v1

    :cond_3e
    new-instance v0, Lcom/android/internal/util/danda/classes/g2;

    invoke-direct {v0, v4, v3, v1}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    return-object v0
.end method
