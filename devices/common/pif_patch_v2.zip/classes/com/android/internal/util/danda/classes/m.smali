.class public abstract Lcom/android/internal/util/danda/classes/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/e;


# virtual methods
.method public final e()[B
    .registers 3

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v1, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v1, v0}, Lcom/android/internal/util/danda/classes/f;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v1, p0}, Lcom/android/internal/util/danda/classes/f;->k(Lcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    instance-of v0, p1, Lcom/android/internal/util/danda/classes/e;

    if-nez v0, :cond_a

    const/4 p1, 0x0

    return p1

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {p0}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-interface {p1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final f(Ljava/lang/String;)[B
    .registers 4

    const-string v0, "DER"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1b

    new-instance p1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v0, Lcom/android/internal/util/danda/classes/b2;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, Lcom/android/internal/util/danda/classes/b2;-><init>(Ljava/io/OutputStream;I)V

    invoke-virtual {v0, p0}, Lcom/android/internal/util/danda/classes/b2;->k(Lcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {p1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    return-object p1

    :cond_1b
    const-string v0, "DL"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_36

    new-instance p1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    new-instance v0, Lcom/android/internal/util/danda/classes/b2;

    const/4 v1, 0x1

    invoke-direct {v0, p1, v1}, Lcom/android/internal/util/danda/classes/b2;-><init>(Ljava/io/OutputStream;I)V

    invoke-virtual {v0, p0}, Lcom/android/internal/util/danda/classes/b2;->k(Lcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {p1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    return-object p1

    :cond_36
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/m;->e()[B

    move-result-object p1

    return-object p1
.end method

.method public hashCode()I
    .registers 2

    invoke-interface {p0}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/t;->hashCode()I

    move-result v0

    return v0
.end method
