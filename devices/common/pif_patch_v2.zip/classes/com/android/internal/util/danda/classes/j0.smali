.class public final Lcom/android/internal/util/danda/classes/j0;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/k;

.field public n:Lcom/android/internal/util/danda/classes/q3;

.field public o:Lcom/android/internal/util/danda/classes/f0;

.field public p:Lcom/android/internal/util/danda/classes/d0;

.field public q:Lcom/android/internal/util/danda/classes/k;

.field public r:Lcom/android/internal/util/danda/classes/g0;

.field public s:Lcom/android/internal/util/danda/classes/u;

.field public t:Lcom/android/internal/util/danda/classes/q1;

.field public u:Lcom/android/internal/util/danda/classes/g3;


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->m:Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v3

    invoke-virtual {v3}, Ljava/math/BigInteger;->intValue()I

    move-result v3

    if-eqz v3, :cond_15

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_15
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->n:Lcom/android/internal/util/danda/classes/q3;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->o:Lcom/android/internal/util/danda/classes/f0;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->p:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->q:Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->r:Lcom/android/internal/util/danda/classes/g0;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->s:Lcom/android/internal/util/danda/classes/u;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->t:Lcom/android/internal/util/danda/classes/q1;

    if-eqz v2, :cond_3a

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_3a
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/j0;->u:Lcom/android/internal/util/danda/classes/g3;

    if-eqz v2, :cond_41

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_41
    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method
