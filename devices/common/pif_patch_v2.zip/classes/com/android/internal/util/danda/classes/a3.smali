.class public abstract Lcom/android/internal/util/danda/classes/a3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/u2;


# virtual methods
.method public abstract a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract b()Lcom/android/internal/util/danda/classes/a3;
.end method

.method public c()I
    .registers 2

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {v0}, Ljava/math/BigInteger;->bitLength()I

    move-result v0

    return v0
.end method

.method public abstract d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract e()I
.end method

.method public abstract f()Lcom/android/internal/util/danda/classes/a3;
.end method

.method public g()Z
    .registers 3

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a3;->c()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_8

    goto :goto_9

    :cond_8
    const/4 v1, 0x0

    :goto_9
    return v1
.end method

.method public h()Z
    .registers 2

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {v0}, Ljava/math/BigInteger;->signum()I

    move-result v0

    if-nez v0, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public abstract i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract j(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract l()Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract m()Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract n()Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract o(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract q()Ljava/math/BigInteger;
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v0

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Ljava/math/BigInteger;->toString(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
