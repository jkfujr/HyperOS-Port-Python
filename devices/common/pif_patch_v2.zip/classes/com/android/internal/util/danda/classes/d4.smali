.class public final Lcom/android/internal/util/danda/classes/d4;
.super Lcom/android/internal/util/danda/classes/u;
.source "SourceFile"


# instance fields
.field public n:[B


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    if-eqz v0, :cond_a

    const/16 v1, 0x30

    invoke-virtual {p1, v1, v0}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    goto :goto_11

    :cond_a
    invoke-super {p0}, Lcom/android/internal/util/danda/classes/u;->m()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/t;->h(Lcom/android/internal/util/danda/classes/f;)V

    :goto_11
    return-void
.end method

.method public final i()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    if-eqz v0, :cond_10

    array-length v0, v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    array-length v1, v1

    add-int/2addr v0, v1

    return v0

    :cond_10
    invoke-super {p0}, Lcom/android/internal/util/danda/classes/u;->m()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/t;->i()I

    move-result v0

    return v0
.end method

.method public final l()Lcom/android/internal/util/danda/classes/t;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    if-eqz v0, :cond_7

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/d4;->t()V

    :cond_7
    invoke-super {p0}, Lcom/android/internal/util/danda/classes/u;->l()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    return-object v0
.end method

.method public final m()Lcom/android/internal/util/danda/classes/t;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    if-eqz v0, :cond_7

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/d4;->t()V

    :cond_7
    invoke-super {p0}, Lcom/android/internal/util/danda/classes/u;->m()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    return-object v0
.end method

.method public final declared-synchronized p(I)Lcom/android/internal/util/danda/classes/e;
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    if-eqz v0, :cond_b

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/d4;->t()V

    goto :goto_b

    :catchall_9
    move-exception p1

    goto :goto_11

    :cond_b
    :goto_b
    invoke-super {p0, p1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object p1
    :try_end_f
    .catchall {:try_start_1 .. :try_end_f} :catchall_9

    monitor-exit p0

    return-object p1

    :goto_11
    monitor-exit p0

    throw p1
.end method

.method public final declared-synchronized q()Ljava/util/Enumeration;
    .registers 3

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    if-nez v0, :cond_d

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_14

    monitor-exit p0

    return-object v0

    :cond_d
    :try_start_d
    new-instance v1, Lcom/android/internal/util/danda/classes/c4;

    invoke-direct {v1, v0}, Lcom/android/internal/util/danda/classes/c4;-><init>([B)V
    :try_end_12
    .catchall {:try_start_d .. :try_end_12} :catchall_14

    monitor-exit p0

    return-object v1

    :catchall_14
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final declared-synchronized r()I
    .registers 2

    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    if-eqz v0, :cond_b

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/d4;->t()V

    goto :goto_b

    :catchall_9
    move-exception v0

    goto :goto_13

    :cond_b
    :goto_b
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0
    :try_end_11
    .catchall {:try_start_1 .. :try_end_11} :catchall_9

    monitor-exit p0

    return v0

    :goto_13
    monitor-exit p0

    throw v0
.end method

.method public final t()V
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/c4;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/c4;-><init>([B)V

    :goto_7
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/c4;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_17

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/c4;->nextElement()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    goto :goto_7

    :cond_17
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/d4;->n:[B

    return-void
.end method
