.class public final Lcom/android/internal/util/danda/classes/o4;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lcom/android/internal/util/danda/classes/b5;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/b5;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/o4;->a:Lcom/android/internal/util/danda/classes/b5;

    return-void
.end method
