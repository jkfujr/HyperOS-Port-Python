.class public abstract Lcom/android/internal/util/danda/classes/u;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Iterable;


# instance fields
.field public m:Ljava/util/Vector;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/f;)V
    .registers 5

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    const/4 v0, 0x0

    .line 5
    :goto_b
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result v1

    if-eq v0, v1, :cond_1d

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    .line 6
    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->b(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    :cond_1d
    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/t;)V
    .registers 3

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    .line 9
    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    return-void
.end method

.method public static n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;
    .registers 3

    if-eqz p1, :cond_1a

    iget-boolean p1, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    if-eqz p1, :cond_12

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    return-object p0

    :cond_12
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "object implicit - explicit expected."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1a
    iget-boolean p1, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    if-eqz p1, :cond_36

    instance-of p1, p0, Lcom/android/internal/util/danda/classes/y0;

    if-eqz p1, :cond_2c

    new-instance p1, Lcom/android/internal/util/danda/classes/u0;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-direct {p1, p0}, Lcom/android/internal/util/danda/classes/u;-><init>(Lcom/android/internal/util/danda/classes/t;)V

    return-object p1

    :cond_2c
    new-instance p1, Lcom/android/internal/util/danda/classes/d2;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-direct {p1, p0}, Lcom/android/internal/util/danda/classes/d2;-><init>(Lcom/android/internal/util/danda/classes/t;)V

    return-object p1

    :cond_36
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    instance-of p1, p1, Lcom/android/internal/util/danda/classes/u;

    if-eqz p1, :cond_45

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    check-cast p0, Lcom/android/internal/util/danda/classes/u;

    return-object p0

    :cond_45
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v0, "unknown object in getInstance: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;
    .registers 4

    if-eqz p0, :cond_66

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/u;

    if-eqz v0, :cond_7

    goto :goto_66

    :cond_7
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/v;

    if-eqz v0, :cond_18

    check-cast p0, Lcom/android/internal/util/danda/classes/v;

    check-cast p0, Lcom/android/internal/util/danda/classes/v0;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/v0;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    return-object p0

    :cond_18
    instance-of v0, p0, [B

    if-eqz v0, :cond_40

    :try_start_1c
    check-cast p0, [B

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0
    :try_end_26
    .catch Ljava/io/IOException; {:try_start_1c .. :try_end_26} :catch_27

    return-object p0

    :catch_27
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "failed to construct sequence from byte[]: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_40
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/e;

    if-eqz v0, :cond_52

    move-object v0, p0

    check-cast v0, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    instance-of v1, v0, Lcom/android/internal/util/danda/classes/u;

    if-eqz v1, :cond_52

    check-cast v0, Lcom/android/internal/util/danda/classes/u;

    return-object v0

    :cond_52
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "unknown object in getInstance: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_66
    :goto_66
    check-cast p0, Lcom/android/internal/util/danda/classes/u;

    return-object p0
.end method


# virtual methods
.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 6

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/u;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/u;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v0

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v2

    if-eq v0, v2, :cond_13

    return v1

    :cond_13
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object v0

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object p1

    :cond_1b
    :goto_1b
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_3f

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {p1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v2}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-interface {v3}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v3

    if-eq v2, v3, :cond_1b

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3e

    goto :goto_1b

    :cond_3e
    return v1

    :cond_3f
    const/4 p1, 0x1

    return p1
.end method

.method public final hashCode()I
    .registers 4

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v1

    :goto_8
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_1c

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/e;

    mul-int/lit8 v1, v1, 0x11

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    xor-int/2addr v1, v2

    goto :goto_8

    :cond_1c
    return v1
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/e0;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->s()[Lcom/android/internal/util/danda/classes/e;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/e0;-><init>([Ljava/lang/Object;)V

    return-object v0
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public l()Lcom/android/internal/util/danda/classes/t;
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/d2;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/d2;-><init>(I)V

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    return-object v0
.end method

.method public m()Lcom/android/internal/util/danda/classes/t;
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/d2;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/d2;-><init>(I)V

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    return-object v0
.end method

.method public p(I)Lcom/android/internal/util/danda/classes/e;
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    invoke-virtual {v0, p1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/internal/util/danda/classes/e;

    return-object p1
.end method

.method public q()Ljava/util/Enumeration;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    return-object v0
.end method

.method public r()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    return v0
.end method

.method public final s()[Lcom/android/internal/util/danda/classes/e;
    .registers 4

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v0

    new-array v0, v0, [Lcom/android/internal/util/danda/classes/e;

    const/4 v1, 0x0

    :goto_7
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v2

    if-eq v1, v2, :cond_16

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v2

    aput-object v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_16
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
