.class public final Lcom/android/internal/util/danda/classes/c6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public final transient a:Lcom/android/internal/util/danda/classes/e1;

.field public final transient b:Lcom/android/internal/util/danda/classes/g3;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/e1;)V
    .registers 2

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    .line 9
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/e1;->n:Lcom/android/internal/util/danda/classes/s5;

    .line 10
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/s5;->s:Lcom/android/internal/util/danda/classes/g3;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/c6;->b:Lcom/android/internal/util/danda/classes/g3;

    return-void
.end method

.method public constructor <init>([B)V
    .registers 6

    const-string v0, "malformed data: "

    const/4 v1, 0x1

    .line 1
    :try_start_3
    sget v2, Lcom/android/internal/util/danda/classes/d1;->a:I

    .line 2
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    if-eqz p1, :cond_17

    .line 3
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/e1;->g(Lcom/android/internal/util/danda/classes/t;)Lcom/android/internal/util/danda/classes/e1;

    move-result-object p1
    :try_end_f
    .catch Ljava/lang/ClassCastException; {:try_start_3 .. :try_end_f} :catch_15
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_f} :catch_13

    .line 4
    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/c6;-><init>(Lcom/android/internal/util/danda/classes/e1;)V

    return-void

    :catch_13
    move-exception p1

    goto :goto_1f

    :catch_15
    move-exception p1

    goto :goto_35

    .line 5
    :cond_17
    :try_start_17
    new-instance p1, Ljava/io/IOException;

    const-string v2, "no content found"

    invoke-direct {p1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1f
    .catch Ljava/lang/ClassCastException; {:try_start_17 .. :try_end_1f} :catch_15
    .catch Ljava/lang/IllegalArgumentException; {:try_start_17 .. :try_end_1f} :catch_13

    .line 6
    :goto_1f
    new-instance v2, Lcom/android/internal/util/danda/classes/h;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0, p1, v1}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v2

    .line 7
    :goto_35
    new-instance v2, Lcom/android/internal/util/danda/classes/h;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0, p1, v1}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v2
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    if-ne p1, p0, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    instance-of v0, p1, Lcom/android/internal/util/danda/classes/c6;

    if-nez v0, :cond_a

    const/4 p1, 0x0

    return p1

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/c6;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/m;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/m;->hashCode()I

    move-result v0

    return v0
.end method
