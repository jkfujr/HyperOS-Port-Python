.class public abstract Lcom/android/internal/util/danda/classes/b4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Lcom/android/internal/util/danda/classes/o4;

.field public static b:Lcom/android/internal/util/danda/classes/o4;

.field public static final c:Ljava/util/ArrayList;

.field public static final d:Ljava/util/ArrayList;

.field public static final e:Ljava/security/cert/CertificateFactory;


# direct methods
.method static constructor <clinit>()V
    .registers 12

    const-string v0, "Invalid cert_size: "

    const-string v1, "Using saved Certs for bootloader spoof. keyboxSize: "

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    sput-object v2, Lcom/android/internal/util/danda/classes/b4;->c:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    sput-object v2, Lcom/android/internal/util/danda/classes/b4;->d:Ljava/util/ArrayList;

    const/4 v2, 0x0

    sput-object v2, Lcom/android/internal/util/danda/classes/b4;->e:Ljava/security/cert/CertificateFactory;

    sget-object v2, Lcom/android/internal/util/danda/OemPorts10TUtils;->h:Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/16 v3, 0x8

    const/4 v4, 0x6

    const-string v5, "X.509"

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string v9, "OemPorts10TUtils"

    const-string v10, "Unexpected Keybox size: "

    if-eqz v2, :cond_b7

    :try_start_29
    invoke-static {v5}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    move-result-object v2

    sput-object v2, Lcom/android/internal/util/danda/classes/b4;->e:Ljava/security/cert/CertificateFactory;

    const-string v2, "persist.sys.cert_ecpriv_chunks"

    invoke-static {v2}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    if-eqz v2, :cond_45

    const-string v2, "persist.sys.cert_rsapriv_chunks"

    invoke-static {v2}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_45

    const/4 v2, 0x1

    goto :goto_46

    :catchall_42
    move-exception v0

    goto/16 :goto_af

    :cond_45
    move v2, v5

    :goto_46
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_55

    invoke-static {}, Lcom/android/internal/util/danda/classes/b4;->a()V

    goto/16 :goto_115

    :cond_55
    const-string v2, "persist.sys.cert_size"

    invoke-static {v2}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_6f

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v11
    :try_end_61
    .catchall {:try_start_29 .. :try_end_61} :catchall_42

    if-nez v11, :cond_6f

    :try_start_63
    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5
    :try_end_67
    .catch Ljava/lang/NumberFormatException; {:try_start_63 .. :try_end_67} :catch_68
    .catchall {:try_start_63 .. :try_end_67} :catchall_42

    goto :goto_6f

    :catch_68
    :try_start_68
    invoke-virtual {v0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_6f
    :goto_6f
    if-eq v5, v4, :cond_94

    if-eq v5, v3, :cond_90

    const/16 v0, 0xa

    if-eq v5, v0, :cond_8c

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "Valid sizes: 6, 8, 10"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_97

    :cond_8c
    invoke-static {v8, v8}, Lcom/android/internal/util/danda/classes/m5;->h(II)V

    goto :goto_97

    :cond_90
    invoke-static {v6, v6}, Lcom/android/internal/util/danda/classes/m5;->h(II)V

    goto :goto_97

    :cond_94
    invoke-static {v7, v7}, Lcom/android/internal/util/danda/classes/m5;->h(II)V

    :goto_97
    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_115

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_ae
    .catchall {:try_start_68 .. :try_end_ae} :catchall_42

    goto :goto_115

    :goto_af
    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_115

    :cond_b7
    :try_start_b7
    invoke-static {}, Lcom/android/internal/util/danda/classes/m5;->f()V
    :try_end_ba
    .catchall {:try_start_b7 .. :try_end_ba} :catchall_bb

    goto :goto_c0

    :catchall_bb
    const-string v0, "Failed to load keybox"

    invoke-static {v9, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_c0
    :try_start_c0
    invoke-static {v5}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/b4;->e:Ljava/security/cert/CertificateFactory;

    sget-boolean v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->b:Z

    if-nez v0, :cond_d0

    invoke-static {}, Lcom/android/internal/util/danda/classes/b4;->a()V

    goto :goto_115

    :catchall_ce
    move-exception v0

    goto :goto_10e

    :cond_d0
    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-eq v0, v8, :cond_fb

    if-eq v0, v4, :cond_f7

    if-eq v0, v3, :cond_f3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v1, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "Valid sizes: 2, 3, 4"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_fe

    :cond_f3
    invoke-static {v8, v8}, Lcom/android/internal/util/danda/classes/m5;->i(II)V

    goto :goto_fe

    :cond_f7
    invoke-static {v6, v6}, Lcom/android/internal/util/danda/classes/m5;->i(II)V

    goto :goto_fe

    :cond_fb
    invoke-static {v7, v7}, Lcom/android/internal/util/danda/classes/m5;->i(II)V

    :goto_fe
    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_115

    const-string v0, "OemPorts10TUtils [DEBUG]"

    const-string v1, "Using Certs from L2RhdGEvbG9jYWwvb2VtcG9ydHMxMHQva2V5Ym94LnhtbAo= for bootloader spoof"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_10d
    .catchall {:try_start_c0 .. :try_end_10d} :catchall_ce

    goto :goto_115

    :goto_10e
    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_115
    :goto_115
    return-void
.end method

.method public static a()V
    .registers 2

    const-string v0, "-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEICHghkMqFRmEWc82OlD8FMnarfk19SfC39ceTW28QuVEoAoGCCqGSM49\nAwEHoUQDQgAE6555+EJjWazLKpFMiYbMcK2QZpOCqXMmE/6sy/ghJ0whdJdKKv6l\nuU1/ZtTgZRBmNbxTt6CjpnFYPts+Ea4QFA==\n-----END EC PRIVATE KEY-----\n"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->j(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o4;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/b4;->a:Lcom/android/internal/util/danda/classes/o4;

    const-string v0, "-----BEGIN CERTIFICATE-----\nMIICeDCCAh6gAwIBAgICEAEwCgYIKoZIzj0EAwIwgZgxCzAJBgNVBAYTAlVTMRMw\nEQYDVQQIDApDYWxpZm9ybmlhMRYwFAYDVQQHDA1Nb3VudGFpbiBWaWV3MRUwEwYD\nVQQKDAxHb29nbGUsIEluYy4xEDAOBgNVBAsMB0FuZHJvaWQxMzAxBgNVBAMMKkFu\nZHJvaWQgS2V5c3RvcmUgU29mdHdhcmUgQXR0ZXN0YXRpb24gUm9vdDAeFw0xNjAx\nMTEwMDQ2MDlaFw0yNjAxMDgwMDQ2MDlaMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE\nCAwKQ2FsaWZvcm5pYTEVMBMGA1UECgwMR29vZ2xlLCBJbmMuMRAwDgYDVQQLDAdB\nbmRyb2lkMTswOQYDVQQDDDJBbmRyb2lkIEtleXN0b3JlIFNvZnR3YXJlIEF0dGVz\ndGF0aW9uIEludGVybWVkaWF0ZTBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABOue\nefhCY1msyyqRTImGzHCtkGaTgqlzJhP+rMv4ISdMIXSXSir+pblNf2bU4GUQZjW8\nU7ego6ZxWD7bPhGuEBSjZjBkMB0GA1UdDgQWBBQ//KzWGrE6noEguNUlHMVlux6R\nqTAfBgNVHSMEGDAWgBTIrel3TEXDo88NFhDkeUM6IVowzzASBgNVHRMBAf8ECDAG\nAQH/AgEAMA4GA1UdDwEB/wQEAwIChDAKBggqhkjOPQQDAgNIADBFAiBLipt77oK8\nwDOHri/AiZi03cONqycqRZ9pDMfDktQPjgIhAO7aAV229DLp1IQ7YkyUBO86fMy9\nXvsiu+f+uXc/WT/7\n-----END CERTIFICATE-----\n"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    sget-object v1, Lcom/android/internal/util/danda/classes/b4;->c:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v0, "-----BEGIN CERTIFICATE-----\nMIICizCCAjKgAwIBAgIJAKIFntEOQ1tXMAoGCCqGSM49BAMCMIGYMQswCQYDVQQG\nEwJVUzETMBEGA1UECAwKQ2FsaWZvcm5pYTEWMBQGA1UEBwwNTW91bnRhaW4gVmll\ndzEVMBMGA1UECgwMR29vZ2xlLCBJbmMuMRAwDgYDVQQLDAdBbmRyb2lkMTMwMQYD\nVQQDDCpBbmRyb2lkIEtleXN0b3JlIFNvZnR3YXJlIEF0dGVzdGF0aW9uIFJvb3Qw\nHhcNMTYwMTExMDA0MzUwWhcNMzYwMTA2MDA0MzUwWjCBmDELMAkGA1UEBhMCVVMx\nEzARBgNVBAgMCkNhbGlmb3JuaWExFjAUBgNVBAcMDU1vdW50YWluIFZpZXcxFTAT\nBgNVBAoMDEdvb2dsZSwgSW5jLjEQMA4GA1UECwwHQW5kcm9pZDEzMDEGA1UEAwwq\nQW5kcm9pZCBLZXlzdG9yZSBTb2Z0d2FyZSBBdHRlc3RhdGlvbiBSb290MFkwEwYH\nKoZIzj0CAQYIKoZIzj0DAQcDQgAE7l1ex+HA220Dpn7mthvsTWpdamguD/9/SQ59\ndx9EIm29sa/6FsvHrcV30lacqrewLVQBXT5DKyqO107sSHVBpKNjMGEwHQYDVR0O\nBBYEFMit6XdMRcOjzw0WEOR5QzohWjDPMB8GA1UdIwQYMBaAFMit6XdMRcOjzw0W\nEOR5QzohWjDPMA8GA1UdEwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgKEMAoGCCqG\nSM49BAMCA0cAMEQCIDUho++LNEYenNVg8x1YiSBq3KNlQfYNns6KGYxmSGB7AiBN\nC/NR2TB8fVvaNTQdqEcbY6WFZTytTySn502vQX3xvw==\n-----END CERTIFICATE-----\n"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v0, "-----BEGIN RSA PRIVATE KEY-----\nMIICXQIBAAKBgQDAgyPcVogbuDAgafWwhWHG7r5/BeL1qEIEir6LR752/q7yXPKb\nKvoyABQWAUKZiaFfz8aBXrNjWDwv0vIL5Jgyg92BSxbX4YVBeuVKvClqOm21wAQI\nO2jFVsHwIzmRZBmGTVC3TUCuykhMdzVsiVoMJ1q/rEmdXX0jYvKcXgLocQIDAQAB\nAoGBAL6GCwuZqAKm+xpZQ4p7txUGWwmjbcbpysxr88AsNNfXnpTGYGQo2Ix7f2V3\nwc3qZAdKvo5yht8fCBHclygmCGjeldMu/Ja20IT/JxpfYN78xwPno45uKbqaPF/C\nwoB2tqiWrx0014gozpvdsfNPnJQEQweBKY4gExZyW728mTpBAkEA4cbZJ2RsCRbs\nNoJtWUmDdAwh8bB0xKGlmGfGaXlchdPcRkxbkp6Uv7NODcxQFLEPEzQat/3V9gQU\n0qMmytQcxQJBANpIWZd4XNVjD7D9jFJU+Y5TjhiYOq6ea35qWntdNDdVuSGOvUAy\nDSg4fXifdvohi8wti2il9kGPu+ylF5qzr70CQFD+/DJklVlhbtZTThVFCTKdk6PY\nENvlvbmCKSz3i9i624Agro1X9LcdBThv/p6dsnHKNHejSZnbdvjl7OnA1J0CQBW3\nTPJ8zv+Ls2vwTZ2DRrCaL3DS9EObDyasfgP36dH3fUuRX9KbKCPwOstdUgDghX/y\nqAPpPu6W1iNc6VRCvCECQQCQp0XaiXCyzWSWYDJCKMX4KFb/1mW6moXI1g8bi+5x\nfs0scurgHa2GunZU1M9FrbXx8rMdn4Eiz6XxpVcPmy0l\n-----END RSA PRIVATE KEY-----\n"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->j(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o4;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/b4;->b:Lcom/android/internal/util/danda/classes/o4;

    const-string v0, "-----BEGIN CERTIFICATE-----\nMIICtjCCAh+gAwIBAgICEAAwDQYJKoZIhvcNAQELBQAwYzELMAkGA1UEBhMCVVMx\nEzARBgNVBAgMCkNhbGlmb3JuaWExFjAUBgNVBAcMDU1vdW50YWluIFZpZXcxFTAT\nBgNVBAoMDEdvb2dsZSwgSW5jLjEQMA4GA1UECwwHQW5kcm9pZDAeFw0xNjAxMDQx\nMjQwNTNaFw0zNTEyMzAxMjQwNTNaMHYxCzAJBgNVBAYTAlVTMRMwEQYDVQQIDApD\nYWxpZm9ybmlhMRUwEwYDVQQKDAxHb29nbGUsIEluYy4xEDAOBgNVBAsMB0FuZHJv\naWQxKTAnBgNVBAMMIEFuZHJvaWQgU29mdHdhcmUgQXR0ZXN0YXRpb24gS2V5MIGf\nMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDAgyPcVogbuDAgafWwhWHG7r5/BeL1\nqEIEir6LR752/q7yXPKbKvoyABQWAUKZiaFfz8aBXrNjWDwv0vIL5Jgyg92BSxbX\n4YVBeuVKvClqOm21wAQIO2jFVsHwIzmRZBmGTVC3TUCuykhMdzVsiVoMJ1q/rEmd\nXX0jYvKcXgLocQIDAQABo2YwZDAdBgNVHQ4EFgQU1AwQG/jNY7n3OVK1DhNcpteZ\nk4YwHwYDVR0jBBgwFoAUKfrxrMxN0kyWQCd1trDpMuUH/i4wEgYDVR0TAQH/BAgw\nBgEB/wIBADAOBgNVHQ8BAf8EBAMCAoQwDQYJKoZIhvcNAQELBQADgYEAni1IX4xn\nM9waha2Z11Aj6hTsQ7DhnerCI0YecrUZ3GAi5KVoMWwLVcTmnKItnzpPk2sxixZ4\nFg2Iy9mLzICdhPDCJ+NrOPH90ecXcjFZNX2W88V/q52PlmEmT7K+gbsNSQQiis6f\n9/VCLiVE+iEHElqDtVWtGIL4QBSbnCBjBH8=\n-----END CERTIFICATE-----\n"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    sget-object v1, Lcom/android/internal/util/danda/classes/b4;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v0, "-----BEGIN CERTIFICATE-----\nMIICpzCCAhCgAwIBAgIJAP+U2d2fB8gMMA0GCSqGSIb3DQEBCwUAMGMxCzAJBgNV\nBAYTAlVTMRMwEQYDVQQIDApDYWxpZm9ybmlhMRYwFAYDVQQHDA1Nb3VudGFpbiBW\naWV3MRUwEwYDVQQKDAxHb29nbGUsIEluYy4xEDAOBgNVBAsMB0FuZHJvaWQwHhcN\nMTYwMTA0MTIzMTA4WhcNMzUxMjMwMTIzMTA4WjBjMQswCQYDVQQGEwJVUzETMBEG\nA1UECAwKQ2FsaWZvcm5pYTEWMBQGA1UEBwwNTW91bnRhaW4gVmlldzEVMBMGA1UE\nCgwMR29vZ2xlLCBJbmMuMRAwDgYDVQQLDAdBbmRyb2lkMIGfMA0GCSqGSIb3DQEB\nAQUAA4GNADCBiQKBgQCia63rbi5EYe/VDoLmt5TRdSMfd5tjkWP/96r/C3JHTsAs\nQ+wzfNes7UA+jCigZtX3hwszl94OuE4TQKuvpSe/lWmgMdsGUmX4RFlXYfC78hdL\nt0GAZMAoDo9Sd47b0ke2RekZyOmLw9vCkT/X11DEHTVm+Vfkl5YLCazOkjWFmwID\nAQABo2MwYTAdBgNVHQ4EFgQUKfrxrMxN0kyWQCd1trDpMuUH/i4wHwYDVR0jBBgw\nFoAUKfrxrMxN0kyWQCd1trDpMuUH/i4wDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8B\nAf8EBAMCAoQwDQYJKoZIhvcNAQELBQADgYEAT3LzNlmNDsG5dFsxWfbwjSVJMJ6j\nHBwp0kUtILlNX2S06IDHeHqcOd6os/W/L3BfRxBcxebrTQaZYdKumgf/93y4q+uc\nDyQHXrF/unlx/U1bnt8Uqf7f7XzAiF343ZtkMlbVNZriE/mPzsF83O+kqrJVw4Op\nLvtc9mL1J1IXvmM=\n-----END CERTIFICATE-----\n"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_47

    const-string v0, "OemPorts10TUtils [DEBUG]"

    const-string v1, "Using PREBUILT Certs for bootloader spoof"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_47
    return-void
.end method
