.class public interface abstract Lcom/android/internal/util/danda/classes/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/e;
.implements Lcom/android/internal/util/danda/classes/s3;


# virtual methods
.method public abstract c()Ljava/io/InputStream;
.end method
