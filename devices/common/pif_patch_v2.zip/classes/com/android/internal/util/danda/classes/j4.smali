.class public interface abstract Lcom/android/internal/util/danda/classes/j4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.2"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.3"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.4"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.6"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.7"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.8"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.9"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.17"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.26"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/j4;->a:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.27"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/j4;->b:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.29"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/j4;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.7.2.1.1"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    return-void
.end method
