.class public abstract Lcom/android/internal/util/danda/classes/x2;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lcom/android/internal/util/danda/classes/h3;

.field public b:Lcom/android/internal/util/danda/classes/a3;

.field public c:Lcom/android/internal/util/danda/classes/a3;

.field public d:Ljava/math/BigInteger;

.field public e:I


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/h3;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/android/internal/util/danda/classes/x2;->e:I

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/x2;->a:Lcom/android/internal/util/danda/classes/h3;

    return-void
.end method


# virtual methods
.method public a(Ljava/math/BigInteger;Ljava/math/BigInteger;Z)Lcom/android/internal/util/danda/classes/c3;
    .registers 4

    invoke-virtual {p0, p1}, Lcom/android/internal/util/danda/classes/x2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    invoke-virtual {p0, p2}, Lcom/android/internal/util/danda/classes/x2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p2

    invoke-virtual {p0, p1, p2, p3}, Lcom/android/internal/util/danda/classes/x2;->b(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Z)Lcom/android/internal/util/danda/classes/b3;

    move-result-object p1

    return-object p1
.end method

.method public abstract b(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Z)Lcom/android/internal/util/danda/classes/b3;
.end method

.method public final c(Lcom/android/internal/util/danda/classes/x2;)Z
    .registers 4

    if-eq p0, p1, :cond_35

    if-eqz p1, :cond_33

    iget-object v0, p1, Lcom/android/internal/util/danda/classes/x2;->a:Lcom/android/internal/util/danda/classes/h3;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/x2;->a:Lcom/android/internal/util/danda/classes/h3;

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_33

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v0

    iget-object v1, p1, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_33

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v0

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_33

    goto :goto_35

    :cond_33
    const/4 p1, 0x0

    goto :goto_36

    :cond_35
    :goto_35
    const/4 p1, 0x1

    :goto_36
    return p1
.end method

.method public abstract d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract e()I
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    if-eq p0, p1, :cond_11

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/x2;

    if-eqz v0, :cond_f

    check-cast p1, Lcom/android/internal/util/danda/classes/x2;

    invoke-virtual {p0, p1}, Lcom/android/internal/util/danda/classes/x2;->c(Lcom/android/internal/util/danda/classes/x2;)Z

    move-result p1

    if-eqz p1, :cond_f

    goto :goto_11

    :cond_f
    const/4 p1, 0x0

    goto :goto_12

    :cond_11
    :goto_11
    const/4 p1, 0x1

    :goto_12
    return p1
.end method

.method public abstract f()Lcom/android/internal/util/danda/classes/b3;
.end method

.method public g(Lcom/android/internal/util/danda/classes/c3;)Lcom/android/internal/util/danda/classes/c3;
    .registers 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v1, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    if-ne v0, v2, :cond_9

    return-object v1

    :cond_9
    invoke-virtual/range {p1 .. p1}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v2

    if-eqz v2, :cond_14

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    return-object v1

    :cond_14
    invoke-virtual/range {p1 .. p1}, Lcom/android/internal/util/danda/classes/c3;->f()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    iget-object v2, v1, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/c3;->c()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v3

    iget-boolean v1, v1, Lcom/android/internal/util/danda/classes/c3;->e:Z

    invoke-virtual {v0, v2, v3, v1}, Lcom/android/internal/util/danda/classes/x2;->a(Ljava/math/BigInteger;Ljava/math/BigInteger;Z)Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v2

    if-eqz v2, :cond_34

    goto/16 :goto_26c

    :cond_34
    iget-object v2, v1, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    if-eqz v2, :cond_26c

    move-object v3, v1

    check-cast v3, Lcom/android/internal/util/danda/classes/b3;

    iget-object v4, v3, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    iget-object v5, v3, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    iget-object v6, v3, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    iget-object v7, v3, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v10, "unsupported coordinate system"

    const/4 v11, 0x0

    iget v12, v3, Lcom/android/internal/util/danda/classes/b3;->g:I

    packed-switch v12, :pswitch_data_26e

    iget-object v12, v7, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    iget-object v7, v7, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/c3;->b()I

    move-result v3

    if-eqz v3, :cond_a6

    if-eq v3, v8, :cond_8a

    const/4 v13, 0x2

    if-eq v3, v13, :cond_6d

    const/4 v13, 0x3

    if-eq v3, v13, :cond_6d

    const/4 v13, 0x4

    if-ne v3, v13, :cond_67

    goto :goto_6d

    :cond_67
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_6d
    :goto_6d
    aget-object v3, v5, v11

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v5

    if-nez v5, :cond_a6

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v12, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v7, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    goto :goto_a6

    :cond_8a
    aget-object v3, v5, v11

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v5

    if-nez v5, :cond_a6

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v3, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    invoke-virtual {v6, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v12, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v7, v13}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    :cond_a6
    :goto_a6
    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v12}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v7}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    goto/16 :goto_15f

    :pswitch_bc
    iget-object v3, v7, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    iget-object v12, v7, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    iget v7, v7, Lcom/android/internal/util/danda/classes/x2;->e:I

    if-ne v7, v9, :cond_11c

    aget-object v5, v5, v11

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v7

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v13

    if-eqz v13, :cond_e4

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    if-nez v7, :cond_de

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v12, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    :cond_de
    invoke-virtual {v3, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    goto/16 :goto_15f

    :cond_e4
    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    if-eqz v7, :cond_ff

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v5, v6}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v5, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v5, v12}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    goto :goto_113

    :cond_ff
    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v7}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    invoke-virtual {v6, v5}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v5, v6, v3, v7}, Lcom/android/internal/util/danda/classes/a3;->k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v4, v12, v13}, Lcom/android/internal/util/danda/classes/a3;->o(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    :goto_113
    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    goto :goto_15f

    :cond_11c
    invoke-virtual {v6, v4}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    invoke-virtual {v13, v6}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    if-eqz v7, :cond_14b

    if-ne v7, v8, :cond_145

    aget-object v5, v5, v11

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v7

    if-nez v7, :cond_14b

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v5, v7}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v6, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v3, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v12, v7}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    goto :goto_14b

    :cond_145
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_14b
    :goto_14b
    invoke-virtual {v4, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v12}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    :goto_15f
    if-eqz v3, :cond_264

    iget-object v3, v2, Lcom/android/internal/util/danda/classes/x2;->d:Ljava/math/BigInteger;

    if-eqz v3, :cond_26c

    sget-object v4, Lcom/android/internal/util/danda/classes/u2;->b:Ljava/math/BigInteger;

    invoke-virtual {v3, v4}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_26c

    invoke-virtual {v3}, Ljava/math/BigInteger;->abs()Ljava/math/BigInteger;

    move-result-object v4

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v2

    invoke-virtual {v4}, Ljava/math/BigInteger;->bitLength()I

    move-result v5

    if-lez v5, :cond_197

    invoke-virtual {v4, v11}, Ljava/math/BigInteger;->testBit(I)Z

    move-result v6

    if-eqz v6, :cond_182

    move-object v2, v1

    :cond_182
    move-object v7, v1

    move v6, v8

    :goto_184
    if-ge v6, v5, :cond_197

    invoke-virtual {v7}, Lcom/android/internal/util/danda/classes/c3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v7

    invoke-virtual {v4, v6}, Ljava/math/BigInteger;->testBit(I)Z

    move-result v12

    if-eqz v12, :cond_194

    invoke-virtual {v2, v7}, Lcom/android/internal/util/danda/classes/c3;->a(Lcom/android/internal/util/danda/classes/c3;)Lcom/android/internal/util/danda/classes/c3;

    move-result-object v2

    :cond_194
    add-int/lit8 v6, v6, 0x1

    goto :goto_184

    :cond_197
    invoke-virtual {v3}, Ljava/math/BigInteger;->signum()I

    move-result v3

    if-gez v3, :cond_25d

    check-cast v2, Lcom/android/internal/util/danda/classes/b3;

    iget v3, v2, Lcom/android/internal/util/danda/classes/b3;->g:I

    iget-object v4, v2, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    packed-switch v3, :pswitch_data_274

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v3

    if-eqz v3, :cond_1ae

    goto/16 :goto_25d

    :cond_1ae
    iget-object v6, v2, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    iget v3, v6, Lcom/android/internal/util/danda/classes/x2;->e:I

    if-eqz v3, :cond_1c8

    new-instance v3, Lcom/android/internal/util/danda/classes/b3;

    iget-object v7, v2, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->l()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    iget-object v9, v2, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    iget-boolean v10, v2, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v11, 0x1

    move-object v5, v3

    invoke-direct/range {v5 .. v11}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    :goto_1c5
    move-object v2, v3

    goto/16 :goto_25d

    :cond_1c8
    new-instance v3, Lcom/android/internal/util/danda/classes/b3;

    iget-object v7, v2, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->l()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    iget-boolean v9, v2, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v10, 0x1

    move-object v5, v3

    invoke-direct/range {v5 .. v10}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto :goto_1c5

    :pswitch_1d8
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v3

    if-eqz v3, :cond_1e0

    goto/16 :goto_25d

    :cond_1e0
    iget-object v14, v2, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v14}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v3

    if-eqz v3, :cond_1ea

    goto/16 :goto_25d

    :cond_1ea
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/c3;->b()I

    move-result v3

    if-eqz v3, :cond_249

    iget-object v5, v2, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    if-eq v3, v8, :cond_22e

    const/4 v6, 0x5

    if-eq v3, v6, :cond_21b

    if-ne v3, v9, :cond_215

    aget-object v3, v5, v11

    new-instance v5, Lcom/android/internal/util/danda/classes/b3;

    iget-object v13, v2, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    invoke-virtual {v4, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v15

    new-array v4, v8, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v3, v4, v11

    iget-boolean v2, v2, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/16 v18, 0x0

    move-object v12, v5

    move-object/from16 v16, v4

    move/from16 v17, v2

    invoke-direct/range {v12 .. v18}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    :goto_213
    move-object v2, v5

    goto :goto_25d

    :cond_215
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_21b
    new-instance v3, Lcom/android/internal/util/danda/classes/b3;

    iget-object v13, v2, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->b()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v15

    iget-boolean v2, v2, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/16 v17, 0x0

    move-object v12, v3

    move/from16 v16, v2

    invoke-direct/range {v12 .. v17}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto :goto_1c5

    :cond_22e
    aget-object v3, v5, v11

    new-instance v5, Lcom/android/internal/util/danda/classes/b3;

    iget-object v13, v2, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    invoke-virtual {v4, v14}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v15

    new-array v4, v8, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v3, v4, v11

    iget-boolean v2, v2, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/16 v18, 0x0

    move-object v12, v5

    move-object/from16 v16, v4

    move/from16 v17, v2

    invoke-direct/range {v12 .. v18}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto :goto_213

    :cond_249
    new-instance v3, Lcom/android/internal/util/danda/classes/b3;

    iget-object v13, v2, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    invoke-virtual {v4, v14}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v15

    iget-boolean v2, v2, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/16 v17, 0x0

    move-object v12, v3

    move/from16 v16, v2

    invoke-direct/range {v12 .. v17}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_1c5

    :cond_25d
    :goto_25d
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v2

    if-nez v2, :cond_264

    goto :goto_26c

    :cond_264
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Invalid point coordinates"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_26c
    :goto_26c
    return-object v1

    nop

    :pswitch_data_26e
    .packed-switch 0x0
        :pswitch_bc
    .end packed-switch

    :pswitch_data_274
    .packed-switch 0x0
        :pswitch_1d8
    .end packed-switch
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x2;->a:Lcom/android/internal/util/danda/classes/h3;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v1}, Ljava/math/BigInteger;->hashCode()I

    move-result v1

    const/16 v2, 0x8

    invoke-static {v1, v2}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v1

    xor-int/2addr v0, v1

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v1}, Ljava/math/BigInteger;->hashCode()I

    move-result v1

    const/16 v2, 0x10

    invoke-static {v1, v2}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method
