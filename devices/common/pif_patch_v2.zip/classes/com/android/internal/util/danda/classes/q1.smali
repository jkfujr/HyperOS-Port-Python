.class public Lcom/android/internal/util/danda/classes/q1;
.super Lcom/android/internal/util/danda/classes/b;
.source "SourceFile"


# direct methods
.method public static o(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/q1;
    .registers 6

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/q1;

    if-eqz v0, :cond_d

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/q1;->p(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q1;

    move-result-object p0

    return-object p0

    :cond_d
    check-cast p0, Lcom/android/internal/util/danda/classes/p;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object p0

    array-length v0, p0

    const/4 v1, 0x1

    if-lt v0, v1, :cond_2b

    const/4 v0, 0x0

    aget-byte v2, p0, v0

    array-length v3, p0

    sub-int/2addr v3, v1

    new-array v4, v3, [B

    if-eqz v3, :cond_25

    array-length v3, p0

    sub-int/2addr v3, v1

    invoke-static {p0, v1, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_25
    new-instance p0, Lcom/android/internal/util/danda/classes/q1;

    invoke-direct {p0, v2, v4}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    return-object p0

    :cond_2b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "truncated BIT STRING detected"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static p(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q1;
    .registers 4

    if-eqz p0, :cond_51

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/q1;

    if-eqz v0, :cond_7

    goto :goto_51

    :cond_7
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/m2;

    if-eqz v0, :cond_17

    new-instance v0, Lcom/android/internal/util/danda/classes/q1;

    check-cast p0, Lcom/android/internal/util/danda/classes/m2;

    iget v1, p0, Lcom/android/internal/util/danda/classes/b;->n:I

    iget-object p0, p0, Lcom/android/internal/util/danda/classes/b;->m:[B

    invoke-direct {v0, v1, p0}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    return-object v0

    :cond_17
    instance-of v0, p0, [B

    if-eqz v0, :cond_3d

    :try_start_1b
    check-cast p0, [B

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    check-cast p0, Lcom/android/internal/util/danda/classes/q1;
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_23} :catch_24

    return-object p0

    :catch_24
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "encoding error in getInstance: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "illegal object in getInstance: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_51
    :goto_51
    check-cast p0, Lcom/android/internal/util/danda/classes/q1;

    return-object p0
.end method


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 8

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/b;->m:[B

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object v1

    const/4 v2, 0x1

    iget v3, p0, Lcom/android/internal/util/danda/classes/b;->n:I

    if-lez v3, :cond_16

    array-length v0, v0

    sub-int/2addr v0, v2

    aget-byte v4, v1, v0

    const/16 v5, 0xff

    shl-int/2addr v5, v3

    and-int/2addr v4, v5

    int-to-byte v4, v4

    aput-byte v4, v1, v0

    :cond_16
    array-length v0, v1

    add-int/lit8 v4, v0, 0x1

    new-array v4, v4, [B

    int-to-byte v3, v3

    const/4 v5, 0x0

    aput-byte v3, v4, v5

    invoke-static {v1, v5, v4, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v0, 0x3

    invoke-virtual {p1, v0, v4}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    return-void
.end method

.method public final i()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/b;->m:[B

    array-length v1, v0

    add-int/lit8 v1, v1, 0x1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    array-length v0, v0

    add-int/2addr v1, v0

    add-int/lit8 v1, v1, 0x1

    return v1
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
