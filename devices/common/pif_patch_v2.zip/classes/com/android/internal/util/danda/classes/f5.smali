.class public final Lcom/android/internal/util/danda/classes/f5;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Ljava/math/BigInteger;

.field public n:Ljava/math/BigInteger;

.field public o:Ljava/math/BigInteger;

.field public p:Ljava/math/BigInteger;

.field public q:Ljava/math/BigInteger;

.field public r:Ljava/math/BigInteger;

.field public s:Ljava/math/BigInteger;

.field public t:Ljava/math/BigInteger;

.field public u:Ljava/math/BigInteger;

.field public v:Lcom/android/internal/util/danda/classes/u;


# direct methods
.method public static g(Lcom/android/internal/util/danda/classes/u;)Lcom/android/internal/util/danda/classes/f5;
    .registers 5

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/f5;

    if-eqz v0, :cond_7

    check-cast p0, Lcom/android/internal/util/danda/classes/f5;

    return-object p0

    :cond_7
    new-instance v0, Lcom/android/internal/util/danda/classes/f5;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->v:Lcom/android/internal/util/danda/classes/u;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v1}, Ljava/math/BigInteger;->intValue()I

    move-result v2

    if-eqz v2, :cond_37

    invoke-virtual {v1}, Ljava/math/BigInteger;->intValue()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_2f

    goto :goto_37

    :cond_2f
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "wrong version for RSA private key"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_37
    :goto_37
    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->m:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->n:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->o:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->p:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->q:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->r:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->s:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->t:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/f5;->u:Ljava/math/BigInteger;

    invoke-interface {p0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_a7

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/android/internal/util/danda/classes/u;

    iput-object p0, v0, Lcom/android/internal/util/danda/classes/f5;->v:Lcom/android/internal/util/danda/classes/u;

    :cond_a7
    return-object v0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->m:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->n:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->o:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->p:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->q:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->r:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->s:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->t:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/f5;->u:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/f5;->v:Lcom/android/internal/util/danda/classes/u;

    if-eqz v2, :cond_67

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_67
    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method
