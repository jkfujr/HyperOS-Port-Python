.class public abstract Lcom/android/internal/util/danda/classes/b1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/c1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/android/internal/util/danda/classes/c1;

    invoke-direct {v0}, Lcom/android/internal/util/danda/classes/c1;-><init>()V

    sput-object v0, Lcom/android/internal/util/danda/classes/b1;->a:Lcom/android/internal/util/danda/classes/c1;

    return-void
.end method
