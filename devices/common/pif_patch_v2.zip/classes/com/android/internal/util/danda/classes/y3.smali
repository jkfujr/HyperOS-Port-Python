.class public final Lcom/android/internal/util/danda/classes/y3;
.super Ljava/security/cert/CertificateException;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Throwable;


# virtual methods
.method public final getCause()Ljava/lang/Throwable;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y3;->a:Ljava/lang/Throwable;

    return-object v0
.end method
