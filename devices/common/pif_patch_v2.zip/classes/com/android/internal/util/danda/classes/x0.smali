.class public final Lcom/android/internal/util/danda/classes/x0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/x;


# instance fields
.field public final synthetic m:I

.field public final n:Lcom/android/internal/util/danda/classes/y;


# direct methods
.method public synthetic constructor <init>(ILcom/android/internal/util/danda/classes/y;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/android/internal/util/danda/classes/x0;->m:I

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/x0;->n:Lcom/android/internal/util/danda/classes/y;

    return-void
.end method


# virtual methods
.method public final b()Lcom/android/internal/util/danda/classes/t;
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x0;->n:Lcom/android/internal/util/danda/classes/y;

    iget v1, p0, Lcom/android/internal/util/danda/classes/x0;->m:I

    packed-switch v1, :pswitch_data_1c

    new-instance v1, Lcom/android/internal/util/danda/classes/e2;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/android/internal/util/danda/classes/e2;-><init>(Lcom/android/internal/util/danda/classes/f;)V

    return-object v1

    :pswitch_11
    new-instance v1, Lcom/android/internal/util/danda/classes/w0;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v0

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/w;-><init>(Lcom/android/internal/util/danda/classes/f;Z)V

    return-object v1

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method

.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    iget v0, p0, Lcom/android/internal/util/danda/classes/x0;->m:I

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_26

    :try_start_6
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/x0;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_a} :catch_b

    return-object v0

    :catch_b
    move-exception v0

    new-instance v2, Lcom/android/internal/util/danda/classes/s;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3, v0, v1}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v2

    :pswitch_16
    :try_start_16
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/x0;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_1a
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_1a} :catch_1b

    return-object v0

    :catch_1b
    move-exception v0

    new-instance v2, Lcom/android/internal/util/danda/classes/s;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3, v0, v1}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v2

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_16
    .end packed-switch
.end method
