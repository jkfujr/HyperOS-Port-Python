.class public final Lcom/android/internal/util/danda/classes/n2;
.super Lcom/android/internal/util/danda/classes/a0;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 6

    iget v0, p0, Lcom/android/internal/util/danda/classes/a0;->m:I

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/a0;->o:Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/t;->m()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    iget-boolean v2, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    const/16 v3, 0xa0

    if-eqz v2, :cond_20

    invoke-virtual {p1, v3, v0}, Lcom/android/internal/util/danda/classes/f;->l(II)V

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/t;->i()I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->j(I)V

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->k(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_2f

    :cond_20
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/t;->k()Z

    move-result v2

    if-eqz v2, :cond_27

    goto :goto_29

    :cond_27
    const/16 v3, 0x80

    :goto_29
    invoke-virtual {p1, v3, v0}, Lcom/android/internal/util/danda/classes/f;->l(II)V

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->i(Lcom/android/internal/util/danda/classes/t;)V

    :goto_2f
    return-void
.end method

.method public final i()I
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/a0;->m:I

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/a0;->o:Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/t;->m()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/t;->i()I

    move-result v1

    iget-boolean v2, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    if-eqz v2, :cond_1f

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->b(I)I

    move-result v0

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v2

    add-int/2addr v2, v0

    add-int/2addr v2, v1

    return v2

    :cond_1f
    add-int/lit8 v1, v1, -0x1

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->b(I)I

    move-result v0

    add-int/2addr v0, v1

    return v0
.end method

.method public final k()Z
    .registers 2

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    return v0

    :cond_6
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/a0;->o:Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/t;->m()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/t;->k()Z

    move-result v0

    return v0
.end method
