.class public final Lcom/android/internal/util/danda/classes/o3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/h3;


# instance fields
.field public final a:Lcom/android/internal/util/danda/classes/h3;

.field public final b:Lcom/android/internal/util/danda/classes/j3;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/a5;Lcom/android/internal/util/danda/classes/j3;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/o3;->a:Lcom/android/internal/util/danda/classes/h3;

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/o3;->b:Lcom/android/internal/util/danda/classes/j3;

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/o3;->a:Lcom/android/internal/util/danda/classes/h3;

    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/h3;->a()I

    move-result v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/o3;->b:Lcom/android/internal/util/danda/classes/j3;

    iget-object v1, v1, Lcom/android/internal/util/danda/classes/j3;->a:[I

    array-length v2, v1

    add-int/lit8 v2, v2, -0x1

    aget v1, v1, v2

    mul-int/2addr v0, v1

    return v0
.end method

.method public final b()Ljava/math/BigInteger;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/o3;->a:Lcom/android/internal/util/danda/classes/h3;

    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/h3;->b()Ljava/math/BigInteger;

    move-result-object v0

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/android/internal/util/danda/classes/o3;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/o3;

    iget-object v1, p1, Lcom/android/internal/util/danda/classes/o3;->a:Lcom/android/internal/util/danda/classes/h3;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/o3;->a:Lcom/android/internal/util/danda/classes/h3;

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_21

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/o3;->b:Lcom/android/internal/util/danda/classes/j3;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/o3;->b:Lcom/android/internal/util/danda/classes/j3;

    invoke-virtual {v1, p1}, Lcom/android/internal/util/danda/classes/j3;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_21

    goto :goto_22

    :cond_21
    move v0, v2

    :goto_22
    return v0
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/o3;->a:Lcom/android/internal/util/danda/classes/h3;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/o3;->b:Lcom/android/internal/util/danda/classes/j3;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/j3;->hashCode()I

    move-result v1

    const/16 v2, 0x10

    invoke-static {v1, v2}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method
