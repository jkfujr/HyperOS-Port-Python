.class public final Lcom/android/internal/util/danda/classes/x3;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:Ljava/util/HashMap;


# instance fields
.field public final a:Lcom/android/internal/util/danda/classes/j1;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/android/internal/util/danda/classes/x3;->b:Ljava/util/HashMap;

    sget-object v1, Lcom/android/internal/util/danda/classes/h6;->f:Lcom/android/internal/util/danda/classes/o;

    const-string v2, "ECDSA"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lcom/android/internal/util/danda/classes/v4;->a:Lcom/android/internal/util/danda/classes/o;

    const-string v2, "RSA"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lcom/android/internal/util/danda/classes/h6;->k:Lcom/android/internal/util/danda/classes/o;

    const-string v2, "DSA"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/android/internal/util/danda/classes/j1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/x3;->a:Lcom/android/internal/util/danda/classes/j1;

    return-void
.end method


# virtual methods
.method public final a(Lcom/android/internal/util/danda/classes/d0;)Ljava/security/KeyFactory;
    .registers 5

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/x3;->a:Lcom/android/internal/util/danda/classes/j1;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/d0;->m:Lcom/android/internal/util/danda/classes/o;

    sget-object v1, Lcom/android/internal/util/danda/classes/x3;->b:Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_10

    iget-object v1, p1, Lcom/android/internal/util/danda/classes/o;->m:Ljava/lang/String;

    :cond_10
    :try_start_10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object p1
    :try_end_17
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_10 .. :try_end_17} :catch_18

    return-object p1

    :catch_18
    move-exception p1

    const-string v2, "ECDSA"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2b

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p1, "EC"

    invoke-static {p1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object p1

    return-object p1

    :cond_2b
    throw p1
.end method

.method public final b(Lcom/android/internal/util/danda/classes/b5;)Ljava/security/PrivateKey;
    .registers 5

    :try_start_0
    iget-object v0, p1, Lcom/android/internal/util/danda/classes/b5;->n:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {p0, v0}, Lcom/android/internal/util/danda/classes/x3;->a(Lcom/android/internal/util/danda/classes/d0;)Ljava/security/KeyFactory;

    move-result-object v0

    new-instance v1, Ljava/security/spec/PKCS8EncodedKeySpec;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/m;->e()[B

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/security/spec/PKCS8EncodedKeySpec;-><init>([B)V

    invoke-virtual {v0, v1}, Ljava/security/KeyFactory;->generatePrivate(Ljava/security/spec/KeySpec;)Ljava/security/PrivateKey;

    move-result-object p1
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_13} :catch_14

    return-object p1

    :catch_14
    move-exception p1

    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "unable to convert key pair: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x4

    invoke-direct {v0, v1, p1, v2}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0
.end method
