.class public final Lcom/android/internal/util/danda/classes/m3;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/d;


# instance fields
.field public final m:Lcom/android/internal/util/danda/classes/e;

.field public final n:I


# direct methods
.method public constructor <init>(ILcom/android/internal/util/danda/classes/m;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/m3;->m:Lcom/android/internal/util/danda/classes/e;

    iput p1, p0, Lcom/android/internal/util/danda/classes/m3;->n:I

    return-void
.end method

.method public static g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/m3;
    .registers 7

    if-eqz p0, :cond_107

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/m3;

    if-eqz v0, :cond_8

    goto/16 :goto_107

    :cond_8
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/a0;

    if-eqz v0, :cond_dc

    move-object v0, p0

    check-cast v0, Lcom/android/internal/util/danda/classes/a0;

    iget v1, v0, Lcom/android/internal/util/danda/classes/a0;->m:I

    const/4 v2, 0x0

    packed-switch v1, :pswitch_data_10a

    goto/16 :goto_dc

    :pswitch_17
    new-instance p0, Lcom/android/internal/util/danda/classes/m3;

    sget-object v2, Lcom/android/internal/util/danda/classes/o;->o:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    instance-of v3, v2, Lcom/android/internal/util/danda/classes/o;

    if-eqz v3, :cond_28

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/o;->p(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/o;

    move-result-object v0

    goto :goto_49

    :cond_28
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/p;->n(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/p;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v0

    new-instance v2, Lcom/android/internal/util/danda/classes/n;

    invoke-direct {v2, v0}, Lcom/android/internal/util/danda/classes/n;-><init>([B)V

    sget-object v3, Lcom/android/internal/util/danda/classes/o;->o:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v3, v2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/o;

    if-nez v2, :cond_48

    new-instance v2, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v2, v0}, Lcom/android/internal/util/danda/classes/o;-><init>([B)V

    :cond_48
    move-object v0, v2

    :goto_49
    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/m3;-><init>(ILcom/android/internal/util/danda/classes/m;)V

    return-object p0

    :pswitch_4d
    new-instance p0, Lcom/android/internal/util/danda/classes/m3;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    instance-of v3, v0, Lcom/android/internal/util/danda/classes/p;

    if-eqz v3, :cond_5c

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/p;->n(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/p;

    move-result-object v0

    goto :goto_81

    :cond_5c
    invoke-static {v0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v3

    new-array v3, v3, [Lcom/android/internal/util/danda/classes/p;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object v0

    :goto_6a
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v4

    if-eqz v4, :cond_7c

    add-int/lit8 v4, v2, 0x1

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/android/internal/util/danda/classes/p;

    aput-object v5, v3, v2

    move v2, v4

    goto :goto_6a

    :cond_7c
    new-instance v0, Lcom/android/internal/util/danda/classes/s0;

    invoke-direct {v0, v3}, Lcom/android/internal/util/danda/classes/s0;-><init>([Lcom/android/internal/util/danda/classes/p;)V

    :goto_81
    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/m3;-><init>(ILcom/android/internal/util/danda/classes/m;)V

    return-object p0

    :pswitch_85
    new-instance p0, Lcom/android/internal/util/danda/classes/m3;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/x1;->o(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/x1;

    move-result-object v0

    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/m3;-><init>(ILcom/android/internal/util/danda/classes/m;)V

    return-object p0

    :pswitch_8f
    new-instance p0, Lcom/android/internal/util/danda/classes/m3;

    invoke-static {v0, v2}, Lcom/android/internal/util/danda/classes/u;->n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;

    move-result-object v0

    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/m3;-><init>(ILcom/android/internal/util/danda/classes/m;)V

    return-object p0

    :pswitch_99
    new-instance p0, Lcom/android/internal/util/danda/classes/m3;

    sget-object v2, Lcom/android/internal/util/danda/classes/x5;->q:Lcom/android/internal/util/danda/classes/n0;

    const/4 v2, 0x1

    invoke-static {v0, v2}, Lcom/android/internal/util/danda/classes/u;->n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/x5;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/x5;

    move-result-object v0

    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/m3;-><init>(ILcom/android/internal/util/danda/classes/m;)V

    return-object p0

    :pswitch_aa
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "unknown tag: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_be
    new-instance p0, Lcom/android/internal/util/danda/classes/m3;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/x1;->o(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/x1;

    move-result-object v0

    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/m3;-><init>(ILcom/android/internal/util/danda/classes/m;)V

    return-object p0

    :pswitch_c8
    new-instance p0, Lcom/android/internal/util/danda/classes/m3;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/x1;->o(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/x1;

    move-result-object v0

    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/m3;-><init>(ILcom/android/internal/util/danda/classes/m;)V

    return-object p0

    :pswitch_d2
    new-instance p0, Lcom/android/internal/util/danda/classes/m3;

    invoke-static {v0, v2}, Lcom/android/internal/util/danda/classes/u;->n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;

    move-result-object v0

    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/m3;-><init>(ILcom/android/internal/util/danda/classes/m;)V

    return-object p0

    :cond_dc
    :goto_dc
    instance-of v0, p0, [B

    if-eqz v0, :cond_f3

    :try_start_e0
    check-cast p0, [B

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/m3;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/m3;

    move-result-object p0
    :try_end_ea
    .catch Ljava/io/IOException; {:try_start_e0 .. :try_end_ea} :catch_eb

    return-object p0

    :catch_eb
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "unable to parse encoded general name"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_f3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "unknown object in getInstance: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_107
    :goto_107
    check-cast p0, Lcom/android/internal/util/danda/classes/m3;

    return-object p0

    :pswitch_data_10a
    .packed-switch 0x0
        :pswitch_d2
        :pswitch_c8
        :pswitch_be
        :pswitch_aa
        :pswitch_99
        :pswitch_8f
        :pswitch_85
        :pswitch_4d
        :pswitch_17
    .end packed-switch
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/m3;->m:Lcom/android/internal/util/danda/classes/e;

    iget v1, p0, Lcom/android/internal/util/danda/classes/m3;->n:I

    const/4 v2, 0x4

    if-ne v1, v2, :cond_e

    new-instance v2, Lcom/android/internal/util/danda/classes/g2;

    const/4 v3, 0x1

    invoke-direct {v2, v3, v1, v0}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    return-object v2

    :cond_e
    new-instance v2, Lcom/android/internal/util/danda/classes/g2;

    const/4 v3, 0x0

    invoke-direct {v2, v3, v1, v0}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    return-object v2
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    iget v1, p0, Lcom/android/internal/util/danda/classes/m3;->n:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    const-string v2, ": "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/m3;->m:Lcom/android/internal/util/danda/classes/e;

    const/4 v3, 0x1

    if-eq v1, v3, :cond_31

    const/4 v3, 0x2

    if-eq v1, v3, :cond_31

    const/4 v3, 0x4

    if-eq v1, v3, :cond_25

    const/4 v3, 0x6

    if-eq v1, v3, :cond_31

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_3e

    :cond_25
    invoke-static {v2}, Lcom/android/internal/util/danda/classes/x5;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/x5;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/x5;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_3e

    :cond_31
    invoke-static {v2}, Lcom/android/internal/util/danda/classes/x1;->n(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/x1;

    move-result-object v1

    iget-object v1, v1, Lcom/android/internal/util/danda/classes/x1;->m:[B

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/p5;->a([B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :goto_3e
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
