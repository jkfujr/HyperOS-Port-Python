.class public final Lcom/android/internal/util/danda/classes/w2;
.super Lcom/android/internal/util/danda/classes/x2;
.source "SourceFile"


# instance fields
.field public f:Ljava/math/BigInteger;

.field public g:Ljava/math/BigInteger;

.field public h:Lcom/android/internal/util/danda/classes/b3;


# virtual methods
.method public final b(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Z)Lcom/android/internal/util/danda/classes/b3;
    .registers 11

    new-instance v6, Lcom/android/internal/util/danda/classes/b3;

    const/4 v5, 0x1

    move-object v0, v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    invoke-direct/range {v0 .. v5}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    return-object v6
.end method

.method public final d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;
    .registers 5

    new-instance v0, Lcom/android/internal/util/danda/classes/z2;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/w2;->f:Ljava/math/BigInteger;

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/w2;->g:Ljava/math/BigInteger;

    invoke-direct {v0, v1, v2, p1}, Lcom/android/internal/util/danda/classes/z2;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    return-object v0
.end method

.method public final e()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w2;->f:Ljava/math/BigInteger;

    invoke-virtual {v0}, Ljava/math/BigInteger;->bitLength()I

    move-result v0

    return v0
.end method

.method public final f()Lcom/android/internal/util/danda/classes/b3;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w2;->h:Lcom/android/internal/util/danda/classes/b3;

    return-object v0
.end method

.method public final g(Lcom/android/internal/util/danda/classes/c3;)Lcom/android/internal/util/danda/classes/c3;
    .registers 11

    iget-object v0, p1, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    if-eq p0, v0, :cond_4d

    iget v0, p0, Lcom/android/internal/util/danda/classes/x2;->e:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_4d

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v0

    if-nez v0, :cond_4d

    iget-object v0, p1, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    iget v0, v0, Lcom/android/internal/util/danda/classes/x2;->e:I

    if-eq v0, v1, :cond_1c

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1c

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1c

    goto :goto_4d

    :cond_1c
    new-instance v0, Lcom/android/internal/util/danda/classes/b3;

    iget-object v1, p1, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/w2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    iget-object v1, p1, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/w2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    const/4 v1, 0x1

    new-array v6, v1, [Lcom/android/internal/util/danda/classes/a3;

    iget-object v1, p1, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/w2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    aput-object v1, v6, v2

    iget-boolean v7, p1, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v8, 0x1

    move-object v2, v0

    move-object v3, p0

    invoke-direct/range {v2 .. v8}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    return-object v0

    :cond_4d
    :goto_4d
    invoke-super {p0, p1}, Lcom/android/internal/util/danda/classes/x2;->g(Lcom/android/internal/util/danda/classes/c3;)Lcom/android/internal/util/danda/classes/c3;

    move-result-object p1

    return-object p1
.end method
