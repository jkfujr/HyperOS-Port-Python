.class public final Lcom/android/internal/util/danda/classes/r;
.super Lcom/android/internal/util/danda/classes/f;
.source "SourceFile"


# instance fields
.field public b:Z


# virtual methods
.method public final g(I)V
    .registers 3

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/r;->b:Z

    if-eqz v0, :cond_8

    const/4 p1, 0x0

    iput-boolean p1, p0, Lcom/android/internal/util/danda/classes/r;->b:Z

    goto :goto_b

    :cond_8
    invoke-super {p0, p1}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    :goto_b
    return-void
.end method
