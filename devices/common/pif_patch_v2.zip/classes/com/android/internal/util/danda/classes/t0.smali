.class public final Lcom/android/internal/util/danda/classes/t0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/q;


# instance fields
.field public final synthetic m:I

.field public final n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Lcom/android/internal/util/danda/classes/t0;->m:I

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/t0;->n:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final b()Lcom/android/internal/util/danda/classes/t;
    .registers 8

    iget v0, p0, Lcom/android/internal/util/danda/classes/t0;->m:I

    packed-switch v0, :pswitch_data_36

    new-instance v0, Lcom/android/internal/util/danda/classes/a2;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/t0;->n:Ljava/lang/Object;

    check-cast v1, Lcom/android/internal/util/danda/classes/q2;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    return-object v0

    :pswitch_13
    new-instance v0, Lcom/android/internal/util/danda/classes/s0;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/t0;->c()Ljava/io/InputStream;

    move-result-object v1

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v3, 0x1000

    new-array v4, v3, [B

    :goto_22
    const/4 v5, 0x0

    invoke-virtual {v1, v4, v5, v3}, Ljava/io/InputStream;->read([BII)I

    move-result v6

    if-ltz v6, :cond_2d

    invoke-virtual {v2, v4, v5, v6}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_22

    :cond_2d
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    return-object v0

    nop

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_13
    .end packed-switch
.end method

.method public final c()Ljava/io/InputStream;
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/t0;->n:Ljava/lang/Object;

    iget v1, p0, Lcom/android/internal/util/danda/classes/t0;->m:I

    packed-switch v1, :pswitch_data_12

    check-cast v0, Lcom/android/internal/util/danda/classes/q2;

    return-object v0

    :pswitch_a
    new-instance v1, Lcom/android/internal/util/danda/classes/m1;

    check-cast v0, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {v1, v0}, Lcom/android/internal/util/danda/classes/m1;-><init>(Lcom/android/internal/util/danda/classes/y;)V

    return-object v1

    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_a
    .end packed-switch
.end method

.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 6

    iget v0, p0, Lcom/android/internal/util/danda/classes/t0;->m:I

    const/4 v1, 0x0

    const-string v2, "IOException converting stream to byte array: "

    packed-switch v0, :pswitch_data_40

    :try_start_8
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/t0;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_c} :catch_d

    return-object v0

    :catch_d
    move-exception v0

    new-instance v3, Lcom/android/internal/util/danda/classes/s;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2, v0, v1}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v3

    :pswitch_24
    :try_start_24
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/t0;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_28
    .catch Ljava/io/IOException; {:try_start_24 .. :try_end_28} :catch_29

    return-object v0

    :catch_29
    move-exception v0

    new-instance v3, Lcom/android/internal/util/danda/classes/s;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2, v0, v1}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v3

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_24
    .end packed-switch
.end method
