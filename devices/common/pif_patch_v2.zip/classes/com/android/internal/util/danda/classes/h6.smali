.class public interface abstract Lcom/android/internal/util/danda/classes/h6;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;

.field public static final d:Lcom/android/internal/util/danda/classes/o;

.field public static final e:Lcom/android/internal/util/danda/classes/o;

.field public static final f:Lcom/android/internal/util/danda/classes/o;

.field public static final g:Lcom/android/internal/util/danda/classes/o;

.field public static final h:Lcom/android/internal/util/danda/classes/o;

.field public static final i:Lcom/android/internal/util/danda/classes/o;

.field public static final j:Lcom/android/internal/util/danda/classes/o;

.field public static final k:Lcom/android/internal/util/danda/classes/o;

.field public static final l:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 13

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.840.10045"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v3, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v3, Lcom/android/internal/util/danda/classes/h6;->a:Lcom/android/internal/util/danda/classes/o;

    new-instance v3, Lcom/android/internal/util/danda/classes/o;

    const-string v4, "2"

    invoke-direct {v3, v1, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v3, Lcom/android/internal/util/danda/classes/h6;->b:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v5, "3.1"

    invoke-direct {v1, v3, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v5, "3.2"

    invoke-direct {v1, v3, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/h6;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v5, "3.3"

    invoke-direct {v1, v3, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/h6;->d:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v3, "4"

    invoke-direct {v1, v0, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v5, Lcom/android/internal/util/danda/classes/h6;->e:Lcom/android/internal/util/danda/classes/o;

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v0, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v6, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v6, v5, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v6, Lcom/android/internal/util/danda/classes/h6;->f:Lcom/android/internal/util/danda/classes/o;

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v6, "3"

    invoke-direct {v5, v1, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v5, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/h6;->g:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v5, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/h6;->h:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v5, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/h6;->i:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v5, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/h6;->j:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v5, "0"

    invoke-direct {v0, v1, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v0, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v0, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v0, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v7, "5"

    invoke-direct {v5, v0, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v8, "6"

    invoke-direct {v5, v0, v8}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v9, "7"

    invoke-direct {v5, v0, v9}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v10, "8"

    invoke-direct {v5, v0, v10}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v11, "9"

    invoke-direct {v5, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v11, "10"

    invoke-direct {v5, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v11, "11"

    invoke-direct {v5, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v11, "12"

    invoke-direct {v5, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v11, "13"

    invoke-direct {v5, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v11, "14"

    invoke-direct {v5, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v11, "15"

    invoke-direct {v5, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v11, "16"

    invoke-direct {v5, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v12, "17"

    invoke-direct {v5, v0, v12}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v12, "18"

    invoke-direct {v5, v0, v12}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v12, "19"

    invoke-direct {v5, v0, v12}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v12, "20"

    invoke-direct {v5, v0, v12}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v8}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v9}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.840.10040.4.1"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/h6;->k:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.840.10040.4.3"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/h6;->l:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.133.16.840.63.0"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v11}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.840.10046"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v5, "2.1"

    invoke-direct {v1, v0, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v8}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v9}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v10}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.133.16.840.9.44"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    return-void
.end method
