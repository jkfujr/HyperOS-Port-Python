.class public final Lcom/android/internal/util/danda/classes/v2;
.super Lcom/android/internal/util/danda/classes/x2;
.source "SourceFile"


# instance fields
.field public f:I

.field public g:I

.field public h:I

.field public i:I

.field public j:Lcom/android/internal/util/danda/classes/b3;


# virtual methods
.method public final a(Ljava/math/BigInteger;Ljava/math/BigInteger;Z)Lcom/android/internal/util/danda/classes/c3;
    .registers 6

    invoke-virtual {p0, p1}, Lcom/android/internal/util/danda/classes/v2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    invoke-virtual {p0, p2}, Lcom/android/internal/util/danda/classes/v2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p2

    iget v0, p0, Lcom/android/internal/util/danda/classes/x2;->e:I

    const/4 v1, 0x5

    if-eq v0, v1, :cond_11

    const/4 v1, 0x6

    if-eq v0, v1, :cond_11

    goto :goto_3d

    :cond_11
    move-object v0, p1

    check-cast v0, Lcom/android/internal/util/danda/classes/y2;

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/y2;->g:Lcom/android/internal/util/danda/classes/f4;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/f4;->n()Z

    move-result v0

    if-eqz v0, :cond_2f

    invoke-virtual {p2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_29

    goto :goto_3d

    :cond_29
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_2f
    check-cast p2, Lcom/android/internal/util/danda/classes/y2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/a3;->f()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    invoke-virtual {p2, v0}, Lcom/android/internal/util/danda/classes/y2;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p2

    invoke-virtual {p2, p1}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p2

    :goto_3d
    invoke-virtual {p0, p1, p2, p3}, Lcom/android/internal/util/danda/classes/v2;->b(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Z)Lcom/android/internal/util/danda/classes/b3;

    move-result-object p1

    return-object p1
.end method

.method public final b(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Z)Lcom/android/internal/util/danda/classes/b3;
    .registers 11

    new-instance v6, Lcom/android/internal/util/danda/classes/b3;

    const/4 v5, 0x0

    move-object v0, v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    invoke-direct/range {v0 .. v5}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    return-object v6
.end method

.method public final d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;
    .registers 9

    new-instance v6, Lcom/android/internal/util/danda/classes/y2;

    iget v1, p0, Lcom/android/internal/util/danda/classes/v2;->f:I

    iget v2, p0, Lcom/android/internal/util/danda/classes/v2;->g:I

    iget v3, p0, Lcom/android/internal/util/danda/classes/v2;->h:I

    iget v4, p0, Lcom/android/internal/util/danda/classes/v2;->i:I

    move-object v0, v6

    move-object v5, p1

    invoke-direct/range {v0 .. v5}, Lcom/android/internal/util/danda/classes/y2;-><init>(IIIILjava/math/BigInteger;)V

    return-object v6
.end method

.method public final e()I
    .registers 2

    iget v0, p0, Lcom/android/internal/util/danda/classes/v2;->f:I

    return v0
.end method

.method public final f()Lcom/android/internal/util/danda/classes/b3;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/v2;->j:Lcom/android/internal/util/danda/classes/b3;

    return-object v0
.end method
