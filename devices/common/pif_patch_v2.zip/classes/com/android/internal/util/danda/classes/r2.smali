.class public abstract Lcom/android/internal/util/danda/classes/r2;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/HashMap;

.field public static b:[Ljava/lang/String;

.field public static c:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/android/internal/util/danda/classes/r2;->a:Ljava/util/HashMap;

    const/4 v0, 0x0

    sput-boolean v0, Lcom/android/internal/util/danda/classes/r2;->c:Z

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .registers 6

    const-string v0, "OemPorts10TUtils"

    const-string v1, "com.oemports10t.pif"

    const-string v2, "Insufficient array size for certified props: "

    sget-boolean v3, Lcom/android/internal/util/danda/classes/r2;->c:Z

    if-eqz v3, :cond_b

    return-void

    :cond_b
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    :try_start_f
    invoke-virtual {p0, v1}, Landroid/content/pm/PackageManager;->getResourcesForApplication(Ljava/lang/String;)Landroid/content/res/Resources;

    move-result-object p0
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_13} :catch_ad

    :try_start_13
    const-string v3, "device_props"

    const-string v4, "array"

    invoke-virtual {p0, v3, v4, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object p0

    sput-object p0, Lcom/android/internal/util/danda/classes/r2;->b:[Ljava/lang/String;

    array-length p0, p0

    const/16 v1, 0x8

    if-eq p0, v1, :cond_40

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v1, Lcom/android/internal/util/danda/classes/r2;->b:[Ljava/lang/String;

    array-length v1, v1

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", required 8"

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :catch_3e
    move-exception p0

    goto :goto_98

    :cond_40
    sget-object p0, Lcom/android/internal/util/danda/classes/r2;->a:Ljava/util/HashMap;

    const-string v1, "MANUFACTURER"

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "MODEL"

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "FINGERPRINT"

    const/4 v3, 0x2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "BRAND"

    const/4 v3, 0x3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "PRODUCT"

    const/4 v3, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "DEVICE"

    const/4 v3, 0x5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "SECURITY_PATCH"

    const/4 v3, 0x6

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "DEVICE_INITIAL_SDK_INT"

    const/4 v3, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sput-boolean v2, Lcom/android/internal/util/danda/classes/r2;->c:Z

    invoke-static {}, Lcom/android/internal/util/danda/classes/r2;->b()V
    :try_end_97
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_97} :catch_3e

    goto :goto_ad

    :goto_98
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Error accessing device_props for com.oemports10t.pif : "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :catch_ad
    :goto_ad
    return-void
.end method

.method public static b()V
    .registers 4

    sget-boolean v0, Lcom/android/internal/util/danda/classes/r2;->c:Z

    if-nez v0, :cond_c

    const-string v0, "OemPorts10TUtils"

    const-string v1, "Props not populated yet. Call populateMapFromAPK() first."

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_c
    sget-object v0, Lcom/android/internal/util/danda/classes/r2;->a:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const-string v3, "DEVICE_INITIAL_SDK_INT"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_46

    sget-object v3, Lcom/android/internal/util/danda/classes/r2;->b:[Ljava/lang/String;

    aget-object v1, v3, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    invoke-static {v2, v1}, Lcom/android/internal/util/danda/classes/m5;->m(Ljava/lang/String;I)V

    goto :goto_16

    :cond_46
    const-string v3, "SECURITY_PATCH"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_56

    sget-object v3, Lcom/android/internal/util/danda/classes/r2;->b:[Ljava/lang/String;

    aget-object v1, v3, v1

    invoke-static {v2, v1}, Lcom/android/internal/util/danda/classes/m5;->n(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_16

    :cond_56
    sget-object v3, Lcom/android/internal/util/danda/classes/r2;->b:[Ljava/lang/String;

    aget-object v1, v3, v1

    invoke-static {v2, v1}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_16

    :cond_5e
    return-void
.end method

.method public static c()V
    .registers 13

    const-string v0, "sailfish"

    const-string v1, "OemPorts10TUtils"

    const-string v2, "Spoofed properties to : "

    :try_start_6
    new-instance v3, Ljava/lang/String;

    const-string v4, "L2RhdGEvbG9jYWwvb2VtcG9ydHMxMHQvcGlmLmpzb24K"

    const/4 v5, 0x0

    invoke-static {v4, v5}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/android/internal/util/danda/classes/m5;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_1a
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_1a} :catch_48

    const-string v5, "DEVICE_INITIAL_SDK_INT"

    const-string v6, "SECURITY_PATCH"

    const-string v7, "DEVICE"

    const-string v8, "PRODUCT"

    const-string v9, "BRAND"

    const-string v10, "FINGERPRINT"

    const-string v11, "MANUFACTURER"

    const-string v12, "MODEL"

    if-eqz v4, :cond_a3

    :try_start_2c
    invoke-static {v3}, Lcom/android/internal/util/danda/classes/m5;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_3a

    goto :goto_a3

    :cond_3a
    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_4b

    const-string v4, "Fetching properties from json..."

    invoke-static {v1, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_4b

    :catch_48
    move-exception v0

    goto/16 :goto_dc

    :cond_4b
    :goto_4b
    invoke-static {v3, v11}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v11, v4}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3, v12}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v12, v4}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3, v10}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v10, v4}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3, v9}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v9, v4}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3, v8}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v8, v4}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3, v7}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v7, v4}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3, v6}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v6, v4}, Lcom/android/internal/util/danda/classes/m5;->n(Ljava/lang/String;Ljava/lang/String;)V

    const-string v4, "FIRST_API_LEVEL"

    invoke-static {v3, v4}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    invoke-static {v5, v4}, Lcom/android/internal/util/danda/classes/m5;->m(Ljava/lang/String;I)V

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_e3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v3, v12}, Lcom/android/internal/util/danda/classes/m5;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_e3

    :cond_a3
    :goto_a3
    const-string v2, "Google"

    invoke-static {v11, v2}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "Pixel"

    invoke-static {v12, v2}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "google/sailfish/sailfish:8.1.0/OPM1.171019.011/4448085:user/release-keys"

    invoke-static {v10, v2}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "google"

    invoke-static {v9, v2}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v8, v0}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v7, v0}, Lcom/android/internal/util/danda/classes/m5;->l(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "2018-01-05"

    invoke-static {v6, v0}, Lcom/android/internal/util/danda/classes/m5;->n(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x1e

    invoke-static {v5, v0}, Lcom/android/internal/util/danda/classes/m5;->m(Ljava/lang/String;I)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " doesnt exist or empty, spoofing using prebuilt properties..."

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_db
    .catch Ljava/io/IOException; {:try_start_2c .. :try_end_db} :catch_48

    goto :goto_e3

    :goto_dc
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_e3
    :goto_e3
    return-void
.end method
