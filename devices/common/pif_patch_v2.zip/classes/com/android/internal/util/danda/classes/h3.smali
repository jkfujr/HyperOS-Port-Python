.class public interface abstract Lcom/android/internal/util/danda/classes/h3;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()I
.end method

.method public abstract b()Ljava/math/BigInteger;
.end method
