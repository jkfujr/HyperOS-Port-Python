.class public abstract Lcom/android/internal/util/danda/classes/l;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"


# virtual methods
.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 2

    instance-of p1, p1, Lcom/android/internal/util/danda/classes/l;

    if-nez p1, :cond_6

    const/4 p1, 0x0

    return p1

    :cond_6
    const/4 p1, 0x1

    return p1
.end method

.method public final hashCode()I
    .registers 2

    const/4 v0, -0x1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    const-string v0, "NULL"

    return-object v0
.end method
