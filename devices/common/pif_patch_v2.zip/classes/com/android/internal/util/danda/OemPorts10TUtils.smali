.class public final Lcom/android/internal/util/danda/OemPorts10TUtils;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Ljava/lang/Integer;

.field public static b:Z

.field public static volatile c:Z

.field public static volatile d:Z

.field public static final e:Ljava/lang/Boolean;

.field public static final f:Ljava/lang/Boolean;

.field public static final g:Ljava/lang/Boolean;

.field public static final h:Ljava/lang/Boolean;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-string v0, "persist.sys.oemports10t.utils-debug"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    const-string v0, "persist.sys.oemports10t.utils.fingerprint"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->f:Ljava/lang/Boolean;

    const-string v0, "persist.sys.oemports10t.utils.bootloader"

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->g:Ljava/lang/Boolean;

    const-string v0, "persist.sys.oemports10t.utils.pif.autoupdate"

    invoke-static {v0, v1}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->h:Ljava/lang/Boolean;

    return-void
.end method

.method public static genCertificate(Ljava/lang/Object;Ljava/lang/Object;Landroid/system/keystore2/KeyDescriptor;Ljava/util/Collection;)Landroid/system/keystore2/KeyMetadata;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Landroid/system/keystore2/KeyDescriptor;",
            "Ljava/util/Collection<",
            "Landroid/hardware/security/keymint/KeyParameter;",
            ">;)",
            "Landroid/system/keystore2/KeyMetadata;"
        }
    .end annotation

    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->g:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_a

    return-object v1

    :cond_a
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    iget-object v2, p2, Landroid/system/keystore2/KeyDescriptor;->alias:Ljava/lang/String;

    sget-object v3, Lcom/android/internal/util/danda/classes/h1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v4, Lcom/android/internal/util/danda/classes/f1;

    invoke-direct {v4, v2, v0}, Lcom/android/internal/util/danda/classes/f1;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v3, Lcom/android/internal/util/danda/classes/h1;->b:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v4, Lcom/android/internal/util/danda/classes/f1;

    invoke-direct {v4, v2, v0}, Lcom/android/internal/util/danda/classes/f1;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v3, 0x1

    :try_start_26
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string v5, "handleExceptions"

    new-array v6, v3, [Ljava/lang/Class;

    const-string v7, "android.security.CheckedRemoteRequest"

    invoke-static {v7}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v7

    aput-object v7, v6, v2

    invoke-virtual {v4, v5, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v4, p0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/system/keystore2/KeyMetadata;
    :try_end_47
    .catchall {:try_start_26 .. :try_end_47} :catchall_49

    move v4, v2

    goto :goto_4b

    :catchall_49
    move-object p1, v1

    move v4, v3

    :goto_4b
    new-instance v5, Lcom/android/internal/util/danda/classes/g1;

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    const/16 v6, 0x800

    iput v6, v5, Lcom/android/internal/util/danda/classes/g1;->d:I

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    iput-object v6, v5, Lcom/android/internal/util/danda/classes/g1;->g:Ljava/util/ArrayList;

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    iput-object v6, v5, Lcom/android/internal/util/danda/classes/g1;->h:Ljava/util/ArrayList;

    sget v6, Lcom/android/internal/util/danda/classes/m5;->a:I

    const-string v6, "persist.sys.oemports10t.utils.patchlevel"

    invoke-static {v6}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v2}, Lcom/android/internal/util/danda/classes/m5;->a(Ljava/lang/String;Z)J

    move-result-wide v7

    iput-wide v7, v5, Lcom/android/internal/util/danda/classes/g1;->i:J

    invoke-static {v6}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v3}, Lcom/android/internal/util/danda/classes/m5;->a(Ljava/lang/String;Z)J

    move-result-wide v7

    iput-wide v7, v5, Lcom/android/internal/util/danda/classes/g1;->j:J

    invoke-static {v6}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v3}, Lcom/android/internal/util/danda/classes/m5;->a(Ljava/lang/String;Z)J

    move-result-wide v6

    iput-wide v6, v5, Lcom/android/internal/util/danda/classes/g1;->k:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iput-wide v6, v5, Lcom/android/internal/util/danda/classes/g1;->l:J

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v6

    const v7, 0x186a0

    div-int/2addr v6, v7

    iput v6, v5, Lcom/android/internal/util/danda/classes/g1;->m:I

    invoke-interface {p3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_98
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_100

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/hardware/security/keymint/KeyParameter;

    iget v7, v6, Landroid/hardware/security/keymint/KeyParameter;->tag:I

    sparse-switch v7, :sswitch_data_1ce

    goto :goto_98

    :sswitch_aa
    iget-object v6, v6, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    invoke-virtual {v6}, Landroid/hardware/security/keymint/KeyParameterValue;->getInteger()I

    move-result v6

    iput v6, v5, Lcom/android/internal/util/danda/classes/g1;->d:I

    goto :goto_98

    :sswitch_b3
    iget-object v7, v5, Lcom/android/internal/util/danda/classes/g1;->h:Ljava/util/ArrayList;

    iget-object v6, v6, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    invoke-virtual {v6}, Landroid/hardware/security/keymint/KeyParameterValue;->getDigest()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_98

    :sswitch_c3
    iget-object v7, v5, Lcom/android/internal/util/danda/classes/g1;->g:Ljava/util/ArrayList;

    iget-object v6, v6, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    invoke-virtual {v6}, Landroid/hardware/security/keymint/KeyParameterValue;->getKeyPurpose()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_98

    :sswitch_d3
    iget-object v6, v6, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    invoke-virtual {v6}, Landroid/hardware/security/keymint/KeyParameterValue;->getSecurityLevel()I

    move-result v6

    iput v6, v5, Lcom/android/internal/util/danda/classes/g1;->f:I

    goto :goto_98

    :sswitch_dc
    iget-object v6, v6, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    invoke-virtual {v6}, Landroid/hardware/security/keymint/KeyParameterValue;->getEcCurve()I

    move-result v6

    iput v6, v5, Lcom/android/internal/util/danda/classes/g1;->e:I

    goto :goto_98

    :sswitch_e5
    iget-object v6, v6, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    invoke-virtual {v6}, Landroid/hardware/security/keymint/KeyParameterValue;->getAlgorithm()I

    move-result v6

    iput v6, v5, Lcom/android/internal/util/danda/classes/g1;->a:I

    goto :goto_98

    :sswitch_ee
    iget-object v6, v6, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    invoke-virtual {v6}, Landroid/hardware/security/keymint/KeyParameterValue;->getBlob()[B

    move-result-object v6

    iput-object v6, v5, Lcom/android/internal/util/danda/classes/g1;->c:[B

    goto :goto_98

    :sswitch_f7
    iget-object v6, v6, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    invoke-virtual {v6}, Landroid/hardware/security/keymint/KeyParameterValue;->getBlob()[B

    move-result-object v6

    iput-object v6, v5, Lcom/android/internal/util/danda/classes/g1;->b:[B

    goto :goto_98

    :cond_100
    iget-object p3, v5, Lcom/android/internal/util/danda/classes/g1;->g:Ljava/util/ArrayList;

    if-eqz p3, :cond_1cc

    const/4 v6, 0x2

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {p3, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_1cc

    iget-object p3, v5, Lcom/android/internal/util/danda/classes/g1;->b:[B

    if-eqz p3, :cond_1cc

    const-string p3, "OemPorts10TUtils"

    if-nez v4, :cond_16c

    if-eqz p1, :cond_16c

    iget-object v4, p1, Landroid/system/keystore2/KeyMetadata;->certificate:[B

    if-eqz v4, :cond_16c

    array-length v4, v4

    if-nez v4, :cond_121

    goto :goto_16c

    :cond_121
    sput-boolean v2, Lcom/android/internal/util/danda/OemPorts10TUtils;->d:Z

    sget-object p0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_130

    const-string p0, "Normal TEE device detected during Key Generation!"

    invoke-static {p3, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_130
    :try_start_130
    iget-object p0, p1, Landroid/system/keystore2/KeyMetadata;->certificate:[B

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/h1;->f([B)[Ljava/security/cert/Certificate;

    move-result-object p0

    if-eqz p0, :cond_16b

    array-length p2, p0

    if-lez p2, :cond_16b

    aget-object p2, p0, v2

    invoke-virtual {p2}, Ljava/security/cert/Certificate;->getEncoded()[B

    move-result-object p2

    iput-object p2, p1, Landroid/system/keystore2/KeyMetadata;->certificate:[B

    array-length p2, p0

    if-le p2, v3, :cond_163

    new-instance p2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :goto_14b
    array-length v0, p0

    if-ge v3, v0, :cond_15c

    aget-object v0, p0, v3

    invoke-virtual {v0}, Ljava/security/cert/Certificate;->getEncoded()[B

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/io/OutputStream;->write([B)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_14b

    :catchall_15a
    move-exception p0

    goto :goto_166

    :cond_15c
    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    iput-object p0, p1, Landroid/system/keystore2/KeyMetadata;->certificateChain:[B

    goto :goto_16b

    :cond_163
    iput-object v1, p1, Landroid/system/keystore2/KeyMetadata;->certificateChain:[B
    :try_end_165
    .catchall {:try_start_130 .. :try_end_165} :catchall_15a

    goto :goto_16b

    :goto_166
    const-string p2, "Failed to hack cert chain"

    invoke-static {p3, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_16b
    :goto_16b
    return-object p1

    :cond_16c
    :goto_16c
    sput-boolean v3, Lcom/android/internal/util/danda/OemPorts10TUtils;->d:Z

    sget-object p1, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_17b

    const-string p1, "Broken TEE device detected during Key Generation!"

    invoke-static {p3, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_17b
    :try_start_17b
    invoke-static {v0, v5}, Lcom/android/internal/util/danda/classes/h1;->e(ILcom/android/internal/util/danda/classes/g1;)Ljava/util/ArrayList;

    move-result-object p1

    if-eqz p1, :cond_1cb

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_188

    goto :goto_1cb

    :cond_188
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string v6, "mSecurityLevel"

    invoke-virtual {v4, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v4, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/system/keystore2/IKeystoreSecurityLevel;

    invoke-static {p0, p1, v5, p2}, Lcom/android/internal/util/danda/classes/h1;->c(Landroid/system/keystore2/IKeystoreSecurityLevel;Ljava/util/ArrayList;Lcom/android/internal/util/danda/classes/g1;Landroid/system/keystore2/KeyDescriptor;)Landroid/system/keystore2/KeyEntryResponse;

    move-result-object p0

    if-nez p0, :cond_1a2

    goto :goto_1cb

    :cond_1a2
    iget-object v3, p2, Landroid/system/keystore2/KeyDescriptor;->alias:Ljava/lang/String;

    sget-object v4, Lcom/android/internal/util/danda/classes/h1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v5, Lcom/android/internal/util/danda/classes/f1;

    invoke-direct {v5, v3, v0}, Lcom/android/internal/util/danda/classes/f1;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v4, v5, p0}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p2, Landroid/system/keystore2/KeyDescriptor;->alias:Ljava/lang/String;

    new-array v2, v2, [Ljava/security/cert/Certificate;

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/security/cert/Certificate;

    sget-object v2, Lcom/android/internal/util/danda/classes/h1;->b:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v3, Lcom/android/internal/util/danda/classes/f1;

    invoke-direct {v3, p2, v0}, Lcom/android/internal/util/danda/classes/f1;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v2, v3, p1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Landroid/system/keystore2/KeyEntryResponse;->metadata:Landroid/system/keystore2/KeyMetadata;
    :try_end_1c4
    .catch Ljava/lang/Exception; {:try_start_17b .. :try_end_1c4} :catch_1c5

    goto :goto_1cb

    :catch_1c5
    move-exception p0

    const-string p1, "Failed to generate spoofed hardware key"

    invoke-static {p3, p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_1cb
    :goto_1cb
    return-object v1

    :cond_1cc
    return-object p1

    nop

    :sswitch_data_1ce
    .sparse-switch
        -0x6ffffd3c -> :sswitch_f7
        -0x6ffffd3b -> :sswitch_ee
        0x10000002 -> :sswitch_e5
        0x1000000a -> :sswitch_dc
        0x10000130 -> :sswitch_d3
        0x20000001 -> :sswitch_c3
        0x20000005 -> :sswitch_b3
        0x30000003 -> :sswitch_aa
    .end sparse-switch
.end method

.method public static onDeleteKey(Landroid/system/keystore2/KeyDescriptor;)V
    .registers 4

    if-eqz p0, :cond_21

    iget-object v0, p0, Landroid/system/keystore2/KeyDescriptor;->alias:Ljava/lang/String;

    if-nez v0, :cond_7

    goto :goto_21

    :cond_7
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v0

    iget-object p0, p0, Landroid/system/keystore2/KeyDescriptor;->alias:Ljava/lang/String;

    sget-object v1, Lcom/android/internal/util/danda/classes/h1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v2, Lcom/android/internal/util/danda/classes/f1;

    invoke-direct {v2, p0, v0}, Lcom/android/internal/util/danda/classes/f1;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lcom/android/internal/util/danda/classes/h1;->b:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v2, Lcom/android/internal/util/danda/classes/f1;

    invoke-direct {v2, p0, v0}, Lcom/android/internal/util/danda/classes/f1;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_21
    :goto_21
    return-void
.end method

.method public static onEngineGetCertificateChain()V
    .registers 3

    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->g:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const-string v1, "OemPorts10TUtils"

    if-eqz v0, :cond_18

    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_36

    const-string v0, "Key attestation blocking is disabled because bootloader status is spoofed"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_36

    :cond_18
    sget v0, Lcom/android/internal/util/danda/classes/m5;->a:I

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->stream([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v0

    new-instance v2, Lcom/android/internal/util/danda/classes/l5;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-interface {v0, v2}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v0

    if-nez v0, :cond_37

    sget-boolean v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->c:Z

    if-eqz v0, :cond_36

    goto :goto_37

    :cond_36
    :goto_36
    return-void

    :cond_37
    :goto_37
    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_44

    const-string v0, "Blocked key attestation"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_44
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public static onGetKeyEntry(Ljava/lang/Object;Ljava/lang/Object;Landroid/system/keystore2/KeyDescriptor;)Landroid/system/keystore2/KeyEntryResponse;
    .registers 11

    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->g:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_a

    return-object v1

    :cond_a
    sget-boolean v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->d:Z

    const-string v2, "OemPorts10TUtils"

    if-eqz v0, :cond_31

    sget-object p0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_1d

    const-string p0, "Broken TEE device detected during Key Retrieval!"

    invoke-static {v2, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1d
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result p0

    iget-object p1, p2, Landroid/system/keystore2/KeyDescriptor;->alias:Ljava/lang/String;

    sget-object p2, Lcom/android/internal/util/danda/classes/h1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v0, Lcom/android/internal/util/danda/classes/f1;

    invoke-direct {v0, p1, p0}, Lcom/android/internal/util/danda/classes/f1;-><init>(Ljava/lang/String;I)V

    invoke-virtual {p2, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/system/keystore2/KeyEntryResponse;

    return-object p0

    :cond_31
    const/4 v0, 0x1

    :try_start_32
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const-string v4, "handleRemoteExceptionWithRetry"

    new-array v5, v0, [Ljava/lang/Class;

    const-string v6, "android.security.KeyStore2$CheckedRemoteRequest"

    invoke-static {v6}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v6

    const/4 v7, 0x0

    aput-object v6, v5, v7

    invoke-virtual {v3, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v3, p0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/system/keystore2/KeyEntryResponse;
    :try_end_54
    .catchall {:try_start_32 .. :try_end_54} :catchall_a7

    if-eqz p0, :cond_a6

    iget-object p1, p0, Landroid/system/keystore2/KeyEntryResponse;->metadata:Landroid/system/keystore2/KeyMetadata;

    if-eqz p1, :cond_a6

    iget-object p1, p1, Landroid/system/keystore2/KeyMetadata;->certificate:[B

    if-eqz p1, :cond_a6

    sget-object p1, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_6b

    const-string p1, "Normal TEE device detected during Key Retrieval!"

    invoke-static {v2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_6b
    :try_start_6b
    iget-object p1, p0, Landroid/system/keystore2/KeyEntryResponse;->metadata:Landroid/system/keystore2/KeyMetadata;

    iget-object p1, p1, Landroid/system/keystore2/KeyMetadata;->certificate:[B

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/h1;->f([B)[Ljava/security/cert/Certificate;

    move-result-object p1

    if-eqz p1, :cond_a6

    array-length p2, p1

    if-lez p2, :cond_a6

    iget-object p2, p0, Landroid/system/keystore2/KeyEntryResponse;->metadata:Landroid/system/keystore2/KeyMetadata;

    aget-object v2, p1, v7

    invoke-virtual {v2}, Ljava/security/cert/Certificate;->getEncoded()[B

    move-result-object v2

    iput-object v2, p2, Landroid/system/keystore2/KeyMetadata;->certificate:[B

    array-length p2, p1

    if-le p2, v0, :cond_a2

    new-instance p2, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :goto_8a
    array-length v1, p1

    if-ge v0, v1, :cond_99

    aget-object v1, p1, v0

    invoke-virtual {v1}, Ljava/security/cert/Certificate;->getEncoded()[B

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/io/OutputStream;->write([B)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_8a

    :cond_99
    iget-object p1, p0, Landroid/system/keystore2/KeyEntryResponse;->metadata:Landroid/system/keystore2/KeyMetadata;

    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p2

    iput-object p2, p1, Landroid/system/keystore2/KeyMetadata;->certificateChain:[B

    goto :goto_a6

    :cond_a2
    iget-object p1, p0, Landroid/system/keystore2/KeyEntryResponse;->metadata:Landroid/system/keystore2/KeyMetadata;

    iput-object v1, p1, Landroid/system/keystore2/KeyMetadata;->certificateChain:[B
    :try_end_a6
    .catchall {:try_start_6b .. :try_end_a6} :catchall_a6

    :catchall_a6
    :cond_a6
    :goto_a6
    return-object p0

    :catchall_a7
    sput-boolean v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->d:Z

    sget-object p0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_b6

    const-string p0, "Broken TEE device detected during Key Retrieval (HW)!"

    invoke-static {v2, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_b6
    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result p0

    iget-object p1, p2, Landroid/system/keystore2/KeyDescriptor;->alias:Ljava/lang/String;

    sget-object p2, Lcom/android/internal/util/danda/classes/h1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v0, Lcom/android/internal/util/danda/classes/f1;

    invoke-direct {v0, p1, p0}, Lcom/android/internal/util/danda/classes/f1;-><init>(Ljava/lang/String;I)V

    invoke-virtual {p2, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/system/keystore2/KeyEntryResponse;

    return-object p0
.end method

.method public static onNewApplication(Landroid/content/Context;)V
    .registers 10

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "com.android.vending"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    const/4 v0, 0x1

    sput-boolean v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->c:Z

    :cond_f
    sget v0, Lcom/android/internal/util/danda/classes/m5;->a:I

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "com.android.systemui"

    invoke-static {v0, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const-string v4, "OemPorts10TUtils"

    const-string v5, "com.oemports10t.pif"

    if-nez v3, :cond_27

    invoke-static {v0, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_107

    :cond_27
    const-string v2, "Unexpected Keybox size: "

    const-string v3, "Insufficient array size for keybox: "

    sget-object v6, Lcom/android/internal/util/danda/OemPorts10TUtils;->h:Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-nez v6, :cond_35

    goto/16 :goto_bb

    :cond_35
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v6

    :try_start_39
    invoke-virtual {v6, v5}, Landroid/content/pm/PackageManager;->getResourcesForApplication(Ljava/lang/String;)Landroid/content/res/Resources;

    move-result-object v6
    :try_end_3d
    .catch Ljava/lang/Exception; {:try_start_39 .. :try_end_3d} :catch_bb

    :try_start_3d
    const-string v7, "keybox"

    const-string v8, "array"

    invoke-virtual {v6, v7, v8, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v6

    array-length v7, v6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    sput-object v7, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    const/4 v8, 0x6

    if-ge v7, v8, :cond_70

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v3, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, ", min 6"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_bb

    :catch_6e
    move-exception v2

    goto :goto_a6

    :cond_70
    sget-object v3, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    if-eq v3, v8, :cond_a1

    const/16 v7, 0x8

    if-eq v3, v7, :cond_9c

    const/16 v7, 0xa

    if-eq v3, v7, :cond_97

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v2, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ". Valid sizes: 6, 8, 10, 12"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_bb

    :cond_97
    const/4 v2, 0x5

    invoke-static {v6, v2, v2}, Lcom/android/internal/util/danda/classes/m5;->p([Ljava/lang/String;II)V

    goto :goto_bb

    :cond_9c
    const/4 v2, 0x4

    invoke-static {v6, v2, v2}, Lcom/android/internal/util/danda/classes/m5;->p([Ljava/lang/String;II)V

    goto :goto_bb

    :cond_a1
    const/4 v2, 0x3

    invoke-static {v6, v2, v2}, Lcom/android/internal/util/danda/classes/m5;->p([Ljava/lang/String;II)V
    :try_end_a5
    .catch Ljava/lang/Exception; {:try_start_3d .. :try_end_a5} :catch_6e

    goto :goto_bb

    :goto_a6
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v6, "Error accessing keybox for com.oemports10t.pif : "

    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :catch_bb
    :goto_bb
    const-string v2, "persist.sys.oemports10t.utils.patchlevel"

    const-string v3, "ro.build.version.security_patch"

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v6

    :try_start_c3
    invoke-virtual {v6, v5}, Landroid/content/pm/PackageManager;->getResourcesForApplication(Ljava/lang/String;)Landroid/content/res/Resources;

    move-result-object v6
    :try_end_c7
    .catch Ljava/lang/Exception; {:try_start_c3 .. :try_end_c7} :catch_c8

    goto :goto_d0

    :catch_c8
    invoke-static {v3}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Landroid/os/SystemProperties;->set(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    :goto_d0
    :try_start_d0
    const-string v7, "security_patch"

    const-string v8, "string"

    invoke-virtual {v6, v7, v8, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v7

    if-eqz v7, :cond_e1

    invoke-virtual {v6, v7}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_104

    :catch_df
    move-exception v6

    goto :goto_eb

    :cond_e1
    const-string v6, "security_patch string not found in com.oemports10t.pif"

    invoke-static {v4, v6}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v3}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_ea
    .catch Ljava/lang/Exception; {:try_start_d0 .. :try_end_ea} :catch_df

    goto :goto_104

    :goto_eb
    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "Error accessing security_patch for com.oemports10t.pif : "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v3}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_104
    invoke-static {v2, v3}, Landroid/os/SystemProperties;->set(Ljava/lang/String;Ljava/lang/String;)V

    :cond_107
    const-string v2, "com.google.android.gms"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_132

    const-string v2, "com.google.android.gms.unstable"

    invoke-static {}, Landroid/app/Application;->getProcessName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_132

    sget-object v2, Lcom/android/internal/util/danda/OemPorts10TUtils;->f:Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_132

    sget-object v2, Lcom/android/internal/util/danda/OemPorts10TUtils;->h:Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_12f

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/r2;->a(Landroid/content/Context;)V

    goto :goto_132

    :cond_12f
    invoke-static {}, Lcom/android/internal/util/danda/classes/r2;->c()V

    :cond_132
    :goto_132
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_199

    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->f:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_14f

    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->h:Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_14c

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/r2;->a(Landroid/content/Context;)V

    goto :goto_14f

    :cond_14c
    invoke-static {}, Lcom/android/internal/util/danda/classes/r2;->c()V

    :cond_14f
    :goto_14f
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    :try_start_153
    invoke-virtual {p0, v5}, Landroid/content/pm/PackageManager;->getResourcesForApplication(Ljava/lang/String;)Landroid/content/res/Resources;

    move-result-object p0
    :try_end_157
    .catch Ljava/lang/Exception; {:try_start_153 .. :try_end_157} :catch_199

    :try_start_157
    const-string v0, "spoof_vending_sdk"

    const-string v1, "bool"

    invoke-virtual {p0, v0, v1, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_17e

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p0

    if-eqz p0, :cond_199

    const-string p0, "SDK_INT"

    const/16 v0, 0x20

    invoke-static {p0, v0}, Lcom/android/internal/util/danda/classes/m5;->m(Ljava/lang/String;I)V

    sget-object p0, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_199

    const-string p0, "Spoofed com.android.vending sdk to 32"

    invoke-static {v4, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_199

    :catch_17c
    move-exception p0

    goto :goto_184

    :cond_17e
    const-string p0, "spoof_vending_sdk bool not found"

    invoke-static {v4, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_183
    .catch Ljava/lang/Exception; {:try_start_157 .. :try_end_183} :catch_17c

    goto :goto_199

    :goto_184
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error accessing spoof_vending_sdk for com.oemports10t.pif : "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v4, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :catch_199
    :cond_199
    :goto_199
    return-void
.end method
