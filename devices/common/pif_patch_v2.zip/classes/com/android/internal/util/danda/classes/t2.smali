.class public interface abstract Lcom/android/internal/util/danda/classes/t2;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;

.field public static final d:Lcom/android/internal/util/danda/classes/o;

.field public static final e:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 10

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "0.4.0.127.0.7"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "2.2.1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/o;

    const-string v3, "1"

    invoke-direct {v2, v1, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/o;

    const-string v4, "2"

    invoke-direct {v2, v1, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "2.2.3"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v2, v1, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v2, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v2, v1, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v2, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "2.2.2"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v2, v1, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v2, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v5, v2, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v6, "3"

    invoke-direct {v5, v2, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v7, "4"

    invoke-direct {v5, v2, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v8, "5"

    invoke-direct {v5, v2, v8}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v9, "6"

    invoke-direct {v5, v2, v9}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v2, v1, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v2, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/t2;->a:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v2, v4}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/t2;->b:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v2, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/t2;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v2, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/t2;->d:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v2, v8}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/t2;->e:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "3.1.2.1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    return-void
.end method
