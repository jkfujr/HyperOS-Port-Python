.class public final Lcom/android/internal/util/danda/classes/v0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/v;


# instance fields
.field public final synthetic m:I

.field public final n:Lcom/android/internal/util/danda/classes/y;


# direct methods
.method public synthetic constructor <init>(ILcom/android/internal/util/danda/classes/y;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/android/internal/util/danda/classes/v0;->m:I

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/v0;->n:Lcom/android/internal/util/danda/classes/y;

    return-void
.end method


# virtual methods
.method public final b()Lcom/android/internal/util/danda/classes/t;
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/v0;->n:Lcom/android/internal/util/danda/classes/y;

    iget v1, p0, Lcom/android/internal/util/danda/classes/v0;->m:I

    packed-switch v1, :pswitch_data_1c

    new-instance v1, Lcom/android/internal/util/danda/classes/d2;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v0

    const/4 v2, 0x0

    invoke-direct {v1, v2, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v1

    :pswitch_12
    new-instance v1, Lcom/android/internal/util/danda/classes/u0;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/android/internal/util/danda/classes/u;-><init>(Lcom/android/internal/util/danda/classes/f;)V

    return-object v1

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_12
    .end packed-switch
.end method

.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 3

    iget v0, p0, Lcom/android/internal/util/danda/classes/v0;->m:I

    packed-switch v0, :pswitch_data_26

    :try_start_5
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/v0;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_9} :catch_a

    return-object v0

    :catch_a
    move-exception v0

    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :pswitch_15
    :try_start_15
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/v0;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_19
    .catch Ljava/io/IOException; {:try_start_15 .. :try_end_19} :catch_1a

    return-object v0

    :catch_1a
    move-exception v0

    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_15
    .end packed-switch
.end method
