.class public final Lcom/android/internal/util/danda/classes/n;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:[B


# direct methods
.method public constructor <init>([B)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/c0;->j([B)I

    move-result v0

    iput v0, p0, Lcom/android/internal/util/danda/classes/n;->a:I

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/n;->b:[B

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/n;

    if-eqz v0, :cond_f

    check-cast p1, Lcom/android/internal/util/danda/classes/n;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/n;->b:[B

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/n;->b:[B

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/c0;->c([B[B)Z

    move-result p1

    return p1

    :cond_f
    const/4 p1, 0x0

    return p1
.end method

.method public final hashCode()I
    .registers 2

    iget v0, p0, Lcom/android/internal/util/danda/classes/n;->a:I

    return v0
.end method
