.class public final Lcom/android/internal/util/danda/classes/h;
.super Ljava/io/IOException;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Throwable;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;I)V
    .registers 3

    iput p2, p0, Lcom/android/internal/util/danda/classes/h;->a:I

    .line 1
    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Exception;I)V
    .registers 4

    iput p3, p0, Lcom/android/internal/util/danda/classes/h;->a:I

    .line 2
    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/h;->b:Ljava/lang/Throwable;

    return-void
.end method


# virtual methods
.method public final getCause()Ljava/lang/Throwable;
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/h;->b:Ljava/lang/Throwable;

    iget v1, p0, Lcom/android/internal/util/danda/classes/h;->a:I

    packed-switch v1, :pswitch_data_a

    check-cast v0, Ljava/lang/Exception;

    :pswitch_9
    return-object v0

    :pswitch_data_a
    .packed-switch 0x0
        :pswitch_9
        :pswitch_9
        :pswitch_9
        :pswitch_9
    .end packed-switch
.end method
