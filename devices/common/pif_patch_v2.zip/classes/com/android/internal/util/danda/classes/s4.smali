.class public final Lcom/android/internal/util/danda/classes/s4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/y4;


# instance fields
.field public final a:Lcom/android/internal/util/danda/classes/p4;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/q4;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/s4;->a:Lcom/android/internal/util/danda/classes/p4;

    return-void
.end method


# virtual methods
.method public final a(Lcom/android/internal/util/danda/classes/x4;)Ljava/lang/Object;
    .registers 9

    iget-object v0, p1, Lcom/android/internal/util/danda/classes/x4;->b:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :cond_8
    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_36

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/w4;

    iget-object v4, v3, Lcom/android/internal/util/danda/classes/w4;->a:Ljava/lang/String;

    const-string v5, "Proc-Type"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    iget-object v5, v3, Lcom/android/internal/util/danda/classes/w4;->b:Ljava/lang/String;

    if-eqz v4, :cond_2a

    const-string v4, "4,ENCRYPTED"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2a

    const/4 v1, 0x1

    goto :goto_8

    :cond_2a
    const-string v4, "DEK-Info"

    iget-object v3, v3, Lcom/android/internal/util/danda/classes/w4;->a:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_8

    move-object v2, v5

    goto :goto_8

    :cond_36
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    const-string v0, "exception decoding - please check password and data."

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/s4;->a:Lcom/android/internal/util/danda/classes/p4;

    const/4 v4, 0x4

    if-eqz v1, :cond_64

    :try_start_3f
    new-instance v5, Ljava/util/StringTokenizer;

    const-string v6, ","

    invoke-direct {v5, v2, v6}, Ljava/util/StringTokenizer;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/util/StringTokenizer;->nextToken()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Ljava/util/StringTokenizer;->nextToken()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/p3;->a(Ljava/lang/String;)[B

    move-result-object v5

    new-instance v6, Lcom/android/internal/util/danda/classes/n4;

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    iput-object v2, v6, Lcom/android/internal/util/danda/classes/n4;->a:Ljava/lang/Object;

    iput-object v5, v6, Lcom/android/internal/util/danda/classes/n4;->b:Ljava/lang/Object;

    iput-object p1, v6, Lcom/android/internal/util/danda/classes/n4;->c:Ljava/lang/Object;

    iput-object v3, v6, Lcom/android/internal/util/danda/classes/n4;->d:Ljava/lang/Object;

    return-object v6

    :catch_60
    move-exception p1

    goto :goto_6b

    :catch_62
    move-exception p1

    goto :goto_7d

    :cond_64
    check-cast v3, Lcom/android/internal/util/danda/classes/q4;

    invoke-virtual {v3, p1}, Lcom/android/internal/util/danda/classes/q4;->a([B)Lcom/android/internal/util/danda/classes/o4;

    move-result-object p1
    :try_end_6a
    .catch Ljava/io/IOException; {:try_start_3f .. :try_end_6a} :catch_62
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3f .. :try_end_6a} :catch_60

    return-object p1

    :goto_6b
    if-eqz v1, :cond_73

    new-instance v1, Lcom/android/internal/util/danda/classes/h;

    invoke-direct {v1, v0, p1, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1

    :cond_73
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :goto_7d
    if-eqz v1, :cond_85

    new-instance v1, Lcom/android/internal/util/danda/classes/h;

    invoke-direct {v1, v0, p1, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1

    :cond_85
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0
.end method
