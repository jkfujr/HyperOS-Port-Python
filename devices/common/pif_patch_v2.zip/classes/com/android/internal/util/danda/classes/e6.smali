.class public final Lcom/android/internal/util/danda/classes/e6;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/h6;


# static fields
.field public static final r:Ljava/math/BigInteger;


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/x2;

.field public n:Lcom/android/internal/util/danda/classes/f6;

.field public o:Ljava/math/BigInteger;

.field public p:Ljava/math/BigInteger;

.field public q:[B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-wide/16 v0, 0x1

    invoke-static {v0, v1}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/e6;->r:Ljava/math/BigInteger;

    return-void
.end method

.method public static g(Lcom/android/internal/util/danda/classes/t;)Lcom/android/internal/util/danda/classes/e6;
    .registers 23

    move-object/from16 v0, p0

    instance-of v1, v0, Lcom/android/internal/util/danda/classes/e6;

    if-eqz v1, :cond_9

    check-cast v0, Lcom/android/internal/util/danda/classes/e6;

    return-object v0

    :cond_9
    const/4 v1, 0x0

    if-eqz v0, :cond_2a9

    new-instance v2, Lcom/android/internal/util/danda/classes/e6;

    invoke-static/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v4

    instance-of v4, v4, Lcom/android/internal/util/danda/classes/k;

    if-eqz v4, :cond_2a1

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v4

    check-cast v4, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v4

    sget-object v5, Lcom/android/internal/util/danda/classes/e6;->r:Ljava/math/BigInteger;

    invoke-virtual {v4, v5}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2a1

    const/4 v4, 0x1

    invoke-virtual {v0, v4}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v5

    instance-of v6, v5, Lcom/android/internal/util/danda/classes/g6;

    if-eqz v6, :cond_3c

    check-cast v5, Lcom/android/internal/util/danda/classes/g6;

    goto :goto_5e

    :cond_3c
    if-eqz v5, :cond_5d

    new-instance v6, Lcom/android/internal/util/danda/classes/g6;

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v5

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v5, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v7

    invoke-static {v7}, Lcom/android/internal/util/danda/classes/o;->p(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/o;

    move-result-object v7

    iput-object v7, v6, Lcom/android/internal/util/danda/classes/g6;->m:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v5, v4}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v5

    invoke-interface {v5}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v5

    iput-object v5, v6, Lcom/android/internal/util/danda/classes/g6;->n:Lcom/android/internal/util/danda/classes/t;

    move-object v5, v6

    goto :goto_5e

    :cond_5d
    move-object v5, v1

    :goto_5e
    const/4 v6, 0x2

    invoke-virtual {v0, v6}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v7

    invoke-static {v7}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v7

    iget-object v8, v5, Lcom/android/internal/util/danda/classes/g6;->m:Lcom/android/internal/util/danda/classes/o;

    sget-object v9, Lcom/android/internal/util/danda/classes/h6;->a:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v8, v9}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v9

    iget-object v5, v5, Lcom/android/internal/util/danda/classes/g6;->n:Lcom/android/internal/util/danda/classes/t;

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    if-eqz v9, :cond_118

    check-cast v5, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v5

    invoke-virtual {v7, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/p;

    new-instance v8, Ljava/math/BigInteger;

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v3

    invoke-direct {v8, v4, v3}, Ljava/math/BigInteger;-><init>(I[B)V

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/z2;->r(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    invoke-virtual {v8}, Ljava/math/BigInteger;->signum()I

    move-result v3

    const-string v9, "x value invalid in Fp field element"

    if-ltz v3, :cond_112

    invoke-virtual {v8, v5}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v3

    if-gez v3, :cond_112

    invoke-virtual {v7, v4}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/p;

    new-instance v13, Ljava/math/BigInteger;

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v3

    invoke-direct {v13, v4, v3}, Ljava/math/BigInteger;-><init>(I[B)V

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/z2;->r(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    invoke-virtual {v13}, Ljava/math/BigInteger;->signum()I

    move-result v3

    if-ltz v3, :cond_10c

    invoke-virtual {v13, v5}, Ljava/math/BigInteger;->compareTo(Ljava/math/BigInteger;)I

    move-result v3

    if-gez v3, :cond_10c

    new-instance v3, Lcom/android/internal/util/danda/classes/w2;

    sget-object v9, Lcom/android/internal/util/danda/classes/i3;->a:Lcom/android/internal/util/danda/classes/a5;

    invoke-virtual {v5}, Ljava/math/BigInteger;->bitLength()I

    move-result v9

    invoke-virtual {v5}, Ljava/math/BigInteger;->signum()I

    move-result v14

    if-lez v14, :cond_104

    if-lt v9, v6, :cond_104

    if-ge v9, v12, :cond_db

    invoke-virtual {v5}, Ljava/math/BigInteger;->intValue()I

    move-result v9

    if-eq v9, v6, :cond_d8

    if-eq v9, v12, :cond_d5

    goto :goto_db

    :cond_d5
    sget-object v9, Lcom/android/internal/util/danda/classes/i3;->b:Lcom/android/internal/util/danda/classes/a5;

    goto :goto_e0

    :cond_d8
    sget-object v9, Lcom/android/internal/util/danda/classes/i3;->a:Lcom/android/internal/util/danda/classes/a5;

    goto :goto_e0

    :cond_db
    :goto_db
    new-instance v9, Lcom/android/internal/util/danda/classes/a5;

    invoke-direct {v9, v5}, Lcom/android/internal/util/danda/classes/a5;-><init>(Ljava/math/BigInteger;)V

    :goto_e0
    invoke-direct {v3, v9}, Lcom/android/internal/util/danda/classes/x2;-><init>(Lcom/android/internal/util/danda/classes/h3;)V

    iput-object v5, v3, Lcom/android/internal/util/danda/classes/w2;->f:Ljava/math/BigInteger;

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/z2;->r(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v5

    iput-object v5, v3, Lcom/android/internal/util/danda/classes/w2;->g:Ljava/math/BigInteger;

    new-instance v5, Lcom/android/internal/util/danda/classes/b3;

    invoke-direct {v5, v3, v4}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;I)V

    iput-object v5, v3, Lcom/android/internal/util/danda/classes/w2;->h:Lcom/android/internal/util/danda/classes/b3;

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/w2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    iput-object v4, v3, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v3, v13}, Lcom/android/internal/util/danda/classes/w2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    iput-object v4, v3, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    iput-object v1, v3, Lcom/android/internal/util/danda/classes/x2;->d:Ljava/math/BigInteger;

    iput v11, v3, Lcom/android/internal/util/danda/classes/x2;->e:I

    goto/16 :goto_22d

    :cond_104
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\'characteristic\' must be >= 2"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_10c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_112
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_118
    sget-object v9, Lcom/android/internal/util/danda/classes/h6;->b:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v8, v9}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_299

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v5

    invoke-virtual {v5, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v8

    check-cast v8, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v8

    invoke-virtual {v8}, Ljava/math/BigInteger;->intValue()I

    move-result v8

    invoke-virtual {v5, v4}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v9

    check-cast v9, Lcom/android/internal/util/danda/classes/o;

    sget-object v13, Lcom/android/internal/util/danda/classes/h6;->c:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v9, v13}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_153

    invoke-virtual {v5, v6}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v5

    invoke-virtual {v5}, Ljava/math/BigInteger;->intValue()I

    move-result v5

    move v9, v3

    move v15, v9

    goto :goto_199

    :cond_153
    sget-object v13, Lcom/android/internal/util/danda/classes/h6;->d:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v9, v13}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_291

    invoke-virtual {v5, v6}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v5

    invoke-virtual {v5, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v9

    invoke-static {v9}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v9

    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v9

    invoke-virtual {v9}, Ljava/math/BigInteger;->intValue()I

    move-result v9

    invoke-virtual {v5, v4}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v13

    invoke-static {v13}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v13

    invoke-virtual {v13}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v13

    invoke-virtual {v13}, Ljava/math/BigInteger;->intValue()I

    move-result v13

    invoke-virtual {v5, v6}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v5

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v5

    invoke-virtual {v5}, Ljava/math/BigInteger;->intValue()I

    move-result v5

    move v15, v13

    move/from16 v21, v9

    move v9, v5

    move/from16 v5, v21

    :goto_199
    invoke-virtual {v7, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v13

    check-cast v13, Lcom/android/internal/util/danda/classes/p;

    new-instance v19, Lcom/android/internal/util/danda/classes/y2;

    new-instance v14, Ljava/math/BigInteger;

    invoke-virtual {v13}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v13

    invoke-direct {v14, v4, v13}, Ljava/math/BigInteger;-><init>(I[B)V

    move-object/from16 v13, v19

    move-object/from16 v18, v14

    move v14, v8

    move/from16 p0, v15

    move v15, v5

    move/from16 v16, p0

    move/from16 v17, v9

    invoke-direct/range {v13 .. v18}, Lcom/android/internal/util/danda/classes/y2;-><init>(IIIILjava/math/BigInteger;)V

    invoke-virtual {v7, v4}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v13

    check-cast v13, Lcom/android/internal/util/danda/classes/p;

    new-instance v20, Lcom/android/internal/util/danda/classes/y2;

    new-instance v15, Ljava/math/BigInteger;

    invoke-virtual {v13}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v13

    invoke-direct {v15, v4, v13}, Ljava/math/BigInteger;-><init>(I[B)V

    move-object/from16 v13, v20

    move v14, v8

    move-object v4, v15

    move v15, v5

    move/from16 v16, p0

    move/from16 v17, v9

    move-object/from16 v18, v4

    invoke-direct/range {v13 .. v18}, Lcom/android/internal/util/danda/classes/y2;-><init>(IIIILjava/math/BigInteger;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/v2;

    invoke-virtual/range {v19 .. v19}, Lcom/android/internal/util/danda/classes/y2;->q()Ljava/math/BigInteger;

    move-result-object v13

    invoke-virtual/range {v20 .. v20}, Lcom/android/internal/util/danda/classes/y2;->q()Ljava/math/BigInteger;

    move-result-object v14

    if-eqz v5, :cond_289

    move/from16 v15, p0

    if-nez v15, :cond_1fd

    if-nez v9, :cond_1f5

    filled-new-array {v3, v5, v8}, [I

    move-result-object v16

    invoke-static/range {v16 .. v16}, Lcom/android/internal/util/danda/classes/i3;->a([I)Lcom/android/internal/util/danda/classes/o3;

    move-result-object v16

    :goto_1f2
    move-object/from16 v11, v16

    goto :goto_20a

    :cond_1f5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "k3 must be 0 if k2 == 0"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1fd
    if-le v15, v5, :cond_281

    if-le v9, v15, :cond_279

    filled-new-array {v3, v5, v15, v9, v8}, [I

    move-result-object v16

    invoke-static/range {v16 .. v16}, Lcom/android/internal/util/danda/classes/i3;->a([I)Lcom/android/internal/util/danda/classes/o3;

    move-result-object v16

    goto :goto_1f2

    :goto_20a
    invoke-direct {v4, v11}, Lcom/android/internal/util/danda/classes/x2;-><init>(Lcom/android/internal/util/danda/classes/h3;)V

    iput v8, v4, Lcom/android/internal/util/danda/classes/v2;->f:I

    iput v5, v4, Lcom/android/internal/util/danda/classes/v2;->g:I

    iput v15, v4, Lcom/android/internal/util/danda/classes/v2;->h:I

    iput v9, v4, Lcom/android/internal/util/danda/classes/v2;->i:I

    iput-object v1, v4, Lcom/android/internal/util/danda/classes/x2;->d:Ljava/math/BigInteger;

    new-instance v5, Lcom/android/internal/util/danda/classes/b3;

    invoke-direct {v5, v4, v3}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;I)V

    iput-object v5, v4, Lcom/android/internal/util/danda/classes/v2;->j:Lcom/android/internal/util/danda/classes/b3;

    invoke-virtual {v4, v13}, Lcom/android/internal/util/danda/classes/v2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    iput-object v3, v4, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v4, v14}, Lcom/android/internal/util/danda/classes/v2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    iput-object v3, v4, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    iput v10, v4, Lcom/android/internal/util/danda/classes/x2;->e:I

    move-object v3, v4

    :goto_22d
    invoke-virtual {v7}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v4

    if-ne v4, v12, :cond_23d

    invoke-virtual {v7, v6}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/q1;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/b;->n()[B

    move-result-object v1

    :cond_23d
    iput-object v3, v2, Lcom/android/internal/util/danda/classes/e6;->m:Lcom/android/internal/util/danda/classes/x2;

    invoke-virtual {v0, v12}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v3

    instance-of v4, v3, Lcom/android/internal/util/danda/classes/f6;

    if-eqz v4, :cond_24d

    check-cast v3, Lcom/android/internal/util/danda/classes/f6;

    iput-object v3, v2, Lcom/android/internal/util/danda/classes/e6;->n:Lcom/android/internal/util/danda/classes/f6;

    :goto_24b
    const/4 v3, 0x4

    goto :goto_257

    :cond_24d
    new-instance v4, Lcom/android/internal/util/danda/classes/f6;

    check-cast v3, Lcom/android/internal/util/danda/classes/p;

    invoke-direct {v4, v3}, Lcom/android/internal/util/danda/classes/f6;-><init>(Lcom/android/internal/util/danda/classes/p;)V

    iput-object v4, v2, Lcom/android/internal/util/danda/classes/e6;->n:Lcom/android/internal/util/danda/classes/f6;

    goto :goto_24b

    :goto_257
    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v3

    iput-object v3, v2, Lcom/android/internal/util/danda/classes/e6;->o:Ljava/math/BigInteger;

    iput-object v1, v2, Lcom/android/internal/util/danda/classes/e6;->q:[B

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v1

    if-ne v1, v10, :cond_278

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v0

    iput-object v0, v2, Lcom/android/internal/util/danda/classes/e6;->p:Ljava/math/BigInteger;

    :cond_278
    return-object v2

    :cond_279
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "k3 must be > k2"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_281
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "k2 must be > k1"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_289
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "k1 must be > 0"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_291
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "This type of EC basis is not implemented"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_299
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "This type of ECCurve is not implemented"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2a1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "bad version in X9ECParameters"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2a9
    return-object v1
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 6

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    sget-object v3, Lcom/android/internal/util/danda/classes/e6;->r:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/o2;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/e6;->m:Lcom/android/internal/util/danda/classes/x2;

    iget-object v4, p0, Lcom/android/internal/util/danda/classes/e6;->q:[B

    invoke-direct {v2, v3, v4}, Lcom/android/internal/util/danda/classes/o2;-><init>(Lcom/android/internal/util/danda/classes/x2;[B)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/e6;->n:Lcom/android/internal/util/danda/classes/f6;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/e6;->o:Ljava/math/BigInteger;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/e6;->p:Ljava/math/BigInteger;

    if-eqz v2, :cond_3b

    new-instance v3, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v3, v2}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_3b
    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method
