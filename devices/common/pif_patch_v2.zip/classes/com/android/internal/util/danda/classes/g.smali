.class public final Lcom/android/internal/util/danda/classes/g;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"


# static fields
.field public static final n:[Lcom/android/internal/util/danda/classes/g;


# instance fields
.field public final m:[B


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0xc

    new-array v0, v0, [Lcom/android/internal/util/danda/classes/g;

    sput-object v0, Lcom/android/internal/util/danda/classes/g;->n:[Lcom/android/internal/util/danda/classes/g;

    return-void
.end method

.method public constructor <init>(I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    int-to-long v0, p1

    .line 2
    invoke-static {v0, v1}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object p1

    invoke-virtual {p1}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/g;->m:[B

    return-void
.end method

.method public constructor <init>([B)V
    .registers 3

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-static {}, Lcom/android/internal/util/danda/classes/d5;->a()Z

    move-result v0

    if-nez v0, :cond_18

    .line 5
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/k;->q([B)Z

    move-result v0

    if-nez v0, :cond_10

    goto :goto_18

    .line 6
    :cond_10
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "malformed enumerated"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 7
    :cond_18
    :goto_18
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/g;->m:[B

    return-void
.end method


# virtual methods
.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 3

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/g;

    if-nez v0, :cond_6

    const/4 p1, 0x0

    return p1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/g;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/g;->m:[B

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/g;->m:[B

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/c0;->c([B[B)Z

    move-result p1

    return p1
.end method

.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 4

    const/16 v0, 0xa

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/g;->m:[B

    invoke-virtual {p1, v0, v1}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    return-void
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/g;->m:[B

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/c0;->j([B)I

    move-result v0

    return v0
.end method

.method public final i()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/g;->m:[B

    array-length v1, v0

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    array-length v0, v0

    add-int/2addr v1, v0

    return v1
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
