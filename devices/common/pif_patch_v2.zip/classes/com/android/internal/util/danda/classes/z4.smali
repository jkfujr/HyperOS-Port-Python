.class public Lcom/android/internal/util/danda/classes/z4;
.super Ljava/io/BufferedReader;
.source "SourceFile"


# virtual methods
.method public final a()Lcom/android/internal/util/danda/classes/x4;
    .registers 16

    invoke-virtual {p0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    :goto_4
    if-eqz v0, :cond_13

    const-string v1, "-----BEGIN "

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_13

    invoke-virtual {p0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    goto :goto_4

    :cond_13
    if-eqz v0, :cond_1e3

    const/16 v1, 0xb

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x2d

    invoke-virtual {v0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    if-lez v1, :cond_1e3

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "-----END "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuffer;

    invoke-direct {v3}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    :goto_40
    invoke-virtual {p0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x1

    if-eqz v5, :cond_7f

    const-string v7, ":"

    invoke-virtual {v5, v7}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v7

    if-ltz v7, :cond_6f

    const/16 v7, 0x3a

    invoke-virtual {v5, v7}, Ljava/lang/String;->indexOf(I)I

    move-result v7

    invoke-virtual {v5, v2, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v8

    add-int/2addr v7, v6

    invoke-virtual {v5, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Lcom/android/internal/util/danda/classes/w4;

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    iput-object v8, v6, Lcom/android/internal/util/danda/classes/w4;->a:Ljava/lang/String;

    iput-object v5, v6, Lcom/android/internal/util/danda/classes/w4;->b:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_40

    :cond_6f
    invoke-virtual {v5, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v7

    const/4 v8, -0x1

    if-eq v7, v8, :cond_77

    goto :goto_7f

    :cond_77
    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_40

    :cond_7f
    :goto_7f
    if-eqz v5, :cond_1cc

    new-instance v1, Lcom/android/internal/util/danda/classes/x4;

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    sget-object v5, Lcom/android/internal/util/danda/classes/b1;->a:Lcom/android/internal/util/danda/classes/c1;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v5

    div-int/lit8 v5, v5, 0x4

    mul-int/lit8 v5, v5, 0x3

    new-instance v7, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v7, v5}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    :try_start_96
    sget-object v5, Lcom/android/internal/util/danda/classes/b1;->a:Lcom/android/internal/util/danda/classes/c1;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v8

    :goto_9f
    if-lez v8, :cond_ba

    add-int/lit8 v9, v8, -0x1

    invoke-virtual {v3, v9}, Ljava/lang/String;->charAt(I)C

    move-result v9

    const/16 v10, 0xa

    if-eq v9, v10, :cond_b7

    const/16 v10, 0xd

    if-eq v9, v10, :cond_b7

    const/16 v10, 0x9

    if-eq v9, v10, :cond_b7

    const/16 v10, 0x20

    if-ne v9, v10, :cond_ba

    :cond_b7
    add-int/lit8 v8, v8, -0x1

    goto :goto_9f

    :cond_ba
    add-int/lit8 v9, v8, -0x4

    invoke-static {v3, v2, v9}, Lcom/android/internal/util/danda/classes/c1;->a(Ljava/lang/String;II)I

    move-result v2

    :goto_c0
    iget-object v10, v5, Lcom/android/internal/util/danda/classes/c1;->b:[B

    if-ge v2, v9, :cond_119

    add-int/lit8 v11, v2, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    aget-byte v2, v10, v2

    invoke-static {v3, v11, v9}, Lcom/android/internal/util/danda/classes/c1;->a(Ljava/lang/String;II)I

    move-result v11

    add-int/lit8 v12, v11, 0x1

    invoke-virtual {v3, v11}, Ljava/lang/String;->charAt(I)C

    move-result v11

    aget-byte v11, v10, v11

    invoke-static {v3, v12, v9}, Lcom/android/internal/util/danda/classes/c1;->a(Ljava/lang/String;II)I

    move-result v12

    add-int/lit8 v13, v12, 0x1

    invoke-virtual {v3, v12}, Ljava/lang/String;->charAt(I)C

    move-result v12

    aget-byte v12, v10, v12

    invoke-static {v3, v13, v9}, Lcom/android/internal/util/danda/classes/c1;->a(Ljava/lang/String;II)I

    move-result v13

    add-int/lit8 v14, v13, 0x1

    invoke-virtual {v3, v13}, Ljava/lang/String;->charAt(I)C

    move-result v13

    aget-byte v10, v10, v13

    or-int v13, v2, v11

    or-int/2addr v13, v12

    or-int/2addr v13, v10

    if-ltz v13, :cond_111

    shl-int/lit8 v2, v2, 0x2

    shr-int/lit8 v13, v11, 0x4

    or-int/2addr v2, v13

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V

    shl-int/lit8 v2, v11, 0x4

    shr-int/lit8 v11, v12, 0x2

    or-int/2addr v2, v11

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V

    shl-int/lit8 v2, v12, 0x6

    or-int/2addr v2, v10

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V

    invoke-static {v3, v14, v9}, Lcom/android/internal/util/danda/classes/c1;->a(Ljava/lang/String;II)I

    move-result v2

    goto :goto_c0

    :cond_111
    new-instance v0, Ljava/io/IOException;

    const-string v1, "invalid characters encountered in base64 data"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_119
    invoke-virtual {v3, v9}, Ljava/lang/String;->charAt(I)C

    move-result v2

    add-int/lit8 v5, v8, -0x3

    invoke-virtual {v3, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    add-int/lit8 v9, v8, -0x2

    invoke-virtual {v3, v9}, Ljava/lang/String;->charAt(I)C

    move-result v9

    sub-int/2addr v8, v6

    invoke-virtual {v3, v8}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const-string v8, "invalid characters encountered at end of base64 data"

    const/16 v11, 0x3d

    if-ne v9, v11, :cond_153

    if-ne v3, v11, :cond_14d

    aget-byte v2, v10, v2

    aget-byte v3, v10, v5

    or-int v5, v2, v3

    if-ltz v5, :cond_147

    shl-int/lit8 v2, v2, 0x2

    shr-int/lit8 v3, v3, 0x4

    or-int/2addr v2, v3

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V

    goto :goto_19b

    :cond_147
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v8}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_14d
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v8}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_153
    if-ne v3, v11, :cond_177

    aget-byte v2, v10, v2

    aget-byte v3, v10, v5

    aget-byte v5, v10, v9

    or-int v9, v2, v3

    or-int/2addr v9, v5

    if-ltz v9, :cond_171

    shl-int/lit8 v2, v2, 0x2

    shr-int/lit8 v8, v3, 0x4

    or-int/2addr v2, v8

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V

    shl-int/lit8 v2, v3, 0x4

    shr-int/lit8 v3, v5, 0x2

    or-int/2addr v2, v3

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V

    goto :goto_19b

    :cond_171
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v8}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_177
    aget-byte v2, v10, v2

    aget-byte v5, v10, v5

    aget-byte v9, v10, v9

    aget-byte v3, v10, v3

    or-int v10, v2, v5

    or-int/2addr v10, v9

    or-int/2addr v10, v3

    if-ltz v10, :cond_1ad

    shl-int/lit8 v2, v2, 0x2

    shr-int/lit8 v8, v5, 0x4

    or-int/2addr v2, v8

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V

    shl-int/lit8 v2, v5, 0x4

    shr-int/lit8 v5, v9, 0x2

    or-int/2addr v2, v5

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V

    shl-int/lit8 v2, v9, 0x6

    or-int/2addr v2, v3

    invoke-virtual {v7, v2}, Ljava/io/OutputStream;->write(I)V
    :try_end_19b
    .catch Ljava/lang/Exception; {:try_start_96 .. :try_end_19b} :catch_1b3

    :goto_19b
    invoke-virtual {v7}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v0, v1, Lcom/android/internal/util/danda/classes/x4;->a:Ljava/lang/String;

    invoke-static {v4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, v1, Lcom/android/internal/util/danda/classes/x4;->b:Ljava/util/List;

    iput-object v2, v1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    return-object v1

    :cond_1ad
    :try_start_1ad
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v8}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_1b3
    .catch Ljava/lang/Exception; {:try_start_1ad .. :try_end_1b3} :catch_1b3

    :catch_1b3
    move-exception v0

    new-instance v1, Lcom/android/internal/util/danda/classes/s;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "unable to decode base64 string: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, v0, v6}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1

    :cond_1cc
    new-instance v0, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " not found"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1e3
    const/4 v0, 0x0

    return-object v0
.end method
