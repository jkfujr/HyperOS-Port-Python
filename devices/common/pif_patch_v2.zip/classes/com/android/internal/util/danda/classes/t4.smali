.class public final Lcom/android/internal/util/danda/classes/t4;
.super Lcom/android/internal/util/danda/classes/z4;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/HashMap;


# direct methods
.method public constructor <init>(Ljava/io/StringReader;)V
    .registers 6

    invoke-direct {p0, p1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/t4;->a:Ljava/util/HashMap;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v2, "CERTIFICATE REQUEST"

    invoke-virtual {p1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v2, "NEW CERTIFICATE REQUEST"

    invoke-virtual {p1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/16 v2, 0x9

    invoke-direct {v0, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v3, "CERTIFICATE"

    invoke-virtual {p1, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/16 v3, 0xa

    invoke-direct {v0, v3}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v3, "TRUSTED CERTIFICATE"

    invoke-virtual {p1, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    invoke-direct {v0, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v2, "X509 CERTIFICATE"

    invoke-virtual {p1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/16 v2, 0x8

    invoke-direct {v0, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v2, "X509 CRL"

    invoke-virtual {p1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/4 v2, 0x3

    invoke-direct {v0, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v3, "PKCS7"

    invoke-virtual {p1, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    invoke-direct {v0, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v2, "CMS"

    invoke-virtual {p1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/4 v2, 0x7

    invoke-direct {v0, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v2, "ATTRIBUTE CERTIFICATE"

    invoke-virtual {p1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/4 v2, 0x0

    invoke-direct {v0, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(I)V

    const-string v3, "EC PARAMETERS"

    invoke-virtual {p1, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/4 v3, 0x5

    invoke-direct {v0, v3, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    const-string v3, "PUBLIC KEY"

    invoke-virtual {p1, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/4 v3, 0x6

    invoke-direct {v0, v3, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    const-string v3, "RSA PUBLIC KEY"

    invoke-virtual {p1, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/s4;

    new-instance v3, Lcom/android/internal/util/danda/classes/q4;

    invoke-direct {v3, v1}, Lcom/android/internal/util/danda/classes/q4;-><init>(I)V

    invoke-direct {v0, v3}, Lcom/android/internal/util/danda/classes/s4;-><init>(Lcom/android/internal/util/danda/classes/q4;)V

    const-string v1, "RSA PRIVATE KEY"

    invoke-virtual {p1, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/s4;

    new-instance v1, Lcom/android/internal/util/danda/classes/q4;

    invoke-direct {v1, v2}, Lcom/android/internal/util/danda/classes/q4;-><init>(I)V

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/s4;-><init>(Lcom/android/internal/util/danda/classes/q4;)V

    const-string v1, "DSA PRIVATE KEY"

    invoke-virtual {p1, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/s4;

    new-instance v1, Lcom/android/internal/util/danda/classes/q4;

    const/4 v3, 0x1

    invoke-direct {v1, v3}, Lcom/android/internal/util/danda/classes/q4;-><init>(I)V

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/s4;-><init>(Lcom/android/internal/util/danda/classes/q4;)V

    const-string v1, "EC PRIVATE KEY"

    invoke-virtual {p1, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    invoke-direct {v0, v3, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    const-string v1, "ENCRYPTED PRIVATE KEY"

    invoke-virtual {p1, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/r4;

    const/4 v1, 0x4

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    const-string v1, "PRIVATE KEY"

    invoke-virtual {p1, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/Object;
    .registers 5

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/z4;->a()Lcom/android/internal/util/danda/classes/x4;

    move-result-object v0

    if-eqz v0, :cond_2f

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/t4;->a:Ljava/util/HashMap;

    iget-object v2, v0, Lcom/android/internal/util/danda/classes/x4;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1b

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/y4;

    invoke-interface {v1, v0}, Lcom/android/internal/util/danda/classes/y4;->a(Lcom/android/internal/util/danda/classes/x4;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_1b
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "unrecognised object: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2f
    const/4 v0, 0x0

    return-object v0
.end method
