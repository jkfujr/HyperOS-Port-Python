.class public interface abstract Lcom/android/internal/util/danda/classes/i4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.392.200011.61.1.1.1.2"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.392.200011.61.1.1.1.3"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.392.200011.61.1.1.1.4"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.392.200011.61.1.1.3.2"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/i4;->a:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.392.200011.61.1.1.3.3"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/i4;->b:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.392.200011.61.1.1.3.4"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/i4;->c:Lcom/android/internal/util/danda/classes/o;

    return-void
.end method
