.class public abstract Lcom/android/internal/util/danda/classes/a;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"


# instance fields
.field public final m:Z

.field public final n:I

.field public final o:[B


# direct methods
.method public constructor <init>(ZI[B)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lcom/android/internal/util/danda/classes/a;->m:Z

    iput p2, p0, Lcom/android/internal/util/danda/classes/a;->n:I

    invoke-static {p3}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/a;->o:[B

    return-void
.end method


# virtual methods
.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 5

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/a;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/a;

    iget-boolean v0, p1, Lcom/android/internal/util/danda/classes/a;->m:Z

    iget-boolean v2, p0, Lcom/android/internal/util/danda/classes/a;->m:Z

    if-ne v2, v0, :cond_1f

    iget v0, p0, Lcom/android/internal/util/danda/classes/a;->n:I

    iget v2, p1, Lcom/android/internal/util/danda/classes/a;->n:I

    if-ne v0, v2, :cond_1f

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/a;->o:[B

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/a;->o:[B

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/c0;->c([B[B)Z

    move-result p1

    if-eqz p1, :cond_1f

    const/4 v1, 0x1

    :cond_1f
    return v1
.end method

.method public final hashCode()I
    .registers 3

    iget v0, p0, Lcom/android/internal/util/danda/classes/a;->n:I

    iget-boolean v1, p0, Lcom/android/internal/util/danda/classes/a;->m:Z

    xor-int/2addr v0, v1

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/a;->o:[B

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/c0;->j([B)I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method

.method public final i()I
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/a;->n:I

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->b(I)I

    move-result v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/a;->o:[B

    array-length v2, v1

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v2

    add-int/2addr v2, v0

    array-length v0, v1

    add-int/2addr v2, v0

    return v2
.end method

.method public final k()Z
    .registers 2

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/a;->m:Z

    return v0
.end method
