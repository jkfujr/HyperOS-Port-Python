.class public final Lcom/android/internal/util/danda/classes/r4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/y4;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 4

    iput p1, p0, Lcom/android/internal/util/danda/classes/r4;->a:I

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eq p1, v1, :cond_2b

    const/4 v1, 0x3

    if-eq p1, v1, :cond_27

    packed-switch p1, :pswitch_data_30

    .line 2
    invoke-direct {p0, v0, v0}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    return-void

    :pswitch_10
    const/16 p1, 0xa

    .line 3
    invoke-direct {p0, p1, v0}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    return-void

    :pswitch_16
    const/16 p1, 0x9

    .line 4
    invoke-direct {p0, p1, v0}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    return-void

    :pswitch_1c
    const/16 p1, 0x8

    .line 5
    invoke-direct {p0, p1, v0}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    return-void

    :pswitch_22
    const/4 p1, 0x7

    .line 6
    invoke-direct {p0, p1, v0}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    return-void

    .line 7
    :cond_27
    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    return-void

    .line 8
    :cond_2b
    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/r4;-><init>(II)V

    return-void

    nop

    :pswitch_data_30
    .packed-switch 0x7
        :pswitch_22
        :pswitch_1c
        :pswitch_16
        :pswitch_10
    .end packed-switch
.end method

.method public synthetic constructor <init>(II)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/android/internal/util/danda/classes/r4;->a:I

    return-void
.end method


# virtual methods
.method public final a(Lcom/android/internal/util/danda/classes/x4;)Ljava/lang/Object;
    .registers 7

    iget v0, p0, Lcom/android/internal/util/danda/classes/r4;->a:I

    const/4 v1, 0x0

    const-string v2, "problem parsing cert: "

    const/4 v3, 0x4

    packed-switch v0, :pswitch_data_1e2

    :try_start_9
    new-instance v0, Lcom/android/internal/util/danda/classes/y5;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/y5;-><init>([B)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_10} :catch_11

    return-object v0

    :catch_11
    move-exception p1

    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :pswitch_28
    :try_start_28
    new-instance v0, Lcom/android/internal/util/danda/classes/c6;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/c6;-><init>([B)V
    :try_end_2f
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_2f} :catch_30

    return-object v0

    :catch_30
    move-exception p1

    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :pswitch_47
    :try_start_47
    new-instance v0, Lcom/android/internal/util/danda/classes/b6;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/b6;-><init>([B)V
    :try_end_4e
    .catch Ljava/lang/Exception; {:try_start_47 .. :try_end_4e} :catch_4f

    return-object v0

    :catch_4f
    move-exception p1

    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :pswitch_66
    new-instance v0, Lcom/android/internal/util/danda/classes/a6;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    const-string v1, "malformed data: "

    const/4 v2, 0x1

    :try_start_6d
    sget v3, Lcom/android/internal/util/danda/classes/d1;->a:I

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    if-eqz p1, :cond_88

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/i0;->g(Lcom/android/internal/util/danda/classes/t;)Lcom/android/internal/util/danda/classes/i0;

    move-result-object p1
    :try_end_79
    .catch Ljava/lang/ClassCastException; {:try_start_6d .. :try_end_79} :catch_86
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6d .. :try_end_79} :catch_84

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object p1, v0, Lcom/android/internal/util/danda/classes/a6;->a:Lcom/android/internal/util/danda/classes/i0;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/i0;->m:Lcom/android/internal/util/danda/classes/j0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v0

    :catch_84
    move-exception p1

    goto :goto_90

    :catch_86
    move-exception p1

    goto :goto_a6

    :cond_88
    :try_start_88
    new-instance p1, Ljava/io/IOException;

    const-string v0, "no content found"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_90
    .catch Ljava/lang/ClassCastException; {:try_start_88 .. :try_end_90} :catch_86
    .catch Ljava/lang/IllegalArgumentException; {:try_start_88 .. :try_end_90} :catch_84

    :goto_90
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v2}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :goto_a6
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v2}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :pswitch_bc
    :try_start_bc
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/g5;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/g5;

    move-result-object p1

    new-instance v0, Lcom/android/internal/util/danda/classes/q5;

    new-instance v1, Lcom/android/internal/util/danda/classes/d0;

    sget-object v2, Lcom/android/internal/util/danda/classes/v4;->a:Lcom/android/internal/util/danda/classes/o;

    sget-object v4, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    invoke-direct {v1, v2, v4}, Lcom/android/internal/util/danda/classes/d0;-><init>(Lcom/android/internal/util/danda/classes/o;Lcom/android/internal/util/danda/classes/e;)V

    invoke-direct {v0, v1, p1}, Lcom/android/internal/util/danda/classes/q5;-><init>(Lcom/android/internal/util/danda/classes/d0;Lcom/android/internal/util/danda/classes/m;)V
    :try_end_d0
    .catch Ljava/io/IOException; {:try_start_bc .. :try_end_d0} :catch_d3
    .catch Ljava/lang/Exception; {:try_start_bc .. :try_end_d0} :catch_d1

    return-object v0

    :catch_d1
    move-exception p1

    goto :goto_d5

    :catch_d3
    move-exception p1

    goto :goto_ed

    :goto_d5
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "problem extracting key: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :goto_ed
    throw p1

    :pswitch_ee
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/q5;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q5;

    move-result-object p1

    return-object p1

    :pswitch_f5
    :try_start_f5
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/b5;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/b5;

    move-result-object p1
    :try_end_fb
    .catch Ljava/lang/Exception; {:try_start_f5 .. :try_end_fb} :catch_fc

    return-object p1

    :catch_fc
    move-exception p1

    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "problem parsing PRIVATE KEY: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :pswitch_115
    :try_start_115
    new-instance v0, Lcom/android/internal/util/danda/classes/j;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/j;-><init>([B)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/j;->f()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/n1;->g(Lcom/android/internal/util/danda/classes/t;)Lcom/android/internal/util/danda/classes/n1;

    move-result-object p1
    :try_end_124
    .catch Ljava/lang/Exception; {:try_start_115 .. :try_end_124} :catch_125

    return-object p1

    :catch_125
    move-exception p1

    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "problem parsing PKCS7 object: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :pswitch_13e
    :try_start_13e
    new-instance v0, Lcom/android/internal/util/danda/classes/u4;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/u4;-><init>([B)V
    :try_end_145
    .catch Ljava/lang/Exception; {:try_start_13e .. :try_end_145} :catch_146

    return-object v0

    :catch_146
    move-exception p1

    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "problem parsing certrequest: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :pswitch_15f
    :try_start_15f
    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    instance-of v2, p1, Lcom/android/internal/util/danda/classes/e3;

    if-eqz v2, :cond_16b

    move-object v1, p1

    check-cast v1, Lcom/android/internal/util/danda/classes/e3;

    goto :goto_18e

    :cond_16b
    if-eqz p1, :cond_18e

    new-instance v1, Lcom/android/internal/util/danda/classes/e3;

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p1

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/d0;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/d0;

    move-result-object v2

    iput-object v2, v1, Lcom/android/internal/util/danda/classes/e3;->m:Lcom/android/internal/util/danda/classes/d0;

    invoke-interface {p1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/p;->n(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/p;

    move-result-object p1

    iput-object p1, v1, Lcom/android/internal/util/danda/classes/e3;->n:Lcom/android/internal/util/danda/classes/p;

    :cond_18e
    :goto_18e
    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(Ljava/lang/Object;)V
    :try_end_191
    .catch Ljava/lang/Exception; {:try_start_15f .. :try_end_191} :catch_192

    return-object v0

    :catch_192
    move-exception p1

    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "problem parsing ENCRYPTED PRIVATE KEY: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :pswitch_1ab
    :try_start_1ab
    iget-object v0, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    instance-of v2, v0, Lcom/android/internal/util/danda/classes/o;

    if-eqz v2, :cond_1c0

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    goto :goto_1c8

    :catch_1bc
    move-exception p1

    goto :goto_1c9

    :catch_1be
    move-exception p1

    goto :goto_1e1

    :cond_1c0
    instance-of p1, v0, Lcom/android/internal/util/danda/classes/u;

    if-eqz p1, :cond_1c8

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/e6;->g(Lcom/android/internal/util/danda/classes/t;)Lcom/android/internal/util/danda/classes/e6;

    move-result-object v1
    :try_end_1c8
    .catch Ljava/io/IOException; {:try_start_1ab .. :try_end_1c8} :catch_1be
    .catch Ljava/lang/Exception; {:try_start_1ab .. :try_end_1c8} :catch_1bc

    :cond_1c8
    :goto_1c8
    return-object v1

    :goto_1c9
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "exception extracting EC named curve: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;I)V

    throw v0

    :goto_1e1
    throw p1

    :pswitch_data_1e2
    .packed-switch 0x0
        :pswitch_1ab
        :pswitch_15f
        :pswitch_13e
        :pswitch_115
        :pswitch_f5
        :pswitch_ee
        :pswitch_bc
        :pswitch_66
        :pswitch_47
        :pswitch_28
    .end packed-switch
.end method
