.class public final Lcom/android/internal/util/danda/classes/m2;
.super Lcom/android/internal/util/danda/classes/b;
.source "SourceFile"


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 7

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/b;->m:[B

    array-length v1, v0

    add-int/lit8 v2, v1, 0x1

    new-array v2, v2, [B

    iget v3, p0, Lcom/android/internal/util/danda/classes/b;->n:I

    int-to-byte v3, v3

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/4 v3, 0x1

    invoke-static {v0, v4, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v0, 0x3

    invoke-virtual {p1, v0, v2}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    return-void
.end method

.method public final i()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/b;->m:[B

    array-length v1, v0

    add-int/lit8 v1, v1, 0x1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    array-length v0, v0

    add-int/2addr v1, v0

    add-int/lit8 v1, v1, 0x1

    return v1
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
