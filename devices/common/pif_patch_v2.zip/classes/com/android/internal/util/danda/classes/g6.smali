.class public final Lcom/android/internal/util/danda/classes/g6;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/h6;


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/o;

.field public n:Lcom/android/internal/util/danda/classes/t;


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/g6;->m:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/g6;->n:Lcom/android/internal/util/danda/classes/t;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method
