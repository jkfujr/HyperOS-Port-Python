.class public final Lcom/android/internal/util/danda/classes/r0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Enumeration;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/android/internal/util/danda/classes/s0;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/s0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/r0;->b:Lcom/android/internal/util/danda/classes/s0;

    const/4 p1, 0x0

    iput p1, p0, Lcom/android/internal/util/danda/classes/r0;->a:I

    return-void
.end method


# virtual methods
.method public final hasMoreElements()Z
    .registers 3

    iget v0, p0, Lcom/android/internal/util/danda/classes/r0;->a:I

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/r0;->b:Lcom/android/internal/util/danda/classes/s0;

    iget-object v1, v1, Lcom/android/internal/util/danda/classes/s0;->n:[Lcom/android/internal/util/danda/classes/p;

    array-length v1, v1

    if-ge v0, v1, :cond_b

    const/4 v0, 0x1

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    return v0
.end method

.method public final nextElement()Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/r0;->b:Lcom/android/internal/util/danda/classes/s0;

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/s0;->n:[Lcom/android/internal/util/danda/classes/p;

    iget v1, p0, Lcom/android/internal/util/danda/classes/r0;->a:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lcom/android/internal/util/danda/classes/r0;->a:I

    aget-object v0, v0, v1

    return-object v0
.end method
