.class public interface abstract Lcom/android/internal/util/danda/classes/l0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;

.field public static final d:Lcom/android/internal/util/danda/classes/o;

.field public static final e:Lcom/android/internal/util/danda/classes/o;

.field public static final f:Lcom/android/internal/util/danda/classes/o;

.field public static final g:Lcom/android/internal/util/danda/classes/o;

.field public static final h:Lcom/android/internal/util/danda/classes/o;

.field public static final i:Lcom/android/internal/util/danda/classes/o;

.field public static final j:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.6.1.4.1.22554"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v3, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    const-string v5, "2.1"

    invoke-direct {v4, v1, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v6, "2.2"

    invoke-direct {v5, v1, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v6, "2.3"

    invoke-direct {v5, v1, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/o;

    const-string v6, "2.4"

    invoke-direct {v5, v1, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v3, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v5, "2"

    invoke-direct {v1, v3, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v3, v4, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v3, v4, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    const-string v6, "1.2"

    invoke-direct {v4, v1, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    const-string v7, "1.22"

    invoke-direct {v4, v1, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    const-string v8, "1.42"

    invoke-direct {v4, v1, v8}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v3, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v3, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v3, v8}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v3, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v4, v3, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v4, v3, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v4, Lcom/android/internal/util/danda/classes/l0;->a:Lcom/android/internal/util/danda/classes/o;

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    const-string v6, "3"

    invoke-direct {v4, v3, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v4, Lcom/android/internal/util/danda/classes/l0;->b:Lcom/android/internal/util/danda/classes/o;

    new-instance v3, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v3, v1, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v4, v3, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v4, Lcom/android/internal/util/danda/classes/l0;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v4, v3, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v4, Lcom/android/internal/util/danda/classes/l0;->d:Lcom/android/internal/util/danda/classes/o;

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v4, v3, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v4, Lcom/android/internal/util/danda/classes/l0;->e:Lcom/android/internal/util/danda/classes/o;

    new-instance v4, Lcom/android/internal/util/danda/classes/o;

    const-string v7, "4"

    invoke-direct {v4, v3, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v4, Lcom/android/internal/util/danda/classes/l0;->f:Lcom/android/internal/util/danda/classes/o;

    new-instance v3, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v3, v1, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v3, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/l0;->g:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v3, v5}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/l0;->h:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v3, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/l0;->i:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v3, v7}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/l0;->j:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v6}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    return-void
.end method
