.class public final Lcom/android/internal/util/danda/classes/u5;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/d;


# instance fields
.field public final m:Lcom/android/internal/util/danda/classes/t;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/t;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    instance-of v0, p1, Lcom/android/internal/util/danda/classes/b0;

    if-nez v0, :cond_14

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/i;

    if-eqz v0, :cond_c

    goto :goto_14

    .line 3
    :cond_c
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "unknown object passed to Time"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_14
    :goto_14
    iput-object p1, p0, Lcom/android/internal/util/danda/classes/u5;->m:Lcom/android/internal/util/danda/classes/t;

    return-void
.end method

.method public constructor <init>(Ljava/util/Date;)V
    .registers 7

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    new-instance v0, Ljava/util/SimpleTimeZone;

    const/4 v1, 0x0

    const-string v2, "Z"

    invoke-direct {v0, v1, v2}, Ljava/util/SimpleTimeZone;-><init>(ILjava/lang/String;)V

    .line 6
    new-instance v3, Ljava/text/SimpleDateFormat;

    const-string v4, "yyyyMMddHHmmss"

    invoke-direct {v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 7
    invoke-virtual {v3, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 8
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x4

    .line 9
    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/16 v1, 0x79e

    if-lt v0, v1, :cond_74

    const/16 v1, 0x801

    if-le v0, v1, :cond_3a

    goto :goto_74

    .line 10
    :cond_3a
    new-instance v0, Lcom/android/internal/util/danda/classes/h2;

    const/4 v1, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    .line 11
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 12
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/p5;->b(Ljava/lang/String;)[B

    move-result-object p1

    iput-object p1, v0, Lcom/android/internal/util/danda/classes/b0;->m:[B

    .line 13
    :try_start_4a
    new-instance p1, Ljava/text/SimpleDateFormat;

    const-string v1, "yyMMddHHmmssz"

    invoke-direct {p1, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 14
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/b0;->n()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;
    :try_end_58
    .catch Ljava/text/ParseException; {:try_start_4a .. :try_end_58} :catch_5b

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/u5;->m:Lcom/android/internal/util/danda/classes/t;

    goto :goto_7b

    :catch_5b
    move-exception p1

    .line 15
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "invalid date string: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 16
    :cond_74
    :goto_74
    new-instance v0, Lcom/android/internal/util/danda/classes/v1;

    .line 17
    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/i;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/u5;->m:Lcom/android/internal/util/danda/classes/t;

    :goto_7b
    return-void
.end method

.method public static h(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/u5;
    .registers 3

    if-eqz p0, :cond_33

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/u5;

    if-eqz v0, :cond_7

    goto :goto_33

    :cond_7
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/b0;

    if-eqz v0, :cond_13

    new-instance v0, Lcom/android/internal/util/danda/classes/u5;

    check-cast p0, Lcom/android/internal/util/danda/classes/b0;

    invoke-direct {v0, p0}, Lcom/android/internal/util/danda/classes/u5;-><init>(Lcom/android/internal/util/danda/classes/t;)V

    return-object v0

    :cond_13
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/i;

    if-eqz v0, :cond_1f

    new-instance v0, Lcom/android/internal/util/danda/classes/u5;

    check-cast p0, Lcom/android/internal/util/danda/classes/i;

    invoke-direct {v0, p0}, Lcom/android/internal/util/danda/classes/u5;-><init>(Lcom/android/internal/util/danda/classes/t;)V

    return-object v0

    :cond_1f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "unknown object in factory: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_33
    :goto_33
    check-cast p0, Lcom/android/internal/util/danda/classes/u5;

    return-object p0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u5;->m:Lcom/android/internal/util/danda/classes/t;

    return-object v0
.end method

.method public final g()Ljava/util/Date;
    .registers 6

    :try_start_0
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u5;->m:Lcom/android/internal/util/danda/classes/t;

    instance-of v1, v0, Lcom/android/internal/util/danda/classes/b0;

    if-eqz v1, :cond_3d

    check-cast v0, Lcom/android/internal/util/danda/classes/b0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v2, "yyyyMMddHHmmssz"

    invoke-direct {v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    new-instance v2, Ljava/util/SimpleTimeZone;

    const-string v3, "Z"

    const/4 v4, 0x0

    invoke-direct {v2, v4, v3}, Ljava/util/SimpleTimeZone;-><init>(ILjava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/b0;->n()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/16 v3, 0x35

    if-ge v2, v3, :cond_30

    const-string v2, "20"

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_36

    :cond_30
    const-string v2, "19"

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_36
    invoke-virtual {v1, v0}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0

    return-object v0

    :catch_3b
    move-exception v0

    goto :goto_44

    :cond_3d
    check-cast v0, Lcom/android/internal/util/danda/classes/i;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/i;->n()Ljava/util/Date;

    move-result-object v0
    :try_end_43
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_43} :catch_3b

    return-object v0

    :goto_44
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "invalid date string: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/u5;->m:Lcom/android/internal/util/danda/classes/t;

    instance-of v1, v0, Lcom/android/internal/util/danda/classes/b0;

    if-eqz v1, :cond_23

    check-cast v0, Lcom/android/internal/util/danda/classes/b0;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/b0;->n()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x35

    if-ge v1, v2, :cond_1c

    const-string v1, "20"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_29

    :cond_1c
    const-string v1, "19"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_29

    :cond_23
    check-cast v0, Lcom/android/internal/util/danda/classes/i;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/i;->p()Ljava/lang/String;

    move-result-object v0

    :goto_29
    return-object v0
.end method
