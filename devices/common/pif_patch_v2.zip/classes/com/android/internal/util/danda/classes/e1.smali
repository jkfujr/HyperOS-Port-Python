.class public final Lcom/android/internal/util/danda/classes/e1;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/u;

.field public n:Lcom/android/internal/util/danda/classes/s5;


# direct methods
.method public static g(Lcom/android/internal/util/danda/classes/t;)Lcom/android/internal/util/danda/classes/e1;
    .registers 4

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/e1;

    if-eqz v0, :cond_7

    check-cast p0, Lcom/android/internal/util/danda/classes/e1;

    return-object p0

    :cond_7
    new-instance v0, Lcom/android/internal/util/danda/classes/e1;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object p0, v0, Lcom/android/internal/util/danda/classes/e1;->m:Lcom/android/internal/util/danda/classes/u;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_35

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/s5;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/s5;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/e1;->n:Lcom/android/internal/util/danda/classes/s5;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/d0;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/d0;

    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/q1;->p(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q1;

    return-object v0

    :cond_35
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "sequence wrong size for a certificate"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/e1;->m:Lcom/android/internal/util/danda/classes/u;

    return-object v0
.end method
